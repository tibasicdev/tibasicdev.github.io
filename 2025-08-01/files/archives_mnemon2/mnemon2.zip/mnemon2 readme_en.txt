MNEMON DataSheet Creator 2.0 Readme


By Mapar007

1. Installation
-Send MNEMON2.8xp to your calc.
-Run prgmMNEMON2

2. Configuration.
-PASS:Input a password NUMBER you would like
-KEYGEN:Input a COMPLETELY RANDOM 6-digit code which is NOT "MNEMON" (unless you want everyone to be able to read your DataSheets, but whether it are numbers or letters doesn't matter)
-Input your password to continue to the Main Menu

3. Creating Data Sheets
-Choose a type of sheet
-Choose 1: "NEW SHEET" in the main menu
-Enter any text/number (read Str8 after first program execution to check which tokens are reckognised by the program (most of the math tokens and the Asm tokens))
-Press "ENTER"
(program will now add your key to the data)
-Write down the bookmark code carefully or you risk data loss! (later version might include a function remembering those)

4. Reading Data Sheets
-Choose a type of sheet
-Choose 2:"LOAD SHEET"
-Input a bookmark code. (if the code is wrong, you will get "INVALID", but if the code fits, and the key is 	wrong, you get "INVALID KEY")
-Wait a second or 2 and the program will output the data.

5. Erasing all data
-Choose 3:"ERASE ALL"
-Pick "YES, ERASE"
-Program will output: "Cleared"

6. Version History

1.0: First release
1.1: A few hours later: Fixed a bug. Made 1.1 version
1.2: fixed bugs
1.3: fixed more bugs
2.0: created multiple types of sheets

\Mapar007 (look for me at http://tibasicdev.wikidot.com/home)



Note: If the program might still crash, just run it again and choose "Quit" to archive your data. Crashing program will not result in immediate data loss. Please report any bugs to Mapar007 on tibasicdev.wikidot.com