
 Solitare v1.0
 by nitacku
 e-mail: nitacku36@yahoo.com

Features:

 clear, easily understandable graphics
 very fast for basic
 just one program
 no bugs
 
Controls:

 move:			arrows
 select/place card	2nd
 set card		graph
 draw from pile		alpha
 quit			clear

Instructions:

 Stack cards on top of other cards 
 having the opposite color suit
 and being one rank higher.
 (Ex. 4 of Hearts on 5 of Clubs)
 Win by building four stacks of cards
 (one for each suit) in ascending
 order from Ace to King. 