connect four game skeleton by facingtomorrow
feel free to use this (as long as you give me credit)

controls:
CLEAR/MODE = quit
S          = save
ENTER      = select menu/column

intro menu:
1: simple  = new token appears in place
2: graphic = new token falls, square by square, into place
3: load    = loads saved game
4: help    = displays controls
5:         = skips game board draw (good for testing)
