+-----------------------------+
| Battle Subs!                |
+-----------------------------+
                                         |_
                                   _____|~ |____
                                  (  --         ~~~~--_,
                                   ~~~~~~~~~~~~~~~~~~~'`

Battle Subs! is a game where you try to sink the
computer submarine.

  Controls:

[2nd]: Fire torpedo. You can only fire ONE at a time. If it
misses the computer, press [2nd] again to remotely blow it
up.
[Arrow] keys: Move your submarine.
[Clear]: Forfeit the Battle.

  Tips:

If you want to hit the computer directly, dive down quicker
before the computer and then fire your torpedo.

  Capability:

This program is compatible for the TI-84+/SE. It CAN
run on the TI-83+/SE, but the game might run slower.

  View Project:
http://tibasicdev.wikidot.com/projects:battle-subs-beta#post-4493881

  Made By:

Name: Thunderlord Zinogre (Zinogre_Bio_Hazard1282_rPi3)
Email: biohazard1282@gmail.com
Discord: Zinogre_BH1282_rPi3
