TINT Package Info

TINT, or TI Number Theory, is a package of lists and programs designed for number theoretic computation and analysis on the TI-84+ series of calculators.
These programs are designed to be used as subprograms for larger projects, and are optimized for numbers less than 10^12.
Note: This package requires OS 2.53MP or higher to use. A version for older calculator models will be available soon.

To install, simply download and open the group. All TINT programs are denoted by θNT followed by 2 or 3 characters.
The following variables and lists are defined for an input N after executing the program θNTN.
Most programs also require the factorization of N to be defined via θNTN (exceptions are noted below).

Vars
Properties
-W: Count of distinct prime divisors
-O: Count of prime divisors
-C: Compositeness
-T: # of Divisors
-S: Sum of Divisors
-A: Aliquot
-B: Abundance
-H: Totient
-L: Liouville function
-U: Mobius function
-R: Radical
-D: Arithmetic derivative
-G: Log arithmetic derivative

Inputs
-N: Number
-P: Arbitrary prime
-M: Arbitrary whole number (usually a modulus)
-Q: Arbitrary whole number
-K: Input number (usually small)

Program Vars
-X: Bound
-Y: Loop var
-Z: Counter

Empty Vars
-E: Empty var
-F: Empty var
-I: Empty var
-J: Empty var
-V: Empty var
-θ: Empty var

Lists
-P: Prime factors of N
-A: Prime multiplicities of N
-B: A+1
-D: Divisors of N
-E: Divisor multiplicities of N
-U: Unitary divisors of N

Premade Lists
-P100: All primes < 100
-P1000: All primes < 1000

Programs (return is Ans unless otherwise stated)
-NTCM: Carmichael's function of N
-NTCQ: Ramanujan's sum of N base Q
-NTCR: Core of N mod M
-NTDK: Sum of Kth powers of divisors of N
-NTGCD: GCD of L1
-NTIS: If N satisfies property; input the property as a two-letter string from the list below in Ans
--"CM": Carmichael
--"LC": Lucas-Carmichael
--"KP": K-Perfect
--"GI": Giuga
--"SF": Squarefree
--"KS": K-Smooth
--"KR": K-Rough
--"PW": Perfect power
--"AB": Abundant
--"PF": Powerful
--"UN": Unusual
--"RF": Refactorable
--"SP": Semiprime
--"NH": Nonhypotenuse
--"AP": Almost perfect
--"KH": K-Hyperperfect
--"HP": Hemiperfect
--"BL": Blum
--"RG": Regular
--"HD": Harmonic divisor
--"AR": Arithmetic
--"PP": Primary pseudoperfect
-NTJK: Jordan's totient of N base K
-NTLCM: LCM of L1
-NTLI: Intersection of L1 and L2 --> L3
-NTLJ: Kronecker symbol (generalized Legendre/Jacobi symbol) of N base Q
-NTMO: Multiplicative order of Q mod M
-NTMU: Mobius function of N w/o factorization
-NTMX: Q^K mod M (modular exponentiation algorithm)
-NTN: TINT data initialization for N
-NTPF: Prime factorization of N
-NTPG: List of primes up to X --> L1
-NTPN: Generate next prime given a list of previous primes in L1
-NTPT: Primality test of N w/o factorization
-NTVP: Multiplicity of P in N

Have any questions? Found a bug?
Contact kg583 on TI-Basic Developer.

Copyright © Kevin Gomez 2018. All rights reserved.