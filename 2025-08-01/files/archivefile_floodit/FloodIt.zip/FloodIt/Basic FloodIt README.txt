 ___       __   __   __    ___ 
|__  |    /  \ /  \ |  \ |  |  
|    |___ \__/ \__/ |__/ |  |  
_______________________________
)_____________________________(

by Michael2_3B
a ti-basic program for the TI-84+ CE

original game: http://unixpapa.com/floodit
 
 _
|_| Installation

-send BFLOODIT.8xp and ZFLOOD.8xp to your calculator using TI Connect CE
-run prgmBFLOODIT
-enjoy :)

 _
|_| Objective

click the blocks in order to fill the board with a single color. see if you can do it within a specified amount of moves!

each time you click a block, everything starting from the top left will get flooded with the color of the block you click. this allows you to reach even more blocks for the next turn. you should catch on pretty quick ;)

 _
|_| Controls

[enter] or [2nd] for clicking
arrow keys for moving cursor
[clear] for quick exit

graphing keys (below the screen) for on-screen buttons

 _
|_| Other Notes

in the options menu, you can change your cursor at any time

if you change the board options (size and/or colors) they won’t go into effect until you press the ‘New’ button.

_______________________________
|_____________________________|


If you have any suggestions on speeding up the flood algorithm, post it! https://www.cemetech.net/forum/viewtopic.php?t=12517

Thank you for downloading!

copyright 2016 Michael2_3B