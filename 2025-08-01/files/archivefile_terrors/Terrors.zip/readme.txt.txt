A few things to note about my programs & subprograms:

1. The programs will be in a group. Ungroup this by going into 2ND (+), going to the bottom option, and selecting ungroup.
2. Do not run anything with a theta (circle with a wavy slash through it) in the name.
3. To get the title screen centered (for aesthetic reasons), select your calculator model at the beginning, when you run the game.
4. To get to the final town, access both towns.
5. The tournament is more of a post-game thing, but can be used earlier to farm money.
6. If you are having trouble running a program, just upload the individual files, which are provided.
*Also, the screenshot shows it working on a TI-84+CSE. However, it can work an a TI-84/TI-84+.

**NOTE** This game does not intentionally depict gang violence or terrorism. 
I do not intend to offend any person or persons with this material.