Welcome to the README :)
First of all, thank you for downloading this.

In order to get this onto your calculator using the .8xp file, you're going to need TI-Connect.

1. Launch TI-Connect and click Send to TI Device.
2. Connect your calculator to your PC/Mac via Mini-B Usb. The window should recognize it.
3. You could either drag and drop the file or you could click "Browse" and find the file like that.
4. Click on Send to Device and wait for the file to transfer.
5. Disconnect your calculator and you're done, it's that simple!

Let me know of any bugs you would like me to fix by commenting on my page.

Thanks, and have a good day!