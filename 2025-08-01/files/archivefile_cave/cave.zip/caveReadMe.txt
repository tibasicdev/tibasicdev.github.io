The Cave ReadMe

WARNING! subProgram ZCAVELVL required for gameplay! Levels WILL NOT load without it!
/*ZCAVELVL should be included in .zip file*/

Storyline:
	You are a snake that took refuge from the rain in a cave. You wake realizing you are lost, and have
	no idea how to get out. Using your intellect, escape the cave by using keys, boulders, and other
	resources.

Gameplay:
	Press the arrow keys to move around. You cannot move through walls, although you can pick up or
	move objects around in order to advance to the next level.

TileMap(On Screen):
	[nothing] Open Space, Walkable /OR/ Invisible Wall, Barrier
	[I] Wall, Barrier
	[delta] Player, Move With Arrow Keys
	[pi] Door, Needs Key To Advance
	[*] Key, Needed To Bypass Door
	[O] Boulder, Push To Move In Direction Of Push

TileMap(In Matrix):
	0 Open Space
	1 Wall
	2 Player (Spawn)
	3 Door
	4 Key
	5 Boulder
	6 Invisible Wall

Update Log:
	V1.3.7 Better level selection, back to matrices for speed
	V1.2.7 Maps now created with strings, reducing size significantly
	V1.1.7 Added 'Invisible Wall' and 2 new levels
	V1.0.5 Initial release, 5 levels

Author:
	Zachatoo (AKA The Amazing Zach)
	Twitter: @zachatoo