Font Editor
-----------------------------------------------------------------------------------------------
This is an on-the-calculator Omnicalc font editor. I got a little bored of making the fonts on the computer and then sending it to my calculator so I figured out the format of the custom fonts and made these editors. Since the programs require Celtic3, but the fonts are installed by Omnicalc, juggling control with the apps was a tad tricky. Don't worry, I figured out an effective method (these two apps have a wierd way of sharing control).

Getting Started
Send FNTEDIT2 and Font to your calculator. If you do not have Omnicalc or Celtic3 Send these, too.
FONTEDIT was my version one. It will edit the font about as well as version 2. Both can be on the calc at the same time.
The Fonts folder contains fonts that I have made. The program Font is the regular font, ready to be edited. These programs show up as CUSTFONT on the calculator. Changing the name will allow you to have access to that as a font, but this program only edits CUSTFONT.

-Now, on the calculator, go to Apps and select Omnicalc. Select Install. Now select Font Sets. Find CUSTFONT and press enter. Press clear.
-Go to Apps again and select Celtic3 press 1 to install and then 1 again to overwrite hooks. Press three to exit.
-Now select the font editor and start editing. Say you turned 'E' into 'e'. Any time an E would be used it would then be e.

Using FNTEDIT2
The first time you use it or send over a new CUSTFONT or delete the hacked pics ZTSTEP and Z(theta)STEP, you will need to select option 2 (Load font pics) on the main menu. This will take all of the characters in CUSTFONT and turn them into the two pics (in a nut shell). This will take about 20 seconds (on an 84+ at least).
To edit the font:
-select EDIT on the main menu
-Use the arrows to move the cursor
-Use + or - to change the Character page
-Press enter to edit the character
	-Use the arrows to move the pixel
	-Press enter to turn the pixel on/off
	-Press mode when you are finished
-Press mode when you are finished

Using FONTEDIT
-Scroll through the characters using the arrows.
-Press enter to edit the character
	-Use the arrows to move the pixel
	-Press enter to turn the pixel on/off
	-Press mode when you are finished

Notes
FNTEDIT2 does not let you edit char 0 (it does not appear edited even when it is anyways)

11/25/2009-Made FONTEDIT,FNTEDIT2 and readme
	FONTEDIT now lets you edit all characters
	Also made it a bit faster (o.k., maybe 48 bits faster, give or take)