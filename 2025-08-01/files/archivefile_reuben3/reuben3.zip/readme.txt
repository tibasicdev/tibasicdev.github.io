____            _                   ___                  _   
|  _ \ ___ _   _| |__   ___ _ __    / _ \ _   _  ___  ___| |_ 
| |_) / _ \ | | | '_ \ / _ \ '_ \  | | | | | | |/ _ \/ __| __|
|  _ <  __/ |_| | |_) |  __/ | | | | |_| | |_| |  __/\__ \ |_ 
|_| \_\___|\__,_|_.__/_\___|_| |_|  \__\_\\__,_|\___||___/\__|
 _                                                            
| |    ___  ___| |_  | __ )  ___| |___      _____  ___ _ __   
| |   / _ \/ __| __| |  _ \ / _ \ __\ \ /\ / / _ \/ _ \ '_ \  
| |__| (_) \__ \ |_  | |_) |  __/ |_ \ V  V /  __/  __/ | | | 
|_____\___/|___/\__| |____/ \___|\__| \_/\_/ \___|\___|_| |_| 
|_   _(_)_ __ ___   ___  ___                                  
 | | | | '_ ` _ \ / _ \/ __|                                 
 | | | | | | | | |  __/\__ \                                 
 |_| |_|_| |_| |_|\___||___/                                 

=== Installation ===
1. Send Reuben3.8xk to your calculator
2. Hit APPS and scroll down to "Reuben 3" and hit enter

You only need very few RAM (~70 bytes) to be able to run the
game, it'll warn if if you don't have enough RAM.

=== Controls ===
Title Screen:
Left/Right/2ND - pick option
DEL - Exit

Walking:
Arrows - Move
2ND - Interact
Alpha - Use Item
2ND+Alpha - Map
MODE - Item Menu
DEL - Exit

Battle Engine:
Left - Attack
Up - Magic
Right - Run (only works in non-boss fights)
Down - Item

Battle Engine Magic:
Left - Stun
Up - Ice
Right - Bold
Down - Fire

=== Credits ===
Programmed:
Sorunome

Story:
Sorunome

Map:
Sorunome
Digital

Graphics:
DJ Omnimaga
Art_of_camelot
Sorunome
Coops
naz2a

Special Thanks:
Geekboy
Iambian
Oninoni
Kotu
Xeda112358
Runer112
p2 (excessive testing)

Some Enemy Sprites:
http://www.wesnoth.org/units/1.12/mainline/en_US/mainline.html
http://opengameart.org/content/32x32-fantasy-tileset
http://opengameart.org/content/10-basic-rpg-enemies
http://opengameart.org/content/34-view-beetle

Original Creator of Reuben Series:
DJ Omnimaga (reachable at http://codewalr.us)


=== Bugs? ====
If you find any bugs, please report them!
https://www.omnimaga.org/reuben-quest/



This game is developed by Omnimaga: https://www.omnimaga.org




I am not responsable for any damage this game may take to your calculator,
even though it shouldn't do any (just your normal disclaimer).
