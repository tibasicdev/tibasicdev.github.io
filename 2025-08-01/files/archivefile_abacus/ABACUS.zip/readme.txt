Abacus, Version 1.0

Author: TaterTomorrow

Descrption: This is an abacus program crammed in under 600 bytes, to both demonstrate the power of an old counting aid and to garner cheap laughs with the irony of emulating an ancient math tool on a modern math tool.

Compatibility: TI-83+/84+

Variables: A, B, C, H, L1, GDB1

Installation: Use TI-Connect to transfer the .8XP file to the calculator, then run ABACUS.

Controls: Up and down keys control the cursor, left and right keys move the beads, and "Y=" cleans the screen and closes.

Troubleshooting: There should be absolutely no bugs in this game, but if you encounter any, please contact me.

Released: January 24, 2021. This package, including the code, is released to the Public Domain. Crediting and shoutouts are highly appreciated :)