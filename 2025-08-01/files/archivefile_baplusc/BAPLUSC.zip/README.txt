 ________________________
|                        |
| Basic Avalanche Plus C |
|________________________|

By Michael2_3B, adapted by Myles_Zadok for color calculators

From Basic Avalanche Plus: "This is one of my most basic games, however it is still kind of addicting :P You must collect the falling "+" signs and avoid the falling "-" signs. Failure to do so will result in Game Over. High score included.

CONTROLS: Left and Right Arrow keys to move, CLEAR to quit at any time."