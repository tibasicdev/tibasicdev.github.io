Project.........Tic-Tac-Toe
Program.........TTT and TTTA
Author..........Zeda Elnara (ThunderBolt)
E-mail..........xedaelnara@gmail.com
Size............819 bytes
Language........English
Programming.....BASIC
Version.........1.00
Last Update.....21:29 23/02/2011

Suggested Font	Any fixed width font (like Courier New)
Suggested Size	11

*Do NOT view with Word Wrap
*The following should fit on one line:
================================================================
How To Use
================================================================
 TTT is the actual program to run and TTTA is the AI code. Run
prgmTTT to play. If you choose to play as X, the calc plays as O
and if you play as O, the calc plays as X. If you want to play
against another person, select the "TWO PLAYER" option.

To play, simply use the numbers 1~9 to place your piece. The
location of the keys corresponds to the location on the playing
board. For example, [7] sets the upper left corner and [3] sets
the lower right corner and [5] sets the center.

For a challenge, try playing as O... I find it pretty tough :D
================================================================
Notes
================================================================
Feel free to check out the source for tricks on manipulating
matrices and lists.
================================================================
History
================================================================
21:34 23/02/2011-Decided to upload this to TIBD
================================================================