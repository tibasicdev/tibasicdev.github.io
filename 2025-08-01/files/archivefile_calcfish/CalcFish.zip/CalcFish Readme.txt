{\rtf1\ansi\ansicpg1252\cocoartf1404\cocoasubrtf340
{\fonttbl\f0\fmodern\fcharset0 Courier-Bold;\f1\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww26580\viewh13780\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\sl336\slmult1\pardirnatural\partightenfactor0

\f0\b\fs10 \cf0 |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||\
||||||||            ||||||||||||||||||||||||||||||||||||||        |||||||||||||||||||||||||||||||||||||                    ||||||||||||    |||||||||||||||||||||||||||||||||||||    ||||||||||||||||||||||\
||||    |||||||||||||    |||||||||||||||||||||||||||||||||||||    |||||||||||||||||||||||||||||||||||||    |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||    |||||||||||||||||||||\
||||    ||||||||||||||||||||||||||             |||||||||||||||    |||||||||||||||||             |||||||    ||||||||||||||||||||||||        ||||||||||||||||            |||||||||    ||||        |||||||||\
||||    |||||||||||||||||||||||||||||||||||||||    |||||||||||    ||||||||||||    |||||||||||||||||||||                ||||||||||||||||    ||||||||||||    |||||||||||||||||||||        ||||||||    |||||\
||||    ||||||||||||||||||||||||||                 |||||||||||    ||||||||||||    |||||||||||||||||||||    ||||||||||||||||||||||||||||    ||||||||||||||||            |||||||||    ||||||||||||    |||||\
||||    |||||||||||||    ||||    |||||||||||||     |||||||||||    ||||||||||||    |||||||||||||    ||||    ||||||||||||||||||||||||||||    ||||||||||||||||||||||||||||    |||||    ||||||||||||    |||||\
||||||||            ||||||||||||||                ||||||||            ||||||||||||            |||||||||    ||||||||||||||||||||||||            ||||||||                |||||||||    ||||||||||||    ||||||\
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
\fs24 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0
\cf0 \

\f1\b0 Version 1.0 By Kydapoot\
Go to {\field{\*\fldinst{HYPERLINK "https://www.cemetech.net/forum/viewtopic.php?t=12759&highlight="}}{\fldrslt https://www.cemetech.net/forum/viewtopic.php?t=12759&highlight=}} for questions, comments, bug reports, etc. I am open to suggestions, optimization help, and questions. Just remember that I am very busy with school and so I may take a while to get back to you.\
\
\ul Contents:\ulnone \
-Installation\
\pard\tx720\tx1440\tx1760\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0
\cf0 -Program Setup\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0
\cf0 -Programs/Other Stuff Used\
-Features\
-Gameplay\
-Money\
-Graphics and Symbols\
-Easter Egg\
-Rights\
\
\ul Installation:\ulnone \
Send everything in the \'93Files To Send\'94 folder to your calc. The entire thing is 11271 bytes. Tested on a TI-84+, but should run on entire TI-83+ Monochrome Family.\
\
\ul Program Setup\ulnone \
WARNING: YOU WILL ALMOST CERTAINLY RUN INTO CRASHES IF YOU DO NOT FOLLOW THESE INSTRUCTIONS!\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8355\tx8674\tx8682\pardirnatural\partightenfactor0
\cf0 Once the programs and lists and strings are on your calc, execute prgmCALCFISH and press a key. When you reach the main menu, select option 7 (MORE OPTIONS) and then select option 1 (RESET STATS) and say yes both times. Then select option 2 (BACK UP DATA). Make sure that the programs CALCFISH, CATFISH, VIRTFISH, and ZVFSHSTP are UnArchived to play. You will then start out with 10 fish, $100, 25 food pellets, 10 pills, and 15 brushes.\
\
\ul Programs/Other Stuff Used:\ulnone \
prgmCALCFISH- Execute this to play\
prgmVIRTFISH- Main Game, Shop\
\pard\tx0\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8674\tx8682\pardirnatural\partightenfactor0
\cf0 prgmCATFISH - Short for \'93Catch Fish;\'94 catching and selling\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8355\tx8674\tx8682\pardirnatural\partightenfactor0
\cf0 prgmMINIGAME- Minigames\
prgmZVFSHSTP- Resets Stats\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8355\tx8674\tx8682\pardirnatural\partightenfactor0

\fs18 \cf0 L
\fs24 FISH       - Stores Data\

\fs18 L
\fs24 FISHB      - Stores Backed Up Data\
Str8        - Stores Bubble+ Bubbles\
Str9        - Stores Backed Up Bubble+ Bubbles\
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8355\tx8674\tx8682\pardirnatural\partightenfactor0
\cf0 \ul \ulc0 Features:\ulnone \
-Main Game: See how long you can keep a fish alive.\
-Highscores: 10 stored for the main game. 
\fs18 L
\fs24 6 is used for ordering the highscores, but not storing.\
-Fishing: Catch fish\
-Selling: Sell fish you have caught for extra money.\
Minigames:\
-Deep Fry: Quickly memorize a customers order and then serve it to them.\
-Shark!: Make a customized shark. Warning: Play this only when really bored!\
-Bubble+: Like cookie clicker, only much less sophisticated.\
-Flying Fish: Memorize where a target is and then try to hit it with a fish.\
-Highscore Cashing- Set all of your highscores to 0 again in exchange for money.\
-Backing up data- Duplicates and archives your day so if something happens you can restore it.\
-Whenever you go to the main menu you will be notified if something happens. I will let the events remain surprises though!\
\
\ul Gameplay:\ulnone \
-Main Game: Your fish will be swimming along the bottom of the tank. It\'92s hunger increases at a constant rate. If its hunger gets above 50, it will starve, so feed it using [2ND]. This reduces it\'92s hunger by 10. Don\'92t overfeed! Every time you feed the fish, the dirtiness increases, and the dirtier than tank is, the faster you fish\'92s disease increases. Press [MATH] to clean -the tank. If the disease gets above 50, your fish dies. Press [ALPHA] to give your fish medicine, but don\'92t overdose: one pill reduces disease by 20! P\
-Catching Fish: Move your hook around with the right and left arrows. if you go off one side of the screen, you appear on the other side, and holding the arrows will make you go twice as fast as normal. Press the down arrow to drop your hook. If the hook hits the fish\'92s head, you have caught one! Press [MODE] to quit, [ENTER] to pause. The more fish you catch, the more likely you are to catch a gold-fish!\
-Minigames:\
-Deep Fry: Quickly memorize the order and then enter in the correct amount of fish, cook level, and recipe. Faster is better, but you lose many points if you are incorrect!\
-Shark!: Press enter to stop the changing parts of the shark and see how cool you can get it to look!\
-Bubble+: Press any key to get a bubble. See how many bubbles you can get! (progress is automatically saved). There are three modes (can be adjusted under the \'93SETTINGS\'94 option). Mode one (preset to this) is the fastest and allows you to have custom bubbles. Mode two is more graphical (it draws fast circles for bubbles). Mode three (personally my least favorite) actually draws bubbles that rise to the top of the screen. This is very slow, however, so if you want a lot of bubbles, this is not the best choice.\
-Flying fish: This is tricky one to do well at. You see the target and then input the gravity, power, and starting height (which are really just A, B, and C in a quadratic equation) and see if you hit the target. If you do, the program keeps track of how man of your fish have hit it.\
\
\ul Money:\ulnone \
-The main game costs $5.00 to play.\
-It costs $5.00 to catch more fish.\
-t costs $1 to go to the market.\
-Fish can be sold at the market for up to $2.00 each.\
-It costs $1.00 to play any minigame\
-If you catch enough fish, you can catch a Gold-Fish, which can make money.\
-You have to but food, brushes, and pills when you run out in order to play the main game. These are pretty cheap though.\
\
\ul Graphics and Symbols:\ulnone \
>=\uc0\u8805  or \u8804 =< - Fish\
\'ba          - Food Pellet\
\'d8 (theta)  - Medicine Pill\
88888888888- Brush\
.          - Filth on tank\
\pard\tx0\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8674\tx8682\pardirnatural\partightenfactor0
\cf0 J          - Fishing hook\
X          - Warning: Fish is to hungry/sick or tank is too dirty.\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8355\tx8674\tx8682\pardirnatural\partightenfactor0
\cf0 !          - Do not feed/pill/clean.\
\
\ul Easter Egg:\ulnone \
May or may not allow you to simultaneously cheat and better understand the program. Happy Hunting!\
\
\ul Rights:\
\ulnone This is entirely my program and you may not distribute it in any way without first asking me permission via private message on Cemetech or Tibasicdev. My username is Kydapoot on both. I am the sole author of this program and it is an original game (not a clone). I have taken inspiration from several games (computer and calculator), but this program is, as they say, 1% inspiration and 99% perspiration: it is definitely mine. You may modify the code if you wish, but I cannot guarantee that the program will work after you do. I have tested this program to extreme degrees and am not liable for any damage it may do to you or your calculator.}