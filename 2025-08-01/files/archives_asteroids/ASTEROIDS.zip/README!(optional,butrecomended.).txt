Ti-84+ ASTEROIDS
Readme
included with your "purchace"(aka:download) are:
ME! The fantastic unbiased readme file that you wanted to download! Oh also my lame roomates...
-My lame roomates-
Asteroids.8xg: Really buggy *FIRST RELEASE* of the classic arcade/Atari 2600 game of the same name. its a group file.
the program you select to run the bug bonanaza known as ti-84+ asteroids is called- ASTEROIDS!, yes, quite orginal. 

The 
project was started on Augest 15, 2012, when Master Superchu first started to derp around with the physics(or lack of) 
engine. the main reasons it took till september 20 to get it released were:
2 RAM clearing incidents.
only working at school
laziness
a math teacher who didnt take kindly to Master Superchu programing in class, and took his calculator from him. 
in math. more advanced than calculus. luckily; Ti-36XS Solar saved the day!

yes, this does work on 83+, however, it is unconfirmed how fast it runs on 83+, as is if it runs on 83.(one would need to
break up the group and transfer programs over one by one O_. 

My other lame roomate
keygame.8xp
a lame reflex 'game' have 'fun'. 

The End!