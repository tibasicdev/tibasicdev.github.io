				************
				*   TiLP   *
				************





DESCRIPTION
-----------

TiLP is a program allowing a PC to communicate with 
a TI calculator.

It works on Linux, Windows, Mac OS-X and FreeBSD platforms. It has been
ported to BeOS (but this port is not maintained any longer).
See README.linux, README.win32 or README.freebsd according to your
platform for more informations.

All physical link cables are supported by TiLP: parallel, serial, 
BlackLink, GrayLink, AVRlink and SilverLink.
TiLP also support some virtual links: one for VirtualTI, the other one for
GtkTiEmu.

Note1: the SilverLink cable may not work fine TI82/85.
Note2: direct USB cable of TI84+ / TI89 Titanium is currenly unusable by TiLP 
			 but supported	by our driver.

Supported calculators are: 
	TI73, TI82, TI83, TI83+/SE, TI84+/SE, TI85, TI86, 
	TI89, TI89 Titanium, TI92, TI92+ and V200.


FEATURES
--------

Note: some features depends on the OS version. Be sure to have the latest !

TI89/TI89 Titanium/TI92+/V200:
  - remote control of the calculator
  - screen dump
  - directory list
  - sending/receiving variable
  - sending/receiving backup
  - ROM dump
  - sending/receiving of FLASH applications
  - upgrading of Operating System (AMS)
  - getting/setting time (need AMS >= 2.08)

TI92:
  - remote control of the calculator
  - screen dump
  - directory list
  - sending/receiving variable
  - sending/receiving backup
  - ROM version
  - ROM dump (FARGO II required)

TI86:
  - screen dump
  - sending/receiving backup (old & new ti86 calcs)
  - sending/receiving variable
  - TIGL file support
  - ROM dump (any shell)

TI85:
  - screen dump
  - sending/receiving backup
  - sending/receiving variable
  - TIGL file support
  - ROM dump (Usgard or ZShell required)

TI83+/TI84+ (SE or not SE):
  - screen dump
  - directory list
  - sending/receiving backup (archived vars are not backed up !)
  - sending/receiving variable
  - sending/receiving of FLASH applications
  - upgrading of Operating System (GRAPH EXPLORER SOFTWARE)
  - ROM dump (any shell)

Note: the TI83+ is the only calc to have a GROUP variable. TiLP supports it in
a specific way: this kind of var is saved as a single file as any other
variable. Thus, if you send it, it will stay be grouped on calc.
The TI's software has a different way: it explode the GROUP variable
into a .8Xg group file and you lost the grouping on calculator.

TI83:
  - screen dump
  - directory list
  - sending/receiving variable
  - sending/receiving backup
  - TIGL file support
  - ROM dump (AShell required)

TI82:
  - screen dump
  - sending/receiving variable
  - sending/receiving backup
  - TIGL files support
  - ROM dump (ASh required)

TI73:
  - screen dump
  - directory list
  - sending/receiving variable
  - sending/receiving of FLASH applications
  - upgrading of Operating System (GRAPH EXPLORER SOFTWARE)


AVAILABILITY
------------

  http://lpg.ticalc.org/prj_tilp 
	(redirected on http://tilp.info)


COPYRIGHT
---------

TiLP is Copyright (C) 1999-2005 by the TiLP team <tilp-users@lists.sf.net>.

Copying is allowed under the terms of GNU General Public License.  
See the file COPYING for more details.


THANKS
------

See the THANKS file, please.


----------------------------------------------------------------------
Please report any bugs, questions, ...  
(please give us your platform, your 
calculator type (with ROM version) and your link cable model).

The TiLP team <tilp-users@lists.sf.net>.
