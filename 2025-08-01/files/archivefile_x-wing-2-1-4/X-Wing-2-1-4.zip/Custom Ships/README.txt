Oxiti8's custom ships pack for X-Wing 2.1 (83+/84+) and X-Wing 2.0(both CT's 83+ port and Scott Westenhaver's TI-83 original)

This pack includes picvars for the ARC-170 Starfighter, the TIE Fighter, and the T-70 X-Wing.

To use one of these ships, open the folder with the name of the ship you want to use,
and send Pic1.8xi (or Pic1.83i if you are using an original TI-83)
from that folder to your calculator.

Only one ship can be used at once. To change ships, swap out the picvar.

Note: Technically, any picvar in the Pic1 slot can be used with X-Wing 2.
However, using any random picvar for this may cause problems with visibility.

That being said, I want to encourage you to care and share your own custom ships, 
so I have included a template in .bmp format for you to edit in the "TEMPLATE" folder.

Have fun!



ARC-170 and TIE Fighter picvars by Oxiti8
