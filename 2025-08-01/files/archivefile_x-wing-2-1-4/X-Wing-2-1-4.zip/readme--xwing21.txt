        ____________________________________________
       |         ____________  __   ________        |
       |        /  ____  ___| /  \  |  ___  \       |
       |       /  /   | |    / || \ |  |__\  |      |
       | ______\  \   | |   /  __  \|  ____ /____   | 
       | |_________|  |_|  /__/  \__\  |   \_____|  |
       |  ___        ___   __   ________     _____  |   
       |  \  \  /\  /  /  /  \  |  ___  \   /  ___| |
       |   \  \/  \/  /  / || \ |  |__\  | /  /     |
       |    \        /  /  __  \|  ____  /_\  \     | 
       |     \__/\__/  /__/  \__\__|   \_______|    |
       |____________________________________________|


X-Wing 2.1 - Revival Update (Version 2.1.4)
for TI-83+(SE)/TI-84+(SE) systems

NOTICE FROM OXITI8: THIS PROGRAM IS A FAN-MADE UPDATE TO X-WING 2.0, AND IS NOT MEANT TO INFRINGE ON ANYONE'S RIGHTS.
IF THE ORIGINAL CREATORS WISH TO TAKE THIS DOWN FOR ANY REASON, THEY SHOULD EMAIL ME AT weedleninja88@gmail.com.

by Scott Westenhaver
originally distributed by CDG (revival is distributed by Oxiti8)
ported by Chris Tandiono
revival update by Oxiti8/Ben. F

1. Installation
	To install, send all the *.8x? files to your calculator. For proper game performance,
it is essential that you allow it to overwrite any files it needs.  The following vars will
be overwritten by xwing: prgmXWING, Pic0, Pic1, Pic2 and Pic3.  If any of these 
vars are used, you must rename them if you wish to preserve them. X-Wing 2.1 cannot be 
installed concurrently with other versions of X-Wing or any other game that requires
these variables.

2. Gameplay
	X-Wing is a first-person combat flight simulator of the X-Wing starfighter set in 3D 
space.  Controls are similar to most other flight simulators and are quite easy to adapt to.
A list of all of the key commands is provided in the program's built in documentation.  The
objective is to maneuver your craft so that the TIE fighter is in the center of the screen, 
and then fire on it.  If it goes off of the screen, you will see an "X" at the edge of the 
screen.  Flying towards this X will bring you to the enemy.  
****NOTE**** If you cannot see the enemy or the X indicator, just fly down because he is 
most likely just obscured by the cockpit. You won't see the X until he goes below the bottom 
of the screen.

3. How to use Custom Ships
On top of the standard X-Wing, X-Wing 2.1.4 comes with 3 custom ships, one for each trilogy:
The ARC-170 Starfighter, the TIE Fighter, and the T-70 X-Wing.
The picvars for these ships and the instructions on how to use them can be found inside the folder titled "Custom Ships". 

4. X-wing 2.0 History

	12-20-98:	X-Wing 2.0 project begins.
	12-31-98:	Primitive 3D display system complete.
	01-06-99:	Engine scrapped due to speed problems.
	01-25-99:	Faster engine developed.
	02-04-99:	Engine scrapped due to overwhelming bugs.
	02-16-99:	All new high speed engine begins.
	03-03-99:	New engine essentially complete.
	03-12-99:	Player motion developed.
	03-13-99:	X-Wing 2.0 technolgy demo released.
	03-25-99:	AI system developed.
	04-29-99:	AI scrapped due to unrecoverable speed problems.
	05-03-99:	New AI developed.
	05-09-99:	New AI scrapped due to complexity and inaccuracy.
	06-01-99:	New AI developed that requires almost no calculation.
	06-06-99:	X-Wing 2.0 Alpha 1 released.
	07-01-99:	Display bugs mainly eliminated.
	07-12-99:	Offscreen target locator developed.
	07-18-99:	Opening intro completed.
	07-23-99:	Code streamlined.
	07-25-99:	Combat system perfected.
	07-29-99:	Graphics and menus developed.
	07-30-99:	X-Wing 2.0 Beta 1 released.
	08-08-99:	X-Wing 2.0 Beta 2 released. Added random locations, fixed bugs.
	08-10-99:	X-Wing 2.0 Beta 3 released. Enhanced help, added high score system.
	08-22-99:	X-Wing 2.0 Final Release Completed. All bugs gone.
	04-08-04:	X-Wing 2.0 for the TI-83+ is released. Ported by Chris Tandiono.
	01-21-21:	X-Wing 2.1 Revival for the TI-83/84+ by oxiti8 is completed. Added 3 new results screens, removed menu flashing, added shell compatibility, removed the need for XSETUP, and made optimizations to reduce program size.
	01-22-21:	X-Wing 2.1 Revival first released. Work on X-Wing 2.1.1 begins.
	01-24-21:	X-Wing 2.1.1 completed. Updated text spacing, memory leaks are patched.
	01-25-21:	X-Wing 2.1.1 released.
	01-28-21:	X-Wing 2.1.1 is submitted to ticalc.org with a revised README.
	02-08-21:	X-Wing 2.1.2 is started, ARC-170 custom ship is completed.
	02-09-21:	X-Wing 2.1.2 is completed. It is heavily optimized to reduce file size and slightly increase speed, it adds an icon for DoorsCS, and fixes a graphing bug in the intro.
	02-10-21:	TIE Fighter custom ship is completed.
	02-23-21:	X-Wing 2.1.3 is started. Adds JEDI difficulty, and fixed a bug that made Medium difficulty register as Hard difficulty.
	02-24-21:	X-Wing 2.1.3 is completed. Now allows for the high score list to be archived.
	03-27-21:	X-Wing 2.1.4 is released. This version reduces the filesize even further, and adds 1 new custom ship to the game, the T-70 X-Wing.

5. Contact information
	Comments? E-mail the original author at scottwest@aol.com, the porter at 
m1ss1ontomars2k4@yahoo.com, and the revival creator at weedleninja88@gmail.com. If you want to redistribute any portion of the original program, e-mail 
Scott. Contact Scott if you are an independent developer willing to join a group to promote 
your work and help you with future projects.
			

Star Wars, X-Wing, and all related images are registered trademarks of LucasFilm LTD and The Walt Disney Company.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Portions of this document are copyright (c)2004 Chris Tandiono and 2021 Ben F./oxiti8.
All other information contained in this document is copyright (c)1999 by CDG.
2.1 revival update 2021 Ben F./Oxiti8.
This document must be distributed with its corresponding program file wherever possible.