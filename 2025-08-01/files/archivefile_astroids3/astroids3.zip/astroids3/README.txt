Astroids 3 CE
v.1.7
Nick Pease
Compatibility: TI84+CE
This program is a shoot em up style game that places you as the pilot of a spacecraft.
You must either shoot the asteroids or avoid them.
Keep in mind that if you avoid them, you lose 1 point. 
This is ENTIRELY written in TI-Basic and utilizes the homescreen.
It is written for TI84+CE right now, but a port to TI-83+ is planned. 

Contents:
ASTROID3.8xp     Calculator File
README.txt       README (THIS FILE)

Installation:
To install, send ASTROID3.8xp and ASHINST.8xp to your calculator. Run ASHINST.8xp BEFORE ASTROID3.8xp OR A ERROR WILL BE THROWN!
After you run the program and ASTROID3.8xp is working, you can delete the ASHINST.8xp file.

(C) 2017 Nick Pease


