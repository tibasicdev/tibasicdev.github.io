Hi!

This is the readme to BDHCNVRT.

Just in case the instructions in the program aren't clear, I explain it here but more briefly.

For binary numbers, you have to enter the numbers one by one (pressing enter after each digit you enter),  and from RIGHT to LEFT.
The reason for this is that the already large program would become a lot longer if you had to enter it te normal way.
And becouse you normally read binary numbers from right to left.

Also, becouse you can enter 16 digits (becouse that's all that can fit in one line on the home screen), 
I made it that way that when you're ready with your number, 
you enter any number that isn't 1 or 0, that number becomes 0 and the program converts your number.
So if your number is 000001100101, you have to enter:
1 <enter>
0 <enter> 
1 <enter>
0 <enter>
0 <enter>
1 <enter>
1 <enter>
2(or something else that isn't 1 or 0) <enter>

For decimal numbers there is no big problem, you just enter the whole number the way you normally do.
So if your number is 42, you just type 42 and push enter.
Just make sure your number isn't larger than decimal 65535 becouse that is hexadecimal FFFF and binary 1111111111111111.
If it is, the program won't convert it but instead tell you it is to big.

For hexadecimal numbers you enter the number digit by digit, 4 digits of it, in the normal 
You can use letters, or you can use the decimal value of those numbers. That's 10 for A, 11 for B, 12 for C, 13 for D, 14 for E and 15 for F.
So if your number is AB, you have to enter:
0 <enter>
0 <enter>
A <enter>
B <enter>

If there are any issues, please e-mail me at denis.ru@hotmail.com

That's all you have to know.

All your base are belong to us.

/)*(\