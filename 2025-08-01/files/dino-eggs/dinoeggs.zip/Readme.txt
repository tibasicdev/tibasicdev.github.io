Alex's Dino Eggs         axchos@yahoo.com
by Alex Cho Snyder       Author of Dragon

Dino Eggs is based on the PuzzPack game Dino Puzzle. The object is
to match falling shapes with similar shapes on the field. You do
this by moving a cursor and switching two rows at a time to align
them with the two incoming shapes before they land and another pair
descends. In the first version of Dino Eggs, every time you land a
shape onto another shape of the same kind, both disappear. If those
two shapes are eggs (theta), then you also gain two points. In the
second version, you must match three shapes in a row before they
disappear, but every kind of shape gives you a point, not just eggs.
In both versions, the game starts slowly and increases speed with
each point you gain until it maxes out after a hundred points.

You may save one game at a time, and they will be preserved even
after starting a new game or continuing, as long as you do not save
over them or delete the saved list file. In the menu, use the arrow
keys and enter or the number pad to select an option.

( - Your cursor
(

(0=theta, n=pi)

0 - An egg, giving points or hatching to the adjacent shape
n - A rough imitation of the mushroom shape of Dino Puzzle
* - A rough imitation of the plant shape of Dino Puzzle
s - A rough imitation of the snake shape of Dino Puzzle
e - A rough imitation of the bird shape of Dino Puzzle


Controls -

Arrows - Move cursor up and down, left arrow drops pieces

2nd    - Switch two selected rows (right arrow also switches)

Mode   - Save game

Clear  - End game


Programming -

Vars -

A - Your cursor vertical coord
B - Your score
C - Falling shape 1 type (1=0, 2=n, 3=*, 4=s, 5=e)
D - Falling shape 2 type (1=0, 2=n, 3=*, 4=s, 5=e)
E - Falling shape 1 vertical coord
F - Falling shape 1 horizontal coord (<-->)
G - Falling shape 2 vertical coord
H - Falling shape 2 horizontal coord (<-->)
I - Temporary loop var
J - Temporary loop var
K - Future shape 1 type
L - Future shape 2 type
M - Future shape 1 vertical coord
N - Future shape 2 vertical coord

[D] - 6x15 matrix of the field

L0 - Saved game/high score list for Dino Eggs
L00 - Saved game/high score list for Dino Eggs 2