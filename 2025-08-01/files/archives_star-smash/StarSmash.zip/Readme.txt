*********STAR SMASH*********

I.    Files
II.   Instilation
III.  Instructions
IV.  Support


I.    The folder you just downloaded contains several items. Star Smash
      as a program, Star Smash as a hexifile, Star Smash as an app, the 
      program to install Star Smash, A screen shot, and this readme.
      The files you will want to put on your calculator are: StrSmash 
      (Ti Connect Program), StrSmash (Ti Connect Application),  
      and SETUPSS (Ti Connect Program). Leave the hexifile alone, it's only
      if the application gets deleted or corrupted.

II.   After you have put the correct programs on your calculator, 
      unarchive them all except for the Ti Connect Application. Run
      the program titled SETUPSS once, it will reset the highscore names, 
      and then archive it. You will not need this program again, unless your
      highscore names become corrupted. Star Smash uses strings five, six,
      and seven, so you may want to be careful to not use these strings in 
      another program. 

III. In game instructions are provided. 

IV. If you have any questions, you can either post them on the discussion 
     for this program, email me at benny2391@charter.net, or send a private
     message to my wikidot account, programmingfreak. I don't check 
     my email often, so only use it if you canot find the discussion page or 
     my account. There are no known glitches, but if you discover any that 
     I have missed, please contact me.
