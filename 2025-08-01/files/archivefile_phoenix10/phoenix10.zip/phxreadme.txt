Phoenix 1.0 Readme


1. Configuration

- You first need to enter a 7-character code, which will be used to "lock" your data.
- Then specify a password. You can use any key, exept [ON]

2. Creating a sheet

- First, select a category (New univ. sheet/New pers. sheet)
- Input the data (if a token is not recognised, a ? will appear if you load the sheet, but most common tokens will be recognised; no more than 100 tokens)
- Press enter. A sheet Id will be returned. This should be an integer number between 1-16, there is no support for more sheets.

3. Loading a sheet
- Select Load pers/load univ
- Input the ID (e.g. if you want to load sht nbr 1, input 1)
- Press enter. The sheet will be loaded on the graph screen

4. Erasing data

- You can clear a sheet database by going to Settings/actions and then selecting the appropriate option.

5. The rest of the settings menu

- You can turn off password prompting
- You can modify your key and password, but be aware that if you modify the key, you won't be able to read your old personal data anymore.

6. The I/O menu

- You can export both personal and universal data to L6, and transfer it to another calc.
- You can import an external list
- You can read imported lists

7. Reading imported data

To do this, you must know the PHX bookmark codes of the sheet. Currently there is no support for tracking them down, but I'll try to add that in a next version. It comes down on this:

PHX Bookmark = Integerpart.decimalpart

Integerpart=starting point
decimalpart=length (key included)

If the BMK code matches, you can see the sheet data on the screen.


8. Contact the author

Mail to mapar007a@gmail.com or contact me at wikidot.com