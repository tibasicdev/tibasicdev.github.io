Java(Beta)
A Basic Program developed by Elijah Fajimi

Description:
Java is a text-based personal assistant to meet your needs. 

Current Version: v0.1b
v0.1b
Released on Sat May 9, 2020
- Added commands (Request cmds() to view)


Upcoming Updates: 
Measurement Converter
Surface area support for more 3D figures
Chatting with Java
Support with Ti-84 Plus CE (JavaCE)

System Minimum Requirements:
Display: 320x320/ 240x320 - 16 bit color LCD
CPU: ARM9-26EJ-S (132 MHz)
SDRAM: 64 MB
NAND Memory: 128 MB
Flash ROM: 512KB NOR ROM
OS Version: v4.5.0 or higher
Storage: 5kb

COMPATIBILITY:
Ti-Nspire CX CAS & Non-CAS
Ti-Nspire CX II CAS & Non-CAS

No Ndless Required!

Included in this Bundle:
Java(Beta).tns (This is the application)
README.txt (This is the file you are viewing now)

Installation Guide:

Preparation -
Make sure you have TI-Nspire™ Computer Link Software downloaded before installation of Java. Download the software at https://education.ti.com/en/products/computer-software/ti-nspire-computer-link 
Download -
Install the bundle, unzip, and transfer to your TI-Nspire CX/CX-CAS through the link software.
Getting Started -
Open Java(Beta) - TiAssistant and select Java(Beta). Once done, Java will set up immediately and you'll be ready to go!


Contact me @ elijahfajimi1@gmail.com
©2020, Elijah Fajimi. All rights reserved.
