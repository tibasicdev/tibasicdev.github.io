
                ##### #####     ##### #      ###  #   #
                  #     #       #     #     #   # #   #
                  #     #   ### ####  #     #   # # # #
                  #     #       #     #     #   # # # #
                  #   #####     #     #####  ###   ###

		    by Jonathan Bush and Pablo Yong

Please refer to the PDF readme for more information, and a better experience.

--------------------------------------------------------------------------------

Compatibility

TI-83, TI-83 Plus, TI-83 Plus Silver Edition
TI-84 Plus, TI-84 Plus Silver Edition
International versions of the above

--------------------------------------------------------------------------------

Installation

Use TI-Connect or a similar software to transfer TIFLOW.8xg to your calculator. 
If you drag the group into the RAM portion of your calculator, TI Connect will
ask which files you wish to transfer. TIFLOW.8xp, and at least one of the
FLPACK__.8xp files are required. The FLPACK__.8xp files contain the pack data
necessary to play the levels. Each pack contains unique levels of a different
size. You may Archive packs that you do not currently wish to play, and UnArchive
them when needed. You can also utilize the HomeRun feature of DoorsCS7 to run
programs while archived.

--------------------------------------------------------------------------------

Game Play

Flow is played by two simple rules: connect each lettered pair of dots (nodes),
and fill every space. Lines are also not allowed to cross themselves or lines of
a different letter.

Play TI-FLOW by running one of the pack programs listed above from the PRGM menu.

Select the desired level from the Select Level screen.

Play the game by using the arrow keys to move the cursor, and [2ND] to select
and deselect letters. Refer to the PDF for more information.

--------------------------------------------------------------------------------

License

TI-FLOW is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike
4.0 International License (CC BY-NC-SA 4.0).

You are free: to copy, distribute, display, and demonstrate the work, and to make
derivative works under the following conditions: you must attribute the work in
the manner specified by the licensor; you may not use this work for commercial
purposes; if you alter, transform, or build upon this work, you may distribute
the resulting work only under a license identical to this one. For any reuse or
distribution, you must make clear to others the license terms of this work. Any
of these conditions can be waived if you get permission from the licensor. Your
fair use and other rights are in no way affected by the above.

