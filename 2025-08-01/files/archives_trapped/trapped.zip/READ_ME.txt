  _________  _______   _______   _______   _______   _______   ______  
  \__   __/ (  ____ ) (  ___  ) (  ____ ) (  ____ ) (  ____ \ (  __  \ 
     ) (    | (    )| | (   ) | | (    )| | (    )| | (    \/ | (  \  )
     | |    | (____)| | (___) | | (____)| | (____)| | (__     | |   ) |
     | |    |     __) |  ___  | |  _____) |  _____) |  __)    | |   | |
     | |    | (\ (    | (   ) | | (       | (       | (       | |   ) |
     | |    | ) \ \__ | )   ( | | )       | )       | (____/\ | (__/  )
     )_(    |/   \__/ |/     \| |/        |/        (_______/ (______/ 
a Puzzle Game By Alex Marcolina


I) Description

At the begining of the game, you wake up to find yourself trapped in the center of a fiendish maze 
filled with mystery and enemies that want to eat you.  A mysterios friend and long forgotten
notes guid you through the maze.  Find Items, blow up walls, fight logical enemies, and above
all, find the machine that will help you escape.

II) System Requirements

The Game is fairly large, about 1400 bytes, so Trapped should be the only thing unarchived.
You do NOT have to unarchive Pic0 for Trapped to work.
You must also have xLib on your calculator and installed.


III) gameplay

Keys:

Arrow Keys------move
2nd-------------Place\detonate bomb
Mode------------Status Menu
Clear-----------Exit

Items:

Bombs
Pushpower
Glasses

Items will be explained in full in the game.


IV) Saving

When you go to the status menu, your game is automaticaly saved to list trp.
When you exit out, this list is archived.  DO NOT TAMPER WITH THIS LIST!!!
You will most certainly cause an ingame crash or othr unexpected results.
I did not put tamper protection on the list, but if you can figure out which numbers do 
what, you deserve to cheat.

V) Warning

Due to a certain feature built into the program, if you EVER exit out using the on button,
the next time you try to run the program, unexpected things may happen.  Such as nothing.
Sometimes the problem will fix itself after the program is run, but other times you must reset 
variable p to zero.

VI) Bugs

there are no known bugs at this point, if you find any
PLEASE report them at builderboy2005@yahoo.com

also, as this program uses xLib, an assembly routine, it is possible
that this program will crash and reset your ram.  Oh well, you have been
warned.

VII) Compatability

Trapped should be fully compatable with ti-83 but it was made on a ti-84, so it
is not guarentied.  And it will run slow. slloooowwwwww.


