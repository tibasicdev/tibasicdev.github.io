 __       _     _           
/ _\_ __ (_) __| | ___ _ __ 
\ \| '_ \| |/ _` |/ _ \ '__|
_\ \ |_) | | (_| |  __/ |   
\__/ .__/|_|\__,_|\___|_|   
   |_|    
                  
Spider
An Angel Production
Coded by Alex Marcolina
Builderboy2005@yahoo.com

-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

Contents:
	I)   Introduction
	II)  Instructions
	III) Easy/Medium/Hard
	IV)  Errors
	V)   Conclustion

I) Introduction

	I was browsing ti-calc when i came across a program that involved pipes and rearanging
and adding them to let the water through.  This program inspired me, and soon i had created my
own rendition.  You start out with a matrix of pipes which you can select and rotate, and the 
spider starts in one small section, after a bit, the spider starts to move, and the farther it 
travels through the pipes, the higher score you get.

II) Instructions
	
	The instructions are simple, when you you first run the game, you should be greeted by the
Angel productions Logo, and then proceed to the main menu.  The highscore button is mode, and you
quit out with clear.  Select your game type (Easy/Medium/Hard) and it proceeds to build your random 
level.  The starting poit will flash to let you know of its position  
	In the game, your cursor is centered over one pipe section, and you move it with the arrow
keys and rotate the piece undernieth it with 2nd.  After the bar on the bottom reaches left, the spider
will start.  Keep the spider from crashing into a dead end for as long as possible.  At any time you can
press clear to end the game and quit out to the home screen.
	Once the game is over, you will recieve your score, and be alerted if it is a highscore.  You
will then go back to the main menu.

III) Easy/Medium/Hard

There are 3 difficulty settings, easy, medium, and hard.  On easy, the spide rmoves slowly, and you have
strait pieces and turned pieces.  On medium, the spider moves faster, and non-rotatable, multiturn pieces 
have been added to the field.  On hard, the spider moves at its fastest, and some spaces have been left blank.

There are sepperate highscores for each difficulty setting.

IV) Errors

	There are no known bugs orr errors in the program with the exeption of a program error
that alerts you of a small problem that sometimes occurs on Ti84 calculators.  Not to worry though!
The program backs up your highscores, and prompts you to re-set your calculator
remember to archive your programs!

