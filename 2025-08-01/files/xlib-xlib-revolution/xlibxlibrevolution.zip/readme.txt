TI-BASIC will never die... and Dance shall live forever...

XLIB XLIB REVOLUTION
Version 1.4
2005, by K�vin Ouellet, Epic Programming Studio.
Dance Dance Revolution is a property of Konami.

Description
===========
xLIB xLIB Revolution is a clone of the Dance Dance Revolution game using xLIB flash APP by Patrick Prendergast (hence the name). Unlike most other calculator clones this one features crazy graphics and run pretty fast. It also includes a level editor that will allow infinite possibilities for the game.

Installation
============
This game requires a TI-83+, a TI-83+SE, a TI-84+, a TI-84+SE with 15 KB of RAM free as well as some archive memory if you want more than one level on the same calculator. The game has been adjustedd to run at the same speed on all the calculator models mentionned above. 

To install the game (assuming you have TI-Connect), locate the xxr folder on your computer and select all 8x? files. Right click on one of them and click on "Send to TI device". Wait until the software finishes loading and click on "Send". The files should now transfer.

Ok now you have the game but what about levels? Well go in the Level Samples folder now. Select all 8xg files, right click and send to TI device. Wait until it finish loading and click on send. Now you should have the game as well as 3 levels on your calc. Keep in mind that XXROTFD.8xg is a Silver Edition/84+ only level. It will not run on the regular 83+!

Playing the game
================
To start the gamefirst you need to ungroup a level. Go in the MEM menu ([2nd] + [+]) and press [8]. Now select the "UNGROUP" label and choose one of the XXR????? files. This should install a level. (If you need to switch to another level in the future repeat those steps again and when it says duplicate name overwrite all.)

Now assuming you followed those steps carefully go in the PRGM menu and select XXR and press enter twice. You should now see the following title screen. Press 2nd to bring the menu.

START SONG: start the game
DIFFICULTY: changes difficulty settings (in hard mode you lose points even if there was no arrows to be pressed when you press a key)
HIT DETECTION: set if the game must check if arrow matches before they reach the top or after
QUIT: Exit the game

If you ever played Dance Dance Revolution type games you should get into xLIB xLIB Revolution very quickly. The only difference is that there is no sound. Basically this is a reflexion game where you must press the corresponding arrow that is highlighted at the top of the screen. When you don't or press the wrong one you miss and lose points. You start with 100 points and if it reaches 0 you fail. The goal of the game is to perform the whole step pattern until the end of the song. Afterward you see a screen with your score as well as the highest consecutive successful steps record you did during the song. Here are the controls:

2nd: Go to next screen
arrows: press the arrow that match the one on the screen
ON/MODE: Quit the game

Credits
=======
-Patrick Prendergast for xLIB and his support (xLIB updates can be found there: http://omnimaga.dyndns.org/index.php?showtopic=1362 )
-Patai Gergely for his awesome PindurTI emulator
-All people support on forums and IRC (this is what kept this project alive)
-Konami for making DDR
-You for downloading this game

Contact information
===================
E-mail: omnimaga@gmail.com
Omnimaga website: http://omnimaga.dyndns.org

Disclaimers
===========
-I will not hold responsible for damage caused to your calc.
-You can't use the code for this game without my permission.
-No animals were harmed during the making of this game.