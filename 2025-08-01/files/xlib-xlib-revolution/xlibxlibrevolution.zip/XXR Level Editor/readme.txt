TI-BASIC will never die... and Dance shall live forever...

XLIB XLIB REVOLUTION LEVEL EDITOR
Version 0.2
2005, by K�vin Ouellet, Epic Programming Studio.
Dance Dance Revolution is a property of Konami.

Description
===========
This is the editor you can use to create your own XXR songs. This file includes some info on how to use it.

Installation
============
Send XXREDIT.8xp to your calculator. You need xLIB installed or the editor will not work.

Using the level editor
======================
WARNING: BEFORE USING THE EDITOR, YOU MUST AGREE THAT YOU ARE NOT ALLOWED TO COPY OTHER PEOPLE LEVELS AND BACKGROUND IMAGES. YOU CAN USE THE BACKGORUND IMAGES FROM THE LEVEL SAMPLE INCLUDED WITH THIS GAME (FOR EXAMPLE CREATING A NEW VERSION OF THE SIM FILES) BUT YOU NEED TO GIVE ME CREDITS FOR THEM!!!!!!!

Now start the program XXREDIT. To navigate through the menus press the corresponding number and enter. Now let's start a new file.
-select 0:NEW
-type a name for the song. its 1 to 16 characters. If longer it will be truncated
-choose song speed. 0 is the fastest and 999 is the slowest
-Choose if your song is going to be SE only or not. If its SE only it will go twice faster than normal but it will not work on the regular 83+ model. XXROTFD.8xg (Over the Frail Dream) is one example of SE only files.
-Now you are ready to make your song. You should see the song name at the top of the screen, 3 steps, the lenght of the song (LGHT), which is 95 steps by default, the speed (SPD) which you set up before but that you can change in the editor if you wish and if your level is SE only you'll see a "S" besides the song speed. Use the F1 to F5 keys (Y=, WINDOW, ZOOM, TRACE and GRAPH) to change the steps. Use the up and down arrows to scroll up or down to next or previous step. If you want to scroll faster hold it down for a while. To change the song lenght use the left or right arrow (the sim file can be from 25 to 984 steps long). TO change the song speed from here use the + and - keys. That should be all for song making.

Making song background
======================
Ok now you have a "song"? but what about background? Right now what you have is a default white background the level editor creates when making a new song. Ok this is not that bad but maybe you would want a cool background image instead or even AN ANIMATION!!!! Well what you need to do is to create an image, store it in Pic5, create another one, store it in Pic6, another one in Pic7 and Pic8, thats all. You dont need to draw the top arrows at all, when running XXR they'll be added at the top for you. :)

However there is a problem: the calc draw tools are not the best drawing tools avaliable, you might want to try making your background images on the computer instead. What you need for that is
-A drawing program like MS Paint, Paint Shop Pro or Photofiltre
-Image Studio by Cullen Sauls found at http://www.ticalc.org/archives/files/fileinfo/307/30736.html

Now make a picture with a width of 96 pixels and a height 64 pixels and save it as pic5.bmp . Repeat those steps with pic6.bmp, pic7.bmp and pic8.bmp . (you can give other names for your images but its a good idea to give them picX names so you remember which one has to be converted to pic8, pic7, etc.). Now open Image studio, go in image/image colors/ and select Monochrome (Black & White). Open pic5.bmp, export as Picture. Now select TI-83+ then select Pic5 and click OK. Now save the picture where you want. It will save it as Pic5.8xi. After that repeat the same steps with Pic6, Pic7 and Pic8 . Now select pic5.8xi, pic6.8xi, pic7.8xi and pic8.8xi and send them to your calculator. You should now have your background image or animation ready. :)

Submitting your own levels at ticalc.org
========================================
If you have an account at ticalc.org you can submit your own levels here. However please follow the following guidelines for submitting them!!!

-I recommend grouping all level files together in a group file (8xg). Its optionnal but it makes things easier for those who want to keep 30 levels at once on their calcs. YOU MUST INCLUDE L1.8XL, Pic5.8xi, Pic6.8xi, Pic7.8xi, Pic8.8xi and Str1.8xs
-Once its done put them in a .zip file. Add the xxr prefix at the beginning of the file name. Basically if you  want it called hello.zip call it xxrhello.zip instead. This might make ticalc.org levels archive easier to browse once there are more XXR levels because at the moment the BASIC games level seciton of ticalc.org include levels for every games supporting external levels in their archives. 
-Check again if you included ALL files mentionned above!!!!
-Now in the file upload form make sure you specify in your description this file is for xLIB xLIB revolution or XXR so people know what they are downloading more. 
-Make sure you upload your zip file in the "TI-83/84 Plus BASIC Game Levels" directory! Check if everything is ok and click on the submit button. Then  the file archivers will approve them. Once approved the file wil be located at http://www.ticalc.org/pub/83plus/basic/games/levels/ .

Credits
=======
-Patrick Prendergast for xLIB
-Andree Chea for ZCALCVER
-Konami for making DDR
-Cullen Sauls for Image Studio program
-You for downloading this game

Contact information
===================
E-mail: omnimaga@gmail.com
Omnimaga website: http://omnimaga.dyndns.org	

Disclaimers
===========
-I will not hold responsible for damage caused to your calc.
-You can't use the code for this game and program without my permission. Same goes for songs background images included
-No animals were harmed during the making of this game and program.