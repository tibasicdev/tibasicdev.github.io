Yahtzee!  Created by 7thAce - Version 1.2 Release 2
Inspired by my friend who texted me from Cosco (store) and saw the game.
Thanks for beta testing on the TI-84+ and helping me to get this done in just 5 days!

Changelog:
Version 1.2  - Added labeling to the boxes and fixed up the readme.
Version 1.1  - Fixed anything with If D=E=F=G=H.  Apparantly that doesn't work on some Calcs.
Version 1.01 - Fixed up slight bugs
Version 1.0  - Primary Release

Extra Thanks to:
James Kanjo - Improving the readme, screenshot animation, and suggestions.

To start:
Unarchive all 3 yahtzee programs if they have a star next to them(Yahtzee, Yahtze, Yzanalyz)
Run Yahtzee.
Note that the high score is 309

To play:
Run Yahtzee.
Press enter after it says v1.2 Public
Follow the onscreen directions.
If there is not a specific button to press, press any key.

Yahtzee Graphical User Interface (GUI):
Top bar - Status Bar - Look at this for information of what to do.
Top right box - Score - Displays score
Middle (14 boxes) - Shows which boxes you have used during this game.  See below for more info.
Bottom - Dice - What else would dice do?

Basic controls:
2nd - Rolls dice when prompted
Alpha - Displays tutorial when prompted
Enter - Used for everything except rolling
Arrow keys - Moves "^" for selecting your score
Graph Command Keys (Trace, Y=) - Used to select your holds.
Any key - Used to progress when it is paused (You know it is paused when at the top status bar there only is a message, no "Press this key")

Middle 14 boxes:
Use the arrows to navigate.  They are now labeled if you leave the cursor on a box! v1.2 and up

  1   2   3   4  5  6  YZ
3oak 4oak FH SS LS Chancex2

1 - All the ones are added up
2 - All the twos are added up
Etc.
YZ - Yahtzee!  5 Of A Kind.  Always +50 points regardless of dice values.
3oak - 3 Of a Kind - If you have 3 of a kind, then all your dice will be added together for the score
4oak - 4 Of a Kind - If you have 4 of a kind, then all your dice will be added together for the score
FH - Full House - 3 Of a kind and a pair.  Always +25 points, regardless of dice values.
SS - Small Straight - A straight with 4 numbers in a row (1,2,3,4)    Always +30 points regardless of dice values.
LS - Large Straight - A straight with 5 numbers in a row (1,2,3,4,5)  Always +40 points regardless of dice values.
Chance - There are two spots for this.  Just add all of your dice up for a total.  No restrictions.

Future Updates: High score and better Yahtzee! scoring.

If you find any bugs or Suggestions, post on the TI|BD forums or Email me (7thAce@gmail.com)
Copyright � 2008, 7thAce and the tibasicdev.com project. All rights reserved.
