Yahtzee!  Created by 7thAce - Version 1.0 Release 1
Inspired by my friend who texted me from Cosco (store) and saw the game.
Thanks for beta testing on the TI-84+ and helping me to get this done in just 5 days!

Yahtzee Graphical User Interface (GUI):
Top bar - Status Bar - Look at this for information of what to do.
Top right box - Score - Displays score
Middle (14 boxes) - Shows which boxes you have used during this game.  See below for more info.
Bottom - Dice - What else would dice do?

Basic controls:
2nd - Rolls dice when prompted
Alpha - Displays tutorial when prompted
Enter - Used for everything except rolling
Arrow keys - Moves "^" for selecting your score
Any key - Used to progress when it is paused (You know it is paused when at the top status bar there only is a message, no "Press this key")

Middle 14 boxes:
Use the arrows to navigate.  NOTE: They are currently not labeled 
For easy reference - The boxes are as followed

  1   2   3   4  5  6  YZ
3oak 4oak FH SS LS Chancex2

1 - All the ones are added up
2 - All the twos are added up
Etc.
YZ - Yahtzee!  +50 points
3oak - 3 Of a Kind - If you have 3 of a kind, then all your dice will be added together for the score
4oak - 4 Of a Kind - If you have 4 of a kind, then all your dice will be added together for the score
FH - Full House - 3 Of a kind and a pair  +25 points
SS - Small Straight - A straight with 4 numbers in a row (1,2,3,4)    +30 points
LS - Large Straight - A straight with 5 numbers in a row (1,2,3,4,5)  +40 points
Chance - There are two spots for this.  Just add all of your dice up for a total.  No restrictions.

Future Updates: High score and better Yahtzee! scoring.

If you find any bugs or Suggestions, post on the TI|BD forums or Email me (7thAce@gmail.com)
