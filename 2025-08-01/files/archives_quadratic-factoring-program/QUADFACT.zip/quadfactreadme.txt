Quadratic Factoring Program
--------------------
by Timothy Foster
====================
This program will factor any quadratic from the standard ax^2+bx+c to (ax+b)(cx+d).

This program does not recognize GCF's and you should train yourself to see those.

Ex.  4x^2+8x+4
The program will solve as (4x+4)(x+1), but you should factor out four to make 4(x+1)^2.

The program will recognize prime polynomials.

If the x^2 coefficient is negative, the program multiplies by -1 to all coefficients.  This becomes problematic with expressions.
If you are factoring an expression, please factor out -1 first, and then do it.

Ex. -x^2+4x-4
The program will solve as (x-2)(x-2), but you should factor out -1 to make -(x-2)(x-2).

The program does not factor x^2+2x+1 properly.  Hopefully, you don't need a program to factor that one...

-------------------
INSTRUCTIONS ON USE
===================
The program asks for a, b, and c.  The equation is in the form of ax^2+bx+c=0.
So, a is the first coefficient, b is the second, and c is the third/constant.

Then, the output is givin as a list of four numbers vertcally.

(ax+b)(cx+d)
	1
	2
	3
	4

This interprets as (x+2)(3x+4).  The list goes in order: top to bottom is left to right.

Don't use imaginary numbers

If you have questions, contact Timothy Foster from the Ti-Basic Developer.

--------------
Copyright info
==============
This is not the first quadratic factorer out there, and it doesn't bother me if you apply parts of my code.
Feel free to study and use the code.  Do not copy this program and put it out as your own.