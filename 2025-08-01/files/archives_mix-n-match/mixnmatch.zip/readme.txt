MIX 'N MATCH

A game for the TI-83 calculator by Maarten Janssen in 2009
Contact: maarten@cheerful.nl

This read me file contains some general information about the game Mix 'n Match.


1. HOW TO PLAY
==============
First you should transfer the file MIXNMATCH.83P found in this archive to your calculator and start the program MIXMATCH.

Mix 'n Match is a Bejeweled type of game. You have to match three or more identical tiles horizontally or vertically by flipping two adjacent tiles. Matching tiles will be removed from the board and be replaced by new tiles from the top. This can lead to cascading tile matches, each with a higher score multiplier.

The active tile is indicated by two vertical lines. Use the cursor keys to move the selector. Press 2nd to switch to tile flipping mode. Notice that the cursor will now become a box. Now you can select the tile with which you want to flip by pressing a directional key, or you can press 2nd again to stop flipping.

You can press DEL during the game to return to the menu.
Press CLEAR to quit the game.


2. ABOUT THE GAME
=================
Mix 'n match is written in 100% TI-Basic. It uses some neat tricks to display the beautiful graphics on your calculator. The game requires 3020 bytes to be stored on the calculator and an additional 600 bytes to run, witch will be freed when you quit the game. 

Keep in mind that because this game has been written in TI-Basic it will be slow when checking for matches and cascades. The game does not crash, just wait for a few seconds. Because of this speed limitation the game will not check if there are any valid moves left after a match between tiles.

Feel free to copy this game to anyone who likes it. You are also free to examine how stuff is done by snooping around in the source code. I you want to contact me you can use the address at the top of this read me file.