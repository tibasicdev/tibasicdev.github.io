Asteroids 3 CE v.9.5 ICE
Nick Pease
LAX18 - TIBD
The REAL LAX18 - Cemetech.net
-----------------------------------------------
Contents:
ASTEROID.8xp            Game File (Assembly)
ASTSRC1.8xp              Game File SRc (ICE)
------------------------------------------------
Description:
This game places you as the pilot of a spacecraft
tasked with the task of destroying incomming asteroids.
For every asteroid that you hit you gain a point, for every
asteroid that you miss, you lose a point.

UPDATE: 
- NOW DOES NOT NEED PROGRAM RAND 
- SHOWS LAST SCORE
- RUNS MENU ON EXIT.
------------------------------------------------
Installation:
Copy ASTEROID.8xp to your calculator (or CEmu). Run
ASTEROID.8xp by going to the catelog and selecting Asm(. Paste pgrmASTEROID
in this so it looks like Asm(pgrmASTEROID. Hit enter to play!
------------------------------------------------
Controls:
[<] Move ship left
[>] Move ship right
[Mode] Pause (any key to resume)
[Del] or [Clear] Exit
[^] or [2nd] Shoot

