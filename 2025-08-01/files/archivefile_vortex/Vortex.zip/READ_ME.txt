VORTEX

A Program By Alex Marcolina
Builderboy2005@yahoo.com

Contents of this READ_ME:
I----Introduction
II---Instructions
III--Items and Wepons List
IV---Known Bugs
V----Final Word


-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

I) Introduction

Vortex is a fun, challenging, turn based multiplayer stratagy game. The Object of the Game is to
kill your opponent.  You can go arround collecting boxes of money and use them to buy upgrades, items, and wepons.
The Game also features a random level generator.  Fully MirageOS compatable.

This game was one of my first, and features Basic graphics, and fun gameplay.  It is definetaly one of my best games.

II) Instructions

There are no ingame instructions, so you need to read this!!!

The game is turn based, so player 1 goes first, then hands the calculator to player 2, etc...
in the game, there are five buttons:

Move----You have 2
Dig-----You have 1
Bild----You have 1
Fire----You have 1
Item

to use the buttons, press the button bellow the icon, then use the arrow keys to direct it.
Example: To move, you would pres move, and then use the arrow keys.

MOVE   moves you (Duh)
Dig    digs a wall in front of you
Build  Builds a wall in front of you
Fire   fires a bullet in the direction you choose.  Any wall it hits will be destroyed.
ITEM   brings you to the item menu.  More on that later.
Pressing clear will end your turn and then the other player will go.

There are 10-8 boxes randomly generated on the level.  Each has 10 coins, you use these to buy Items and stuff



III) Item List

This lists the items and wepons and it tells you what they each do.


Super-Wall-------Cost 10---Lets you build and dig an infinite number of alls for one turn.
Stamina----------Cost 20---Gives you two extra moves for 1 turn
Invisible--------Cost 30---Turns you invisible, makes you invincible, and ends your turn.  You become visible after your opponent ends his turn
Trap-------------Cost 20---Use the arrow keys to deploy an invisible trap.  You can die on this too, so beware!
Ammo-------------cost 30---Increases your maximum ammunition count by 1
Breaker----------Cost 40---Gives you one bullet that breaks through 2 extra walls.  (wears out after a turn, so use it imidietly)
Guided-----------Cost 50---Use the arrow keys to direct a missile through the maze.  Can't go through walls
Phaser-----------Cost 60---Instently kills the other player (With cool animation too!)



IV) Known Bugs

There are several known bugs, but the game was released a long time ago, and you shouldn't run into them
unless you are purposely trying to find them.

You when you dig the border, it will let you, and then if you try to move out through the hole or 
shoot again, you will get an error.

Also, if you dig or shoot the bottom border, you can them ove inside it, but you most likely will get stuck.

if you fire a breaker at the bordering wall, you will get an error.

if you place a trap on your opponent who is right next to you, you will die instead

if you walk past your opponent, he will disapear and become invincable for one turn




Final Word

Although slightly buggy, the bugs do not interfere with the gameplay, and the 8 unique items
make for interesting and challenging gameplay.  hopefully you
and your friends will have a fun time playing this.

Comments and criticisms go to Builderboy2005@yahoo.com
Alex marcolina