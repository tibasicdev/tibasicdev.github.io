GeometryCE
by Trent Knight
Released May 9, 2017
----------------------------------------------

Requirements: TI-84 Plus CE

Installation: Move GEOMETRY.8xp and ZINVERSE.8xp 
	      to your calculator using TI Connect

Running:      Press the prgm key and select GEOMETRY

Credits:      Thanks to all the people on 
              tibasicdev.wikidot.com that helped me
              fix any problems I had

Feedback:     If you notice any bugs or have any other 
              kind of feedback please send them to me 
              at trentknight56@gmail.com