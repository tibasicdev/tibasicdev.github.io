Gladiator Fight for TI-83+ calculators
by SpaceManiac
(c) SpaceManiac 2009

A multiplayer turn-based strategy game in which 2-9 players compete for ultimate supremacy in a gladiator battle!

Rules of the game:
1. If you shoot someone, they will get hurt, unless
   a) they shot themself, in which case you will get hurt instead
   b) they are dead, in which case you must choose someone else to shoot
2. If you shoot yourself, you will get hurt, unless
   a) someone else shot you, in which case they will get hurt instead
3. Last player alive wins!