Source Seekers:
Source Seekers is a dungeon crawler-type RPG with action and puzzle elements.
A few things to keep in mind, though:
1. The sword only attacks to the right, and 1 "square" in front of you.
2. The magic is the opposite: To the left, and 2 squares behind you.
3. Saving = quitting.
4. If you get a bug, go to this topic and/or PM me (123outerme) on Omnimaga: http://www.omnimaga.org/ti-z80-calculator-projects/(to-be-named)-dungeon-crawlercollection-game/
5. Objects can't be "destroyed" with the sword, but may disappear. Only attack an "S", "O", "P", "H", or "M".