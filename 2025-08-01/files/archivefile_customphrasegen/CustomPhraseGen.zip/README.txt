Customizable Phrase Generator v2.0 by Michael2_3B
--------------------------------------------------
This program will generate a random phrase for you! It is very customizable, as you can add vocab and different sentence structures.

<<Usage>>
-The first time you run it, you will be prompted to choose to use pre-existing vocab (including 1 sentence structure) or you can create your own custom set. You can go back to this menu whenever you want by resetting (option 4 in the Main Menu).
-Adding vocab involves selecting which part of speech your vocab word is from, then typing in your word. You can add multiple words at once, however it is not possible to enter vocab that is more than one word and intended to be together. There are certain characters you cannot use, so the program will tell you when you have used one.
-Adding a sentence structure involves typing in the order of your structure, using number keys 1-8. You can backspace by pressing [DEL], and you can cancel by pressing [CLEAR].
-You can reset the program by selecting "Reset" in the Main Menu. This will clear all vocabulary and delete all sentence structures.

<<Features>>
-You can use (and add to) pre-existing vocab and sentence structures, or you can create your own custom vocab and sentence structures.
-You can generate a random phrase, which is made up by a random sentence structure that you have previously entered, and vocab you have previously entered.
-You can add vocabulary to any of the 8 parts of speech.
-You can add sentence structures.

You can keep a generated phrase by exiting the program DIRECTLY after generation, and calling Str9.

<<Known Bugs>>
-If you have at least 1 sentence structure, but don't have any vocab, it will crash when you try to generate a new phrase.
-If any of the parts of speech contained in your sentence structure don't have vocab words, it will crash when you try to generate a new phrase.



Please feel free to pm me (Michael2_3B) on cemetech.net if you have find any other bugs or if you have a suggestion, comment, or question.

Program is unlocked, so any changes are your responsibility.

Copyright (c) 2015 Michael2_3B

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.