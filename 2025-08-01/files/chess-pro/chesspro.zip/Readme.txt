Chess Pro! v2.2
Send feedback to <francishuang@hotmail.com>

1) Keys
2) Features
3) Freeing up RAM
4) Typing in Program by Hand
5) To Do
6) Acknowledgements

Welcome to Chess Pro!  Those with link cables should
send the Chesspro.83g file directly to their calculator.
See section 4) if you do not have a graph link.

1) KEYS:
[DEL]   - Main Menu
[ENTER] - Select (Also can use 2nd)
[GRAPH] - Quick Exit
Arrows  - Move cursor.

*Note: you can press the arrows quickly without waiting
for the cursor to catch up - it will eventually
get there.

2) Features
-3 save slots with customized names (each 10 letters
     long max)
-1 Autosave slot to avoid having to pick the last game
     ou saved from a list.  Saves on exit so if the
     teacher comes and you hit [GRAPH], you can
     continue the game again by choosing
     [CONTINUE LAST] from the intro menu.
-All move checking except to see if the king is in
     check, which speeds up the program. Semi-Auto
     castling by moving the king over two squares.
     The game ends upon capturing of the king. Pawns
     are promoted when necessary.
-Good graphics of pieces and background
-No intro screens to bother with
-Does not eat up half of your RAM like other chess programs
     (7K with Pics and no savegames)
-Option to create missing Pic6, Pic9, and Str9 in case
     they were deleted.  These are located in the intro
     menu.
-Fast cursor movement (see note about Arrows in the
     KEYS section above)
-Cursor switches to the king-pawn of the side to move

3) Freeing up RAM
   ��������������
   If you need to free up some ram to run some other
games, here are some procedures that are useful.
   To temporarily free up memory, delete the [G] and
\L\TMP files. They will be created again the next time
you play a game, but you will not be able to choose
[CONTINUE LAST] from the intro menu since this deletes
the autosaved game.
   If you really need memory, delete Pic6, Pic9,
\L\CHS, Str9, matrices [H] through [J], if they exist,
and \L\CH1 through \L\CH3, if they exist.  The next
time you run the program, choose [4:REPAIR ALL] from the
intro menu.
   Note that *ALL SAVED GAMES WILL BE LOST* from the
second method above.

Description of external files:
   Pic6, Pic9 = Pictures needed for game
   \L\CHS, \L\TMP, \L\CH1 to \L\CH3 = Various savegame
     data.
   [G]-[J] = Place game boards are saved to

4) Typing in the Program by Hand
   �����������������������������
   There is only need to type in the program by hand if
no link cable is available.  First, get Winlink from
http://education.ti.com/product/accessory/link/down/linkwin.html
After installing the program, go to the [Tools] [Ungroup]
option.  Choose chesspro.83g and ungroup it.  Open the
Chesspro.83p file from [File] [Open].  Eventually, all
of the files ending in .83p will need to be typed in.
   To start a new program on the ti-83, press [PRGM]
[Arrow over to NEW] [Enter].  For the name, type in
CHESSPRO.   Start typing in the program as it appears
in the Winlink window.  For help in typing in the
symbols, see Symbols.txt.  Type in all of the files
ending in .83p into the calculator.  Do not try to
enter the lists, strings, or pictures, since they will
be created automatically.  If you encounter any errors,
make sure the program is entered exactly as written.
E-mail me at <francishuang@hotmail.com> for more help.
   The first time you run the program, it will create
Pic6, Pic9, and Str9.  In case these files are deleted,
create them again from the intro
menu options [4:REPAIR ALL].

5) To do
-undo of moves

6) Acknowledgements
I would like to  thank Marshall Duer-Balkind for his
    comments and a bit of friendly competition =)
Thinkmaster for finding king-move bug
ASimPerson@aol.com for TI83+ Pic6 and Pic9 help


For questions or suggestions, send me an email to
<francishuang@hotmail.com>