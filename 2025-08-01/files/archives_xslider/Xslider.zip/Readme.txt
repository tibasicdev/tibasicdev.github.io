Xslider is based off of 15 square but you can generate any size box between 2-5 for the length and 2-7 for the width.Once it is done shuffling you control it with the arrow keys and you go to the piece you would like to move and press 2nd and it will move to the open square.To win you get all the pieces in numerical order with the space at the bottom right corner.Email noah.fencer@gmail.com if you find any bugs.
Credits----
Me
Ed H for the shuffling