REUBEN QUEST: THE LOST MIRROR
Version 1.00, programmed by K�vin Ouellet, (c) 2005. 
Reuben Quest: The Lost Mirror and Reuben Quest: The Lost Mirror logo 
are property of Omnimaga and Epic Programming Studio. 
ASM libraries used in this program are property of their respective owners.

Introduction
Installing and running the game
Story
Controls
Items and shopping
Battles
Menu
Some advices
Bugs
Frequently asked questions
Acknowledgements
Disclaimers
Contact
Website links



Introduction

First of all, thanks for downloading this! Reuben Quest: The Lost Mirror is the sequel to Reuben Quest: Ev Awakening. It's a game that is quite hard to classify due to it's variety. I like to say it's a puzzle game because you have to explore to find items and interact with the environnement (push blocks, cut plants, destroy rocks, etc.) to advance in your quest and sometimes you have to solve riddles. Sometimes, you may have to explore at the same place for a while to figure out that something actually do something :). However, I also like to say that it's a RPG too because as you wander around you have to fight powerful creatures to get strong enough to face more powerful foes and you can interact with NPCs (non-player characters) to get clues. So basicaly it's should be classified as a puzzle-RPG :), which will satisfy people regardless of if they like puzzle or role-playing game! This sequel includes everything that the original game had to offer like the flickerless grayscale graphics and the many secrets plus new stuff like more complex puzzles, more monsters, many plot twists, viewing inside houses, cutting plants, pushing blocks, destroy blocks and more! All you need is a TI-83+ Silver Edition, a TI-84+ or a TI-84+ Silver Edition calculator (for speed a regular 83+ isn't recommended) with all your RAM and 120 KB of archive memory then you just have to sit down to enter another world filled with surprises, mysteries, challenges and revolutionnary graphics.

Installing and running the game

IMPORTANT NOTE BEFORE INSTALLING THE GAME: Due to compatibility problems between TI-Connect and hacked pic files, The Lost Mirror now uses an installation procedure that is different (and longer) than with Ev Awakening. Those picture are now sent as normal Pic0.8xi through Pic9.8xi files to your calculator then converted into hacked pictures by running a program on the calc. This will take a bit longer but it will ensure TI-Connect compatibility with this game. Now follow the installation steps carefully. If during the installing it ask to Garbage Collect please choose yes!!!

1) First of all reset your RAM. Make sure you have enough archive memory (at least 120 KB).
2) In TI-Connect Device Exploder or TI-Graph-Link locate  ''files/RAM/Part 1'' folder and send the file to your calculator RAM.
3) Go in the PRGM menu, select INSTALL and hit ENTER twice. The screen will come blank. After a while a weird picture will appear. Wait until it dissapear then reset your RAM.
4) Locate "files/archive/Part 1" folder, select Omnicalc.8xk and send it (check TI-Connect or TI-Graph Link help file for info on how to send Flash APPS to your calc).
5) Once it's sent to your calculator, press the APPS key then select Omnicalc. Press any key to clear the splash screen and when the main menu appears, choose "1: Install/Uninstall". If it ask to overwrite hooks, press Y= to choose yes. Now Omnicalc should be installed.
6) Locate "files/archive/part 2" folder on your computer and send the files to your calculator ARCHIVE memory.
7) Locate "files/RAM/part 2" folder and send the file to your calculator RAM.
8) To play the game open the PRGM menu. select AREUBEN and press ENTER twice.
9) When this screen is displayed press any key except ON.
10) Now adjust your contrast if it's too light or too dark and start a new game or a saved game.

IMPORTANT NOTE TO GAMERS: Because this game never needs to write data into the Flash ROM (archived programs are copied in the RAM in order to be ran), it will require A LOT of RAM during execution. Due to the fact that each archived programs/group/variables names takes at least 12 KB of RAM, if you have too many files not related to Reuben Quest: The Lost Mirror on your calc this may result into ERR:MEMORYs. Make sure you only have a few files on your calc before installing the game.

Story

After Reuben defeated the Evil Knight Ev, peace returned back on the island. But one night, Reuben saw a light coming from Ev Palace and heard an horrible scream calling for his help. He suddently woke up and discovered that it was a dream. Next morning a rumor was talking about a knight who went through a mirror, which left him with more questions than awnsers. Was it really a dream? Is the evil knight still alive? What is the mirror told in the rumor? Where is it located? What lies behind it?

The only thing he knew is that his quest was about to begin once again...

Controls

Title screen
-Any key except ON: open main menu
-ON/CLEAR: Exit game

Main menu
-Arrows: Change contrast (to make sure that everyone can see grayscale properly on all calculator models)
-ALPHA: New game
-2nd: Load game
-ON/CLEAR: Exit game

During walking
-Arrows: Move Reuben. To look at or take something, talk to someone, push a block, cut plants or open a door, just walk into it.
-2nd: Open menu
-ON/CLEAR: Exit game

During talking
-Any key except ON: Continue to next part of text or close text box.
-ON: Exit game

During shopping
-Digits (1,2,3,4): Choose item to buy and the bottle to put the item in
-Any other key except ON: Exit shop
-ON: Exit game

During Battles
-Arrows: choose battle commands.
-Digits (1,2,3,4): When the item menu is open choose an item to use
-Any key except arrows and ON: cancel magic selection.
-ON: Exit game

In game menu
-Digits (1, 2, 3 and 4): Use items in bottles
-2nd: Exit menu
-ON/CLEAR: Exit game
Items and shopping

In The Lost Mirror there is more items avaliable than in Ev Awakening but most of them are not free. When you enter a shop a menu with the items avaliable to buy will show up.
Choose an item you can afford by pressing the corresponding number key.
Now choose a bottle to put the item in. If you want to cancel, press any key that is not 1, 2, 3, 4 or ON.
That's it. Here is a list of items found in Reuben Quest: The Lost Mirror.
-Water: Restore 300 HP
-Herb: Restore 600 HP
-Potion: Restore all HP
-Gigseng: Restore 50 MP
-Elixir: Restore all HP and MP
-Fire: Cause twice as much damage than the fire magic
-Pure: Cure poison
-Bottle: Allow you to stock water, herb, potion, gigseng, elixir, fire or pure item. There is a total of 4 bottles in the game.
-Gloves: Allow you to push blocks (much like those in Zelda):
-Swim Suit: Allow you to walk in less deeper water area (those in gray):
-Hammer: Allow you to break rocks:

Battles

When you walk or trigger special events, you may be engaged into a battle. Be prepared. Depending of your LV, monsters will sometimes attack first. When it's your turn an attack pad will appear in the screen (much like Lufia for the SNES). Use arrows to choose commands. 
The left icon allow you to attack, the upper one allow you to use magic (requires 5 MP), the lower one allow you to use items in your bottles (if you have a bottle with an item inside) and the right one allow you to escape. Escaping only work half of the time and you cannot escape from boss fights. Here is a quick description of each battle commands:

-Attack: Attack normally
-Magic: Use magic (open a new attack pad)
	Fire (lower icon): Do fire damage
	Ice (upper icon): Do ice damage
	Bolt (right icon): Do bolt damage
	Cure (left icon): Restore some HP
-Items: Open a window prompting you to choose the content of one of your bottles and use it.
-Escape: Can escape from battle

Note that offensive magic do the same amount of damage than normal attacks, but depending of monsters weaknesses, they can do less or more damage. When you win a battle you get money and experience points (to view how many you gained go in the menu). When you reach a certain amount you level up.
Menu

During walking, press 2nd to bring the menu. 
Here you can view and use your items, your equipement, your money, your status (LV/HP/MP/Experience) and the area you are in. 

Note about items: when you have something inside a bottle only the name of the item inside the bottle will be displayed. Press the number key corresponding to one of the bottles to use it.


Some advices

-Always keep an eye on your HP... and your teachers :).
-If you go in a dungeon and feel that monsters attacks are too strong, just wander outside and fight weaker creatures to get stronger.
-Look everywhere when you explore. The South Island in RQ: The Lost Mirror hide a lot more puzzle and stuff than Reuben Island in RQ: Ev Awakening!
-Use your item and money wisely. In the first game everything was free, but in this sequel (almost) everything has a price and you can only carry 4 items at once. Also be careful when you catch water in a bottle or buy an item in shops: if you put the item in a bottle that alerady have an item inside the old item is lost.
-Save often! You don't know what's ahead. To save your game stand in front of a goodness.
Make sure you don't modify or delete RQSA2 list or you will restart from the beginning the next time you load your game.

Bugs

As far as I know there is no error in the game but there is one little thing you might notice while playing: When you push blocks, cut plants and/or destroy rocks in an area, exit that area then go back in it, all the blocks/plants/rocks will reappear to their original locations. Entering a battle will also do the same thing. What it means is that if you stand where a block/plant/rock was, you will reappear on it after the battle. This is unfixable due to lack of RAM space but it should not cause any problems.

Frequently asked questions

Q: Would the game works on the regular 83+?
A: Yes. Of course it's slower and grayscale doesn't look as good as on the SE but this game runs a bit faster than the original Reuben Quest so it might be bearable. Also the game will not crash, so you can play without any problem. However keep in mind that you will need all of the calculator memory.

Q: I can't believe it! Is it really in BASIC?
A: Yes, but because of grayscale interrupts, about 60% of the program execution is done by ASM programs but those programs are only 15% of the whole game.

Q: So this should be considered as an ASM game since it uses ASM?
A: Not necessarly, as the ASM libraries are external. Also I didn't do any ASM coding while making this game.

Q: What are the hacked pictures you talk about in the installation procedure? And why they aren't compatible with TI-Connect?
A: The hacked pictures are the same things than normal pictures, but their names are not recgonized by the calculator OS so instead of Pic11 for example it will display GBD7. Also they must be created by using a small program known as DevPic (found at ticalc.org). This allow programmers to have up to 40 pictures in their BASIC games. The reason why they aren't compatible with TI-Connect is because this software is not smart enough to know the existence of assembly programming :).

Q: Are there any cheats for this game?
A: No, this would have made the game too easy. You can check the advice section of this text but there is no code or walkthrough avaliable (*cough*thismighthelptoo*cough*)

Q: How long did you take to make this game?
A: Devellopement started in December 15th 2004 and ended in January 15th 2005. So basically it took me one month.

Q: My question isn't really related to this game in particular, but how much time did you spent in finding out how to make grayscale in BASIC?
A: A bit less than 3 seconds :). In fact, in the evening of November 20th 2004, as I was messing around with the new Play( command in Omnicalc, a BASIC grayscale trick suddently came into my head (I didn't need to spend any time on how to find out how to do it). Next morning I made two picture then made a walking loop with many Sprite( commands. When I saw the result, I thought: "TI-BASIC is now different from what it was yesterday."

Q: How can I program games like this in BASIC?
A: Check my Guide to TI-83+ Silver Edition BASIC Grayscale at ticalc.org. It contains everything you need to start up.
Acknowledgements

-Detacheds Solutions for Omnicalc application. Without their hard work TI-83+SE/84+/SE grayscale would never have been possible in TI-BASIC!
-Patrick Prendergast for xLIB
-Kevtiva Interactive for Flash Gordon, DevPic and Zpic
-BAPG for DevPic
-Michael Vincent for BASIC Tools programs (and Omnicalc)
-Everyone at Epic Programming Studio!
-Square-Enix because I borrowed some monster sprites from Final Fantasy II, III and Dragon Warrior IV.
-Taito because I did the same thing with Lufia And The Forteress of Doom
-Nintendo because I did it too with Metroid and Zelda: Link Awakening
-And everybody I forgot to mention :)

Disclaimers

-You may look at the code, but you may not steal it or modify it and release this game as your own. If you want to use some part of code in your games, please give me some credits... and make sure it's a GOOD game :).
-I will not held responsible for any damage caused to your calc.

Contact

If you have any comment/suggestions/feedback/bug reports, e-mail me at omnimaga@gmail.com . For faster reply you can also ask on the forums here: http://omnimaga.dyndns.org/index.php?showforum=58

Website links

-http://omnimaga.dyndns.org