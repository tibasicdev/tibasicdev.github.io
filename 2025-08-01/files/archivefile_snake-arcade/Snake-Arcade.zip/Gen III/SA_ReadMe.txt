  _____             _                                     _      
 / ____|           | |            /\                     | |     
| (___  _ __   __ _| | _____     /  \   _ __ ___ __ _  __| | ___ 
 \___ \| '_ \ / _` | |/ / _ \   / /\ \ | '__/ __/ _` |/ _` |/ _ \
 ____) | | | | (_| |   <  __/  / ____ \| | | (_| (_| | (_| |  __/
|_____/|_| |_|\__,_|_|\_\___| /_/    \_\_|  \___\__,_|\__,_|\___|
=========================================================================================================
It's here! The game everybody has been waiting for! Well, nobody knew this game even existed till right
now. But anyways, let's begin. Snake Arcade is a game for the TI-84 Plus Family (Excluding the CE and CSE
models). This game also uses libraries, to improve graphics, speed, and... other stuff. This game is
special in it's own ways, because of the features built in the program. This game includes four different
game modes to play, so you don't get tired of playing one little snake game over, and over, and over
again. I am truly excited to release this game to everyone, I hope everyone will enjpy this program.

  _____                        __  __           _           
 / ____|                      |  \/  |         | |          
| |  __  __ _ _ __ ___   ___  | \  / | ___   __| | ___  ___ 
| | |_ |/ _` | '_ ` _ \ / _ \ | |\/| |/ _ \ / _` |/ _ \/ __|
| |__| | (_| | | | | | |  __/ | |  | | (_) | (_| |  __/\__ \
 \_____|\__,_|_| |_| |_|\___| |_|  |_|\___/ \__,_|\___||___/
                                                            
There are four different game modes for this game, which are:

Program Release Information: (This will possibly be the Read Me) The Celtic III game Snake Arcade will be released for the TI-84 Plus Family around July 4th, 2019. This game is like no other; because of the 4 built-in game modes, which are:

- Normal snake: A simple snake game on the home screen where you have to eat the *'s and the snake grows longer and longer. You may go past the wall boundries, the only way you die is by pressing CLEAR or running into yourself.

- Demented Snake: Similar to the game above, but the snake display is very… glitched and you constantly have to change your direction to keep the snake moving fast.

- Space Snake: You are in space and you have to guide the snake to fly inside the astroids (= signs) to get points. Crash into a pixel and it's game over.

- Nibbles: A very graphical, and fast snake game. Guide your snake to get all pieces of food that appears around the screen. The 3 ways you can die is crashing either into a wall, or yourself, or by pressing CLEAR.

*****Authors of these programs will be shown in the disclaimer.*****

 _______ _             _____ _                 
|__   __| |           / ____| |                
   | |  | |__   ___  | (___ | |_ ___  _ __ ___ 
   | |  | '_ \ / _ \  \___ \| __/ _ \| '__/ _ \
   | |  | | | |  __/  ____) | || (_) | | |  __/
   |_|  |_| |_|\___| |_____/ \__\___/|_|  \___|

The Store is a place where you buy things for your snake. The in-game currency is Gold, where it is a type of money that you use to purchase things. When you boot up the store, you will see the amount of apples and the amount of gold you have. Gold is the in-game currency, where you can buy skins for your snake. The
Apples are a secondary currency where you use these to revive your snake in the Space Snake game mode. If you crash into an
astroid, you may use apples to continue playing if you die. You can buy 20 different skins and food for your snake, if you
have enough gold. But don't worry, Gold can be easily earned by playing the games and selling unwanted skins.

If you buy a skin you didn't want on accident, press ALPHA to sell that skin.

If you want to sell ALL skins (not the defaults), press MATH to sell all of them at once.

You can also exchange between apples and gold. One apple is equal to ten gold. Press the left key to get more gold, and press
the right key to get more apples.

If you're one of those people who keep their time and date correct on your calculator, great! On Fridays, Saturdays, and
Sundays, all items in the Store are 30% off. Useful for getting hands a skin or two that you really want.

TIP: If you buy lot's of expensive skins during the sale, and sell them once the sale ends, you can get a good amount of gold.

  _____                              _             
 / ____|                            | |            
| |  __  __ _ _ __ ___   ___   _ __ | | __ _ _   _ 
| | |_ |/ _` | '_ ` _ \ / _ \ | '_ \| |/ _` | | | |
| |__| | (_| | | | | | |  __/ | |_) | | (_| | |_| |
 \_____|\__,_|_| |_| |_|\___| | .__/|_|\__,_|\__, |
                              | |             __/ |
                              |_|            |___/ 
                
Normal mode: Use the arrow keys to change the direction of your snake, and eat the food that
appears on the screen. You die by either pressing clear, running into yourself, or by pressing right while going left, pressing left while going right, and vice versa.

Dimented mode: This mode is kinda trippy, because how hard it is to control the snake. You constantly have to change direction
with the arrow keys to keep the snake moving fast. The longer the snake, the better control you have. But in this mode, there
is a small... catch. In this mode, technically you can't "die"... so I added a 2-minute time limit to eat as much food as
possible in 120 seconds.

Space mode: You are in space... and you need to guide the snake to go inside the = signs to get points. In a normal = sign, it
is worth 3 points. Keep an eye out for longer ones, as they are worth more points. Don't dilly-dally however, being idle in
this mode can lead to crashing your snake... Just make sure you have apples to spare in case you die.......

Nibbles mode: The very graphical and fast snake game. Same rules as the normal mode, but you can't run into the walls. You
won't appear on the other side... so don't even bother attempting.

 _    _ _       _        _____                         
| |  | (_)     | |      / ____|                        
| |__| |_  __ _| |__   | (___   ___ ___  _ __ ___  ___ 
|  __  | |/ _` | '_ \   \___ \ / __/ _ \| '__/ _ \/ __|
| |  | | | (_| | | | |  ____) | (_| (_) | | |  __/\__ \
|_|  |_|_|\__, |_| |_| |_____/ \___\___/|_|  \___||___/
           __/ |                                       
          |___/                                        

In each mode, there is a high score system coded in the game. Each mode has a top-5 list, so try to beat those scores and
show your friends! In the High Scores option in the main menu, it will also tell you the mean score for the list. If you don't 
understand that word "mean", it's just the average score for the scores. That means to add up all the numbers and divide
by the amount of numbers there are. If your score at the end of the game makes it on the top 5, you get a gold reward
depending on the mode you played. The game modes are ranging from easiest to most difficult: Space Snake, Nibbles, Normal,
and Dimented.

__   _______                    _   _                    _     
\ \ / /  __ \                  | | | |                  | |    
 \ V /| |__) |   __ _ _ __   __| | | |     _____   _____| |___ 
  > < |  ___/   / _` | '_ \ / _` | | |    / _ \ \ / / _ \ / __|
 / . \| |      | (_| | | | | (_| | | |___|  __/\ V /  __/ \__ \
/_/ \_\_|       \__,_|_| |_|\__,_| |______\___| \_/ \___|_|___/

After each mode, you get a certain amount of expierence points based on what your score is. For Space Snake, you only get 30%
of your original score because if you have enough apples and play long enough, you can get a pretty big score...
But anyways, you start at level 1. To upgrade to the next level, you need 25 XP to upgrade to level 2. You get a gold reward
by upgrading levels. (3*[the level you upgraded to])

This feature is the same in Fly the Copter II game I made, but with more features and faster processing. I have not implemented a maximum score, as it is hard to reach Level 999.

__      ___               _               _____        _        
\ \    / (_)             (_)             |  __ \      | |       
 \ \  / / _  _____      ___ _ __   __ _  | |  | | __ _| |_ __ _ 
  \ \/ / | |/ _ \ \ /\ / / | '_ \ / _` | | |  | |/ _` | __/ _` |
   \  /  | |  __/\ V  V /| | | | | (_| | | |__| | (_| | || (_| |
    \/   |_|\___| \_/\_/ |_|_| |_|\__, | |_____/ \__,_|\__\__,_|
                                   __/ |                        
                                  |___/                         

You can view your data in the main menu. You are able to see the amount of gold and apples you have, the selected skin and
food with the amount you have for both of them, your level, the XP and needed XP to upgrade, and a progress bar.

  _____          _                  _          _   _             
 / ____|        | |                (_)        | | (_)            
| |    _   _ ___| |_ ___  _ __ ___  _ ______ _| |_ _  ___  _ __  
| |   | | | / __| __/ _ \| '_ ` _ \| |_  / _` | __| |/ _ \| '_ \ 
| |___| |_| \__ \ || (_) | | | | | | |/ / (_| | |_| | (_) | | | |
 \_____\__,_|___/\__\___/|_| |_| |_|_/___\__,_|\__|_|\___/|_| |_|

You can change different settings in the game if you don't like factory defaults. You are able to change the skin and food for the first two modes (Only if you purchased them, if they do not have any uses left- you can't select them). You are also able to set the contrast for the game and the TI-OS. You cannot set the contrast below 10 because it can get really dim and you
can't see anything. You are able to toggle the run indicator on or off, if you like to see games being run the old fashion
way with the run indicator. You can choose if you want to archive the save data on exit or not, but this is HIGHLY
RECOMMENDED that you keep it on YES, in case of a crash or a RAM clear. You can also confirm to save on exit, if you made accidental changes to the game you don't want to save. You can also perfom update checks to see if there is updates to the program. This check DOES NOT connect to the internet and go to the source for the file and compare versions of the file on the
archive(s) and the file itself. It refers to an app var that contains the game code. You can also change the username for the
game. After you register (See Registering 5 sections below) the default username is SNAKES (Inspired by the Home Alone "Snakes" name reference), you can change it to whatever you want. Just keep in mind as a side note that you can have a maximum
of 10 characters. Press 3 to type an underscore.

 _    _           _       _   _             
| |  | |         | |     | | (_)            
| |  | |_ __   __| | __ _| |_ _ _ __   __ _ 
| |  | | '_ \ / _` |/ _` | __| | '_ \ / _` |
| |__| | |_) | (_| | (_| | |_| | | | | (_| |
 \____/| .__/ \__,_|\__,_|\__|_|_| |_|\__, |
       | |                             __/ |
       |_|                            |___/ 

This part of the program is unique, because I wanted to do an update process like other games on different consoles. So, instead of putting the program itself in the zip archive folder, I saved the code to an appvar, and made a seperate
program that copies the programming to the SNKEARC program. You MUST use this program to update or install the game code
if you want to play. Yes, I know this is a bigger pain in the rear instead of sending the files the traditional way. To update,
use the SNKEARUP program to update or install the code. If you have a previous version of the program already installed on your
calculator, the program will confirm to update the program. WARNING: If I make big changes to the game, I can change how the
game saves and reads data, and the save data may not be supported in the newer version, so be cautious about updating! Also,
this is a pretty big program, so it can take a while to update. Keep those batteries good and don't press the ON button. Or you
will have to do the entire process all over again.

 ____             _    _                              _____           _             _             
|  _ \           | |  (_)                            |  __ \         | |           (_)            
| |_) | __ _  ___| | ___ _ __   __ _   _   _ _ __    | |__) |___  ___| |_ ___  _ __ _ _ __   __ _ 
|  _ < / _` |/ __| |/ / | '_ \ / _` | | | | | '_ \   |  _  // _ \/ __| __/ _ \| '__| | '_ \ / _` |
| |_) | (_| | (__|   <| | | | | (_| | | |_| | |_) |  | | \ \  __/\__ \ || (_) | |  | | | | | (_| |
|____/ \__,_|\___|_|\_\_|_| |_|\__, |  \__,_| .__( ) |_|  \_\___||___/\__\___/|_|  |_|_| |_|\__, |
                                __/ |       | |  |/                                          __/ |
                               |___/        |_|                                             |___/ 

You can back up and restore save data for this program. Use the SNKARCBU program to do either. There is a useful feature
where it tells the user of when the data was last backed up (i.e. 19H ago).

If you don't understand TI-BASIC programming, skip this paragraph. This is how it checks because the startTmr command value is stored on the 11th line in the app var save data. When you boot the program, the program saves that value and it checks how long ago it was saved. Consider this code:

expr(det(5,Str8,11->T  ;Reads the 11th line of the Back up app var and and stores it's value to T.
	If T>startTmr:Then  ;Checks to see if T is greater than the startTmr value.
		Text(45,2,"INVALID TIME STAMP!
	Else
		checkTmr(T->S
		det(1,Ans)+"S  ;det(1,...) converts any real number/variable to a string. Just like the toString() command for the CE.
		If S>59
		det(1,int(S/60))+"M
		If S>3599
		det(1,int(S/3600))+"H
		If S>86399
		det(1,int(S/86400))+"D
		Text(45,2,Ans," AGO                           
	End

You can only back up data if a user is registered, else the back up will fail. You can only restore data if you have a back up
data saved, else the restoration will fail.

  _____                          _   _               _____        _        
 / ____|                        | | (_)             |  __ \      | |       
| |     ___  _ ____   _____ _ __| |_ _ _ __   __ _  | |  | | __ _| |_ __ _ 
| |    / _ \| '_ \ \ / / _ \ '__| __| | '_ \ / _` | | |  | |/ _` | __/ _` |
| |___| (_) | | | \ V /  __/ |  | |_| | | | | (_| | | |__| | (_| | || (_| |
 \_____\___/|_| |_|\_/ \___|_|   \__|_|_| |_|\__, | |_____/ \__,_|\__\__,_|
                                              __/ |                        
                                             |___/              

This neat little program I coded allows you to convert save data between Gen 2 Snake Arcade and Generation 3. Use the SNKETRAN
program to trasfer save data between generations.

 _    _     _               _____  _      _____ 
| |  | |   (_)             |  __ \| |    / ____|
| |  | |___ _ _ __   __ _  | |  | | |   | |     
| |  | / __| | '_ \ / _` | | |  | | |   | |     
| |__| \__ \ | | | | (_| | | |__| | |___| |____ 
 \____/|___/_|_| |_|\__, | |_____/|______\_____|
                     __/ |                      
                    |___/                       

Using DLC data was originally made for Generation 2... but as nice as I am, I made a program to use it for Generation 3.
SIDE NOTE: IF the DLC data does exist on the calculator, you have 3 choices: to use it on Generation 2., use it on
Generation 3, or don't use it at all. You can use the data ONCE on either version, so choose carefully. But... there is a
loophole to this. Want to know what it is? Guess this code and reveal the answer:

	Hfvat gur FAXRGENA cebtenz gb pbaireg gur TraVV fnir qngn gung gur QYP gung jnf hfrq, lbh pna pbaireg gung qngn gb n TraVVV fnir qngn, znxvat vg cbffvoyr gb hfr gur QYP ba OBGU irefvbaf.

 _____            _     _            _             
|  __ \          (_)   | |          (_)            
| |__) |___  __ _ _ ___| |_ ___ _ __ _ _ __   __ _ 
|  _  // _ \/ _` | / __| __/ _ \ '__| | '_ \ / _` |
| | \ \  __/ (_| | \__ \ ||  __/ |  | | | | | (_| |
|_|  \_\___|\__, |_|___/\__\___|_|  |_|_| |_|\__, |
             __/ |                            __/ |
            |___/                            |___/ 

Registering for the game is easy as riding a bike! If.. you CAN ride one. But anyways, run the SNKAREG3 program to register a
user.

  _____             _                               _   _                     _ _             
 / ____|           (_)                             | | | |                   | (_)            
| (___   __ ___   ___ _ __   __ _    __ _ _ __   __| | | |     ___   __ _  __| |_ _ __   __ _ 
 \___ \ / _` \ \ / / | '_ \ / _` |  / _` | '_ \ / _` | | |    / _ \ / _` |/ _` | | '_ \ / _` |
 ____) | (_| |\ V /| | | | | (_| | | (_| | | | | (_| | | |___| (_) | (_| | (_| | | | | | (_| |
|_____/ \__,_| \_/ |_|_| |_|\__, |  \__,_|_| |_|\__,_| |______\___/ \__,_|\__,_|_|_| |_|\__, |
                             __/ |                                                       __/ |
                            |___/                                                       |___/ 

The game save data is stored into an App var called SnakeARC. The size is about a mere 375 bytes, so doesn't take a whole lot
of memory. The save data is compiled to hexadecimal, so it's just a mess if you try edit the data. I highly recommend you
DO NOT edit the data (if you get smart with Celtic 3), unless you want your game permanently corrupted. When the game loads
the data, it decompiles it and stores it to 10 different lists (wheeze). When the game saves the data, it compiles the lists
to hexadecimal again so it can't be tampered easily.

 _    _ _     _                   
| |  | (_)   | |                  
| |__| |_ ___| |_ ___  _ __ _   _ 
|  __  | / __| __/ _ \| '__| | | |
| |  | | \__ \ || (_) | |  | |_| |
|_|  |_|_|___/\__\___/|_|   \__, |
                             __/ |
                            |___/ 

There were 4 different versions of Snake Arcade. Each one will be listed and described below:

	- Snake: This version I really didn't call it "Snake Arcade". I had a lot less expierence in
TI-Basic programming at this time, at the beginning of my 8th grade year. I just copied the home screen
snake with very few added features. I added a single high score, and poor skin and food selections, using
the Menu() command. There only was a single version of this and didn't stay on my calculator very long.
Hopefully, If I can find this somewhere in Google Drive, I'll add it to this archive. Me finding this is ver unlikely, since I did not upload programs too much back then, so I do not think I can ever recover this
program. RIP

	- Snake Arcade: I started this project at the beginning of my 8th grade year. This version did not
use libraries, so it wasn't very graphical in comparison to the newer versions. This version had 2 game modes: Normal and graph. These had memory leaks, so it got slower and slower over time. This version had a single high score for both modes. This had a cheat code system, and can only be accessed by getting a score
of 62 or higher in any mode. I do not know too much about this program, I do not have my old plans for this
program, so I do not know all the details on what my intentions were.

The second version of this game had a challenge mode, were you had to get a certain score in the home screen
mode in a certain amount of seconds. Successfully completing the challenge will get you a gold reward, and
unlock a snake or food skin.

	- Snake Arcade II: This was the first version that used Celtic 3, and had features that the others did not. The store was introduced, tokens were introduced (like apples, but called tokens instead), and graph mode was still available. A high score system is 5 for every game mode. Memory leaks in the normal and dimented were patched so the program can maintain speed. Nibbles was programmed differently, so instead of ending the game inside the program, it would end at the bottom of the code, which is why you can get scores and stuff from it. Some bugs were still in the program, though. The progress bar at the game over
screen would not always display like it should, mainly the code was not programmed good enough.

Honestly, I'm suprised that I was even able to locate the first and second generations of snake arcade, so
enjoy them!

 ____                  
|  _ \                 
| |_) |_   _  __ _ ___ 
|  _ <| | | |/ _` / __|
| |_) | |_| | (_| \__ \
|____/ \__,_|\__, |___/
              __/ |    
             |___/     

Currently, there are no known bugs witht the code. The only bugs that do not involve the program or any of
it's related programs, are capabilities with MirageOS and Celtic III. Some bugs cause the random number
generator seed in the OS to only be 1, no matter what you do, even with rand. It will always be 1. Reset RAM
or re-install the OS to fix this. Sometimes (but quite rare), the calculator will freeze if you constantly
archive and unarchive the SNKEARC program over and over. Sometimes occurs with the app var too. If this
happens with the program, any other variables (like groups, specifically) with the same name as the program
will become corrupted, because the failed program never made it to archive. You must remove a battery to fix
the problem, possible wiping the save data and corrupting the group. Sorry :( This is how I lost a version
of Gen III I was making. Refer to this link: http://tibasicdev.wikidot.com/forum/t-12099687/group-recovery

 _____  _          _       _                     
|  __ \(_)        | |     (_)                    
| |  | |_ ___  ___| | __ _ _ _ __ ___   ___ _ __ 
| |  | | / __|/ __| |/ _` | | '_ ` _ \ / _ \ '__|
| |__| | \__ \ (__| | (_| | | | | | | |  __/ |   
|_____/|_|___/\___|_|\__,_|_|_| |_| |_|\___|_|   
                                                 
Ok, credit time! This section will describe the authors of the programs, the original source code, the
edited source code, the source of the content, and the time of when it was made. Thanks to the authors for making the games and sharing to others to enjoy!

	= Normal mode=
Author: burr, edited by Weregoose, James Kanjo, and Timothy Foster.
The original source code:

:26→K
:1.1→B
:{4Ans→A
:ClrHome
:For(A,1,E2
:randInt(1,16)+.1randInt(1,8→C
:Repeat C=Ans(1
:A→dim(⌊A
:⌊A(1
:Output(10fPart(Ans),int(Ans),"O
:Output(10fPart(B),int(B),"   // 1 space
:Output(10fPart(C),int(C),"*
:getKey
:If Ans=45
:Goto 0
:If Ans=34 or 2>abs(Ans-25
:Ans→K
:⌊A(A→B
:⌊A(1)+(K=26)-(K=24)+.1((K=34)-(K=25
:If max(LA=Ans
:Goto 0
:Ans+16(not(int(Ans))-(17=int(Ans)))+.8(not(fPart(Ans))-(.9=fPart(Ans
:augment({Ans},⌊A→A
:End
:augment(Ans,{Ans(A→A
:End
:Lbl 0
:ClrHome
:A

The edited source code:

ClrHome
26->K
1.1->B
SetUpEditor A
{4Ans->A
0->D
For(A,1,|E2
randInt(1,16)+.1randInt(1,8->C
Repeat D or C=Ans(1
A->dim(|LA
|LA(1
Output(10fPart(Ans),int(Ans),Str5
Output(10fPart(B),int(B)," 
Output(10fPart(C),int(C),Str6
getKey->F
If Ans=45
1->D
F
If Ans=34 or 2>abs(Ans-25
Ans->K
|LA(A->B
|LA(1)+(K=26)-(K=24)+.1((K=34)-(K=25->E
If max(|LA=Ans
1->D
E
Ans+16(not(int(Ans))-(17=int(Ans)))+.8(not(fPart(Ans))-(.9=fPart(Ans
augment({Ans},|LA->A
End
augment(Ans,{Ans(A->A
If not(D
End

The source: http://tibasicdev.wikidot.com/snake

Time it was made: March 19th, 2008

	=Dimented mode=

Author: burr, edited by Weregoose and James Kanjo.

Original Source code:

26-2int(2rand->K
{4->L1:Ans->L2:1->I
ClrHome
For(J,1,|E2
	L1(1->L1(J
	L2(1->L2(J
	Repeat max(S!=L1 and Ans!=L2
		randInt(1,8->S
		randInt(1,16->T
	End
	Output(S,Ans,"*
	Repeat T=Ans and S=L1(I
		getKey
		If Ans=45:Goto Q
		If Ans=34 or 2>abs(Ans-25:Ans->K
		I+1-J(I=J->I
		Output(L1(Ans),L2(Ans)," 
		(K=34)-(K=25)+L1(Ans-(Ans>1
		Ans+8(not(Ans)-(Ans=9->L1(I
		(K=26)-(K=24)+L2(I-(I>1
		Ans+16(not(Ans)-(Ans=17->L2(I
		Output(L1(I),Ans,"O
End:End
Lbl Q
ClrHome:J

Edited source code:

ClrHome
26-2int(2rand->K
SetUpEditor L1,L2
{4->L1:Ans->L2:1->I
0->D
startTmr->theta
For(J,1,|E2
	L1(1->L1(J
	L2(1->L2(J
	Repeat (S!=1 or not(max(T={1,2,3}))) and max(S!=L1 and Ans!=L2
		randInt(1,8->S
		randInt(1,16->T
	End
	Repeat D or (T=Ans and S=L1(I
		Output(S,T,Str6
		Output(1,1,det(1,120-checkTmr(theta))+" 
		If 119<checkTmr(theta
		1->D
		getKey->F
		If Ans=45
		1->D
		F
		If Ans=34 or 2>abs(Ans-25
		Ans->K
		I+1-J(I=J->I
		Output(L1(Ans),L2(Ans)," 
		(K=34)-(K=25)+L1(Ans-(Ans>1
		Ans+8(not(Ans)-(Ans=9->L1(I
		(K=26)-(K=24)+L2(I-(I>1
		Ans+16(not(Ans)-(Ans=17->L2(I
		Output(L1(I),Ans,Str5
	End
	If not(D
End
J->S

Source: http://tibasicdev.wikidot.com/archives:demented-snake
Time it was made: August 2nd, 2008

	=Space Snake=
Author: 12Me21
Source code:
prgmSPCESNKE
:0->I%
:ClrDraw
:Repeat pxl-Test(31,47
:Pxl-On(31,47
:Text(randInt(0,57),91,"=
:I%+pxl-Test(30,47)pxl-Test(32,47->I%
:getKey
:If Ans=25
:Asm(prgmDOWN
:If Ans=34
:Asm(prgmUP
:Text(0,1,I%
:Asm(prgmLEFT
:End
:Text(0,0,"          (10 spaces)
:If I%>ZnMax
:I%->ZnMax
:For(X,1,9
:Asm(prgmFLASH
:End
:Text(51,0," SCORE: ",I%
:Text(57,0," HIGHSCORE: ",ZnMax
:Pause :ClrHome

prgmUP
:AsmPrgm214C9311409301F402EDB0EB010C00EF304CEF6A48C9

prgmDOWN
:AsmPrgm213396113F9601F402EDB823010C00EF304CEF6A48C9

prgmLEFT
:AsmPrgm213F960E40060CB7CB162B10FB0D20F5EF6A48C9

prgmFLASH
:AsmPrgm210000115F3FEF5F4DC9

Edited source code:

Lbl M3
real(12,7,0,0,95,63,1
real(12,6,0,7,89,62,1
real(12,7,0,29,89,33,1
Line(Xmin,0,0,0
Text(0,0,"SPACE SNAKE
real(13,1
Text(34,1,"HIGH: ",max(|LSPH
real(13,0
DelVar Srand(100
Lbl theta0
Repeat K=45 or pxl-Test(31,47
	Pxl-On(31,47
	getKey->K
	If max(K={25,34:Then
		not(K=34
		real(4,Ans,1,1
	End
	Text(randInt(0,57),91,"=
	S+pxl-Test(30,47)pxl-Test(32,47->S
	real(4,2,1,1
End
If |LSTAT(2
Goto thetaA
Lbl thetaO
For(I,1,60
	real(12,8,0,0,95,63,1
End
rand(100
real(12,7,0,0,95,63,1
If S>min(|LSPH:Then
	1->W
	S->|LSPH(6
	SortD(|LSPH
	5->dim(|LSPH
End
S->R
int(.3S->S
real(12,3,0,0,95,63,1
real(13,1
Text(~1,1,1,"               
Text(~1,1,89," 
real(13,0
Goto GO
Lbl thetaA
StorePic 1
real(12,7,0,0,95,63,1
real(12,3,0,0,95,63,1
real(13,1
Text(~1,1,1,"You Crashed!   
Text(~1,1,89," 
real(13,0
Text(9,2,"USE APPLE
Text(15,2,"END GAME
Text(27,2,"YOU CAN CONTINUE THE GAME
Text(33,2,"FROM HERE IF YOU USE AN
Text(39,2,"APPLE TO KEEP PLAYING.
Text(51,2,"APPLES: ",|LSTAT(2
9->O
Repeat max(K={21,105
	real(12,8,1,O,94,O+6,1
	Repeat K
		getKey->K
	End
	real(12,8,1,O,94,O+6,1
	max(9,min(15,O+6(K=34)-6(K=25->O
End
real(12,7,0,0,95,63,1
RecallPic 1
If O=15
Goto thetaO
|LSTAT(2)-1->|LSTAT(2
real(12,7,0,30,95,32,1
Goto theta0

Source of content: http://tibasicdev.wikidot.com/archive:space-snake
Time it was made: June 8th, 2015

	=Nibbles=
Author: Edward H
Source code:
AxesOff:FnOff 
ClrDraw
ZStandard
104→Xmax
⁻72→Ymin
ZInteger
Line(94,0,94,⁻61
Line(0,0,0,⁻61
Horizontal 0
Horizontal ⁻61
41→A:Ans→E
29→B:Ans→F
1→H:0→V
5→S:0→θ
Pt-On(41,⁻29,2
Repeat not(pxl-Test(N-1,M-1
2+3int(31rand→M
2+3int(20rand→N
End
Pt-On(M,⁻N,2
Pt-Off(M,⁻N,3
Pxl-On(N,M
Repeat 0
getKey→K
If Ans:Then
If H:Then
(Ans=34)-(Ans=25→V
If Ans
0→H
Else
(Ans=26)-(Ans=24→H
If Ans
0→V
End
End
If H:Then
A+3H→A
If pxl-Test(B,Ans-H)
Then
Text(27,34,"SCORE:",θ
Return
End
Pt-On(Ans,⁻B,2
Pxl-Off(B,Ans-H
Pxl-Off(B,Ans-2H
Else
B+3V→B
If pxl-Test(Ans-V,A:Then
Text(27,34,"SCORE:",θ
Return
End
Pt-On(A,⁻Ans,2
Pxl-Off(Ans-V,A
Pxl-Off(Ans-2V,A
End
If pxl-Test(B,A
Then
Pxl-Off(B,A
Repeat not(pxl-Test(N-1,M-1
2+3int(31rand→M
2+3int(20rand→N
End
Pt-On(M,⁻N,2
Pt-Off(M,⁻N,3
Pxl-On(N,M
If θ=95:Then
Text(27,34,"WIN.
Return
End
Pxl-On(62,θ
1+θ→θ
S+3→S
End
If S:Then
S-1→S:Else
pxl-Test(F,E-1)-pxl-Test(F,E+1
If Ans:Then
Pxl-On(F,E+2Ans
Pt-Off(E,⁻F,2
E+3Ans→E
Else
1-2pxl-Test(F+1,E
Pxl-On(F+2Ans,E
Pt-Off(E,⁻F,2
F+3Ans→F
End
End
End

Edited source code:

Lbl M4
ClrDraw
ZStandard
104->Xmax
~72->Ymin
ZInteger
real(7,|LSET(2
real(12,3,0,0,94,61,1
41->A:Ans->E
29->B:Ans->F
1->H:0->V
5->S:0->theta
0->D
Pt-On(41,~29,2
Repeat not(pxl-Test(N-1,M-1
	2+3int(31rand->M
	2+3int(20rand->N
End
Pt-On(M,~N,2
Pt-Off(M,~N,3
Pxl-On(N,M
Repeat D or K=45
	getKey->K
	If Ans:Then
		If H:Then
			(Ans=34)-(Ans=25->V
			If Ans
			0->H
		Else
			(Ans=26)-(Ans=24->H
			If Ans
			0->V
		End
	End
	If H:Then
		A+3H->A
		If pxl-Test(B,Ans-H
		1->D
		A
		Pt-On(Ans,~B,2
		Pxl-Off(B,Ans-H
		Pxl-Off(B,Ans-2H
	Else
		B+3V->B
		If pxl-Test(Ans-V,A:1->D
		B
		Pt-On(A,~Ans,2
		Pxl-Off(Ans-V,A
		Pxl-Off(Ans-2V,A
	End
	If D
	Goto SQ
	If pxl-Test(B,A:Then
		Pxl-Off(B,A
		Repeat not(pxl-Test(N-1,M-1
			2+3int(31rand->M
			2+3int(20rand->N
		End
		Pt-On(M,~N,2
		Pt-Off(M,~N,3
		Pxl-On(N,M
		Pxl-On(62,theta
		theta+1->theta
		If Ans=95
		1->D
		S+3->S
	End
	If D
	Goto SQ
	If S:Then
	S-1->S:Else
		pxl-Test(F,E-1)-pxl-Test(F,E+1
		If Ans:Then
			Pxl-On(F,E+2Ans
			Pt-Off(E,~F,2
			E+3Ans->E
		Else
			1-2pxl-Test(F+1,E
			Pxl-On(F+2Ans,E
			Pt-Off(E,~F,2
			F+3Ans->F
	End:End
Lbl SQ:End
For(I,1,60
	real(12,8,0,0,95,63,1
End
rand(100
ClrDraw

Source: http://tibasicdev.wikidot.com/archive:nibbles
Time it was made: Roughly April 17th, 2014

 _____        __                           _   _             
|_   _|      / _|                         | | (_)            
  | |  _ __ | |_ ___  _ __ _ __ ___   __ _| |_ _  ___  _ __  
  | | | '_ \|  _/ _ \| '__| '_ ` _ \ / _` | __| |/ _ \| '_ \ 
 _| |_| | | | || (_) | |  | | | | | | (_| | |_| | (_) | | | |
|_____|_| |_|_| \___/|_|  |_| |_| |_|\__,_|\__|_|\___/|_| |_|

Author: Bio_Hazard1282_rPi3
Source code: <See Source_Code.txt>
Source: Myself, Celtic 3, TI|BD
Time it was made (Gen 3): Started June 20th, 2019
Email: biohazard1282@gmail.com
Website: web-developing.wikidot.com