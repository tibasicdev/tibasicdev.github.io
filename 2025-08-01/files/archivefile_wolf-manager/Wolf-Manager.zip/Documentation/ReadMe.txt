
 __          __   _  __   __  __                                   
 \ \        / /  | |/ _| |  \/  |                                  
  \ \  /\  / /__ | | |_  | \  / | __ _ _ __   __ _  __ _  ___ _ __ 
   \ \/  \/ / _ \| |  _| | |\/| |/ _` | '_ \ / _` |/ _` |/ _ \ '__|
    \  /\  / (_) | | |   | |  | | (_| | | | | (_| | (_| |  __/ |   
     \/  \/ \___/|_|_|   |_|  |_|\__,_|_| |_|\__,_|\__, |\___|_|   
                                                    __/ |          
                                                   |___/           
*********************************************************************

The new Wolfman Shell is here! Introducing a stunning user interface
and new features that don't exist in other Shells, Wolf Manager gets
the job done with better file management and program execution.

    >>> What's new?
    
- Better group implementation, with proper handling and extraction.
- Bulk selection, with the options to delete/trash files, archive,
  or swap them.
- New rounded UI inspired by Slimshell, and thanks to Michael23_B,
  enhanced GUI with color gradients.
- Recent files for quick selection.
- Improved security with a password that is encrypted with
  substitution cipher (Read notes below).
- Optimized for calculators revision M and newer.
- Better interface customization and improved user-friendliness.
- Code Snipping: Select a specific area in a program or app var
  to extract.
- In addition to error handling in programs, Wolfman now has
  it for non-BASIC programs as well!
- Wolfman also has a debugging feature to assist with error
  reporting to help the development for everyone.
- Updates!!1!11!!
- And much more (I don't remember everything to be honest)

    >>> Downloading and installing

Download the latest archive from Wolf Manager's page 
on Cemetech. Extract the .zip archive and use your
preferred linking software to send the following files 
to your calculator (However TI-Connect CE may spit out an
Invalid tokens! error, better to use TiLP instead):

- WOLFLN (Launcher)
- App var w_upd (Update package)
- THINSIDE (Font file)
- SETSTATE (CPU wait state modifier [Pre-M only])
- WPW (Password program)
- WRGB (RGB program)

After, start the launcher and select Install or Update,
depending if Wolfman is installed already or not. Patiently
wait for the update or install to complete.

Once that is complete, Wolfman is ready to start!

    >>> How to use

The keys needed to operate Wolf manager is pretty straightforward.
Use [2nd]/[enter] to confirm or select various things in the
program, arrow keys to move the cursor or modify values, or the
number keypad.

In the file selection menu, you can use [alpha] and [math] to
jump between pages.

For the bulk select menu, you can use the [f1] to [f5] keys
to modify the selection list.

    >>> Feature List

    >>> Important notes

Due to how the program is structured, the performance on
pre-revision M calculators are poor. To help with that,
an assembly program is included to adjust the CPU wait
state to help (though some instability is introduced).
Because of this, it is known for modifying the CPU wait
state can cause crashes because the calculator is running
faster than it was intended by TI. It is recommended to
do this in an emulator such as CEmu, where it is easier
to recover from a RAM clear.

Functionality of this program is NOT supported on OS
versions 5.4.1 or later. Any reports on certain assembly
programs not working due to OS 5.5+ restricting this will
be fixed last.

At least 70,000 bytes of RAM is required to run Wolfman
due to it being a large program.

The battery level must be 2 or greater (out of 4) or at 
least charging in order to run the program. Otherwise,
issues can occurr upon the charge being lost.

The substitution Cipher to encrypt and decrypt the
password **IS A WEAK ALGORITHM!!** It is intended to
keep unauthorized individuals from accessing Wolfman.
Don't share the app var that contains said password to
unverified and untrusted third parties.

    >> TO REPORT ERRORS AND BUGS: 
    
Please visit https://ceme.tech/p310205 and upload the
contents of prgmDLOG to the thread. Include information
of:

- A brief description of what you were doing
- A brief description of what you were trying to do 
- What device you are using
- What OS you are using 
- What version of Wolfman you are using
- The contents of prgmDLOG (IF DEBUGGING COLLECTION IS 
  ENABLED!)

    >>> Changelog

    >> 0.90

- Initial beta release.