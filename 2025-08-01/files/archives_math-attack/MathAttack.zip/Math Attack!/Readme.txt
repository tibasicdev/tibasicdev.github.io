Project.........Math Attack!
Program.........MATHATTK
Author..........Zeda Elnara (ThunderBolt)
E-mail..........xedaelnara@gmail.com
Size............1103
Language........English
Programming.....BASIC
Version.........2.00
Last Update.....22:14 27/01/2011

Suggested Font	Any fixed width font (like Courier New)
Suggested Size	11

*Do NOT view with Word Wrap
*The following should fit on one line:
================================================================
"Oh dear God!"   (too much DBZA)
================================================================
  I made this because I feel pretty inadequate when it comes to
math. I am known as a human assembler/disassembler, I have been
called a walking calculator, I make brains implode/explode with
my math notes, but it is frustrating to me how long it takes to
do math in my head. Have you ever felt that? That horrible
awareness of how sluggish your thoughts are? Well, that's why I
made this. I can say for sure that my math skills are at least
temporarily enhanced after using this program and the more I
used this program, the more in tune I became with numbers.
Pretty much, if you want to push your brain and give it a
workout, have fun!
================================================================
How To Use
================================================================
  Run prgmMATHATTK.
  Go to the Options menu to select your settings.
    Type is the math operation to play with
    Digits is how many digits to work with
    Questions is how many questions are in the round
   *Use left/right to change, Enter when finished
  Select "Play" to begin playing.

When you input your answer, feel free to use math operators like
+/-*... they won't work. The only inputs allowed are numbers.

When you exit, your current scores will be displayed.
================================================================
Notes
================================================================
-In the next update, I plan to add:
  -Reimplimenting the old division test
  -Reimplimenting powers and roots
  -Allow for decimals
  -Timed play
  -Timed mode
  -A better interface

Seriously, this has been on my computer for over a year and I
forgot all about it. The first version looked prettier, but used
about twice the memory.
================================================================
History
================================================================
22:28 27/01/2011-Finally decided to upload it...
================================================================