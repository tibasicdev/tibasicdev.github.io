Collect Beta

***********************
*Table of contents:   *
*1. 84-Plus/SE Version*
* a. Instructions     *
* b. Known Bugs       *
* c. Copyright info.  *
*                     *
*2. 83-plus version   *
* a. Instructions     *
* b. Known bugs       *
* c. Copyright info.  *
*                     *
*3. Expectable updates*
*                     *
*4. Contact info.     *
***********************

1. 84-plus/SE beta version

a. Instructions:

Not all of the instructions are in the game instructions menu, so read this thoroughly.

The object of the game is to move around and collect the dot. You have until the counter at the bottom
left corner reaches 1000, or in other words, 100 moves.

Use the arrow keys to move up, down, right, and left.

Use the 7, 9, 1, and 3 buttons to move diagonally.

press the 2nd button to move to a random point on the screen

If you hit a wall, it's game over.

Press enter or clear to pause.

While paused, press 0 to exit, or enter or clear to resume.


b. Known bugs
None



c. Copyright info.

I don't believe in making scource code uneditable, so for the sake of any beginning programmers out there,
I'm leaving the scource code open for every program I'm ever going to make. There are a few restrictions I'd
like to put on this code:

1. Do not release this program under your name.
2. Give me credit if you use any segments of my program, or the whole program. (This does NOT apply to the ideas
I use. Only Segments of code taken directly from the main code.)
3. If you are a member of this site, personal message me any edited or optimized versions of this program that you
may make, If you have the time.
------------------------------------------------------------------------------------------------------------------


2. 83-plus version

a. Instructions

Same as the 84-plus/SE Version, but the 2nd button function is removed.

b. If you are moving down and left diagonal, and you try to go down, the game will hesitate, then keep moving down
and left diagonally. If anyone manages to fix it, please personal message me the result.

c. Copyright info.

I don't believe in making scource code uneditable, so for the sake of any beginning programmers out there,
I'm leaving the scource code open for every program I'm ever going to make. There are a few restrictions I'd
like to put on this code:

1. Do not release this program under your name.
2. Give me credit if you use any segments of my program, or the whole program. (This does NOT apply to the ideas
I use. Only Segments of code taken directly from the main code.)
3. If you are a member of this site, personal message me any edited or optimized versions of this program that you
may make, If you have the time.
------------------------------------------------------------------------------------------------------------------



3. Expectable updates

Difficulty levels, and different modes.

Obstacles of random size, and shape, negative version

At least 3-5 frames per second faster for both versions

Anything else I can think of that's within my programming ability.
------------------------------------------------------------------------------------------------------------------



4. Contact info.

Because I don't wish to reveal my name or email address, please personal message me at my wikidot account:
Architeuthiskid. If you don't have a wikidot account, get one.





Thank you for downloading this game, and I hope you learn something from it!

