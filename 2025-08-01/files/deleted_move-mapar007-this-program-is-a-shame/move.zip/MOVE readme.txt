18 June '08

Ok, this was my first try to make a game on the TI84+. It runs far too slow, and any optimization is welcome.



Controls and things on the screen:

X=you
*=bombs (become unharming after 10 turns)
O=point (your goal is to get as many points as you can, obviously)
Move: Arrows
Enter: Generate new O (if old one is hidden)

To see your highscores:

There's no in-game function for that, so follow a few steps (also I forgot to store highscores to a next level... But in the beta version that will change):


UnArchive LHSCM
LHSCM

The first number is your highest score.

Mapar007