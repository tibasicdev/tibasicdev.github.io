
/-------\
| ANBOX |
\-------/

Copyright � 2010, Mark Radocy. All rights reserved.

TI-BASIC, no subprograms
Runs on TI-83 family with an OS of 1.15 or higher.  No other libraries needed
Compatible with Mirage OS
Requires 9873 bytes of RAM (8710 bytes (game) + 1163 bytes (matrix))

based on ORBOX, by Arseniy Shklyaev.  Play ORBOX at http://www.gamebalance.com/games/orbox.html



Like puzzle games on your TI Calc but finished Block Dude?  Give ANBOX a try!

Fundamentals:
Pick a direction, and the player will move in that direction until it hits another block, when it will stop.
It can then be moved again the same way.  Continue until the block reaches the finish.
Just don't go off the screen, or it's game over!

IF YOU NEED TO STOP, PRESS 'MODE' OR 'CLEAR', NOT 'ON'!

Features:
Compatible with Mirage OS
18 levels ranging from very simple to extremely difficult
Smooth learning curve
Speedy gameplay (for the most part)
Auto-saving
Easy interface


Tile symbols:

# - Player.  You control the player, but only when it's not moving

/-\! (spins) - Finish.  Get the player to the finish!

O - Simple wall.  Bounce the player off these to navigate towards the finish

: - Stops the player.  It can move in any direction off this space

* - Spike.  Don't touch this; you'll die!

Discover what other tiles in the game do for yourself.  There are over 15 in all!


Need a walkthrough?  I'm sure someone will make one eventually.
If you're really desprate you can e-mail me at piguyfun@yahoo.com



