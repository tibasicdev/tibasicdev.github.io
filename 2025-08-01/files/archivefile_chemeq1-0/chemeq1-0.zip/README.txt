Chemical Equation Solver


a program for the TI-83/84+ family
by Edward Hou

v1.0

-Purpose
-Installation
-Usage
-Notes
-Changelog
-Contact
-License


==Purpose==
Chemical Equation Solver finds the balanced coefficients of a chemical
equation, inputted as a string.


==Installation==
Move CHEMEQ.8xp to your calculator.


==Usage==
Run CHEMEQ.8xp, and enter the chemical equation. Use the equals symbol in
place of an arrow. You may use parentheses in the compounds, but you cannot
nest them. In general, follow these examples below for your equations:

    C6H5COOH+O2=CO2+H2O
    PhCH3+KMnO4+H2SO4=PhCOOH+K2SO4+MnSO4+H2O
    Ba(NO3)2+H2CO3=BaCO3+HNO3
    BaX2+H2Y=BaY+HX
    H*+CO3-2=H2O+CO2

You can have ions and charged molecules: use the multiplication symbol "*" or
the small "+" tick (found in the Catalog) for a positive charge, and the
subtraction symbol "-", the negative symbol "-", or "e" (the base of the
natural log), for a negative charge. If the charge is greater than 1, put the
sign first and then the number last. Example: write "SO4-2", rather than
"SO42-", and write "Al*3" rather than "Al3*".

You may need lowercase letters enabled to input the two-letter element
symbols. This feature is provided by many Apps, including MirageOS and
Omnicalc. You can also move prgmLOWRCASE to the calculator and run
"Asm(prgmLOWRCASE)" from the home screen. You can find the "Asm(" command in
the Catalog: press [2nd]+(Catalog), and scroll down to "Asm(". You can run the
program again to disable the feature.

You can use any element symbol two letters long, including dummy elements like
"Aa" and "X" that represent groups of elements that are never broken up during
the reaction. For example, you could input:
    AgX+Zn=ZnX2+Ag
where X is a replacement for (NO3). This feature reduces runtime and its use
is recommended.

Only natural numbers may be used as coefficients.

The program overwrites the variables list A, list E, list EE, [E], Str0, Str9,
Str8, A, B, C, L, N, S, T, U, V, W, X, Y, Z, Theta, and Ans.


==Acknowledgements==
The simplify to integers routine is based on ideas from Weregoose from the
United-TI forums.


==Changelog==
v1.0
-Size optimizations
-Speed optimizations

v0.9
-Supports ions and charged molecules
-Supports the use of any 2-letter element symbol
-Always returns integer coefficients in lowest terms
-No longer needs prgmPARSCHF, prgmSMT, or prgmELEMENTS
-Memory optimizations
-Speed optimizations
-Fixed bug where certain equations returned "ERR:INVALID DIM"

v0.2
-First release


==Contact==
If you have any questions, comments, bugs, suggestions, ideas, requests, I can
be contacted at hou edward (at) g mail (dot) com.

Copyright (c) 2008 Edward Z Hou

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
