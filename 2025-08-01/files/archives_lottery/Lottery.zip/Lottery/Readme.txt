Lottery
By: patriotsfan (patriotsfan98@gmail.com)

Use this program to strike it rich and become the next millionaire! Although, I can't guarantee it will happen! :)

CONTROLS
Type in the value for each category and press ENTER. If the value you inputted was invalid, the category will be repeated until you type in an appropriate value.

INPUT
Numbers: Between 1 and 6
Highest: Between 2 and 99
Mega Number: 0=NO, 1=YES
Highest Mega: Between 2 and 99

NOTE: If you happen to win the lottery by using this program and want to give me a share of your earnings, email me at patriotsfan98@gmail.com. (Not mandatory but very much appreciated!!!)

EXAMPLES:

MEGA MILLIONS
Numbers = 5
Highest = 56
Mega Number = 1
Highest Mega = 46

POWERBALL
Numbers = 5
Highest = 59
Mega Number = 1
Highest Mega = 39

VERSIONS
1.0 - (5/15/2010) Original version - 342 bytes