This is an advance quadratic solver designed to allow you to use the answer typed on the screen and put it right as an answer.Simplifys the radical and the fraction to the fullest amount.Update 9/18/08 for speed and size.Results are stored to list three.
Please email noah.fencer@gmail.com with any bugs.

Credits-----
Noah Maddox
Anders Tiberg