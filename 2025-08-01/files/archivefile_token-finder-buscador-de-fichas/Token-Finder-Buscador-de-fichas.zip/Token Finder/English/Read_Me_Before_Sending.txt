 ______        __                         ____                    __                  
/\__  _\      /\ \                       /\  _`\   __            /\ \                 
\/_/\ \/   ___\ \ \/'\      __    ___    \ \ \L\_\/\_\    ___    \_\ \     __   _ __  
   \ \ \  / __`\ \ , <    /'__`\/' _ `\   \ \  _\/\/\ \ /' _ `\  /'_` \  /'__`\/\`'__\
    \ \ \/\ \L\ \ \ \\`\ /\  __//\ \/\ \   \ \ \/  \ \ \/\ \/\ \/\ \L\ \/\  __/\ \ \/ 
     \ \_\ \____/\ \_\ \_\ \____\ \_\ \_\   \ \_\   \ \_\ \_\ \_\ \___,_\ \____\\ \_\ 
      \/_/\/___/  \/_/\/_/\/____/\/_/\/_/    \/_/    \/_/\/_/\/_/\/__,_ /\/____/ \/_/ 
                                                                                      
Token Finder is a special tool for accessing inaccessible tokens on your graphing calculator
that you couldn't do in pure TI-BASIC. Meaning, you can get any token or ASCII character
you ever dreamed of on your calculator.
 _____        __                           _   _             
|_   _|      / _|                         | | (_)            
  | |  _ __ | |_ ___  _ __ _ __ ___   __ _| |_ _  ___  _ __  
  | | | '_ \|  _/ _ \| '__| '_ ` _ \ / _` | __| |/ _ \| '_ \ 
 _| |_| | | | || (_) | |  | | | | | | (_| | |_| | (_) | | | |
|_____|_| |_|_| \___/|_|  |_| |_| |_|\__,_|\__|_|\___/|_| |_|
                                                             
Here is some information regarding the program itself, contact and author information.

Program: TOKEN
Size: 4333 bytes
Status: Archived, Viewable, Unlocked
Type: TI-BASIC (Uses libraries)
Lines: 337

-Author Info-
Author: Bio_Hazard182_rPi3
Date of Creation: November 18th, 2018
Email: biohazard1282@gmail.com

If you have any suggestions or anything, feel free to contact me!
  _____      _   _   _                _____ _             _           _ 
 / ____|    | | | | (_)              / ____| |           | |         | |
| |  __  ___| |_| |_ _ _ __   __ _  | (___ | |_ __ _ _ __| |_ ___  __| |
| | |_ |/ _ \ __| __| | '_ \ / _` |  \___ \| __/ _` | '__| __/ _ \/ _` |
| |__| |  __/ |_| |_| | | | | (_| |  ____) | || (_| | |  | ||  __/ (_| |
 \_____|\___|\__|\__|_|_| |_|\__, | |_____/ \__\__,_|_|   \__\___|\__,_|
                              __/ |                                     
                             |___/                                      

Let's get started. But first before you can get
any tokens yet, make sure you have the following:

- A graphing calculator; make sure it's an 83+/84/SE model. The other models are not
supported, and won't work.
- A communication cable. You gotta have this in order to send anything.
- Linking software. This software allows your computer to communicate with your calculator.
- Enough memory. Make sure you have enough memory to receive variables.

Okay, now that you have the required items above, start the linking software on your computer.
It doesn't really matter what software you use, TI-Connect or TiLP works fine. If you have another
software, make sure it can send and receive TI-Files correctly.
 _____                _ _               ______ _ _           
 / ____|              | (_)             |  ____(_) |          
| (___   ___ _ __   __| |_ _ __   __ _  | |__   _| | ___  ___ 
 \___ \ / _ \ '_ \ / _` | | '_ \ / _` | |  __| | | |/ _ \/ __|
 ____) |  __/ | | | (_| | | | | | (_| | | |    | | |  __/\__ \
|_____/ \___|_| |_|\__,_|_|_| |_|\__, | |_|    |_|_|\___||___/
                                  __/ |                       
                                 |___/                        

	If you have TI-Connect

		If you have the original TI-Connect
Click the button that says "Send to TI Device". If TIC says "Sending to Nothing", make sure your
calculator is selected and connected. Then, click the "Browse" button to send the files in this
folder to your calculator. Send the Celtic 3.8xk and the TOKEN.8Xp files to your calculator.

		If you have TI-Connect CE
Click the Calculator Explorer button with the magnifying glass, and click the button with the
arrow pointing AWAY from the computer. Find the files and select them. Click Open. The
files will be sent to your calculator.

	If you have TiLP
I have no expierence with TiLP on Windows or MAC, so I am only going to explain instructions
for TiLP on a Raspberry Pi with the Raspbian OS. Boot up TiLP. Make sure your calculator is
turned ON and connected. Make sure it's not running anything either. Click the arrow
that is pointing UP and find the files (/pi/Downloads/Token Finder). Click them or select them
and click open and TiLP will send the files. Make sure the Timeout setting for your calculator
is set to 50 so your calculator can Garbage Collect (if it needs to) to receive the
variables.
 _    _                   _______      _______    _             _       _ 
| |  | |                 |__   __|    |__   __|  | |           (_)     | |
| |__| | _____      ________| | ___      | |_   _| |_ ___  _ __ _  __ _| |
|  __  |/ _ \ \ /\ / /______| |/ _ \     | | | | | __/ _ \| '__| |/ _` | |
| |  | | (_) \ V  V /       | | (_) |    | | |_| | || (_) | |  | | (_| | |
|_|  |_|\___/ \_/\_/        |_|\___/     |_|\__,_|\__\___/|_|  |_|\__,_|_|
                                                                          
Now that you sent the variables, let's go through a tutorial for working the program's magic.
First of all, install Celtic 3. Look in the APPS menu and install it. Press 1 to install it.
Now, unarchive the TOKEN program. Run it. Let's go over the options in the main menu.
The first option is the Find option, where you find the tokens you want. Now, before we
go over the other options, let's talk about saving. If you want to save certain hex values
in case you're gonna forget it, you can add them to the app var the program creates
specificly for this utility. The name of this is named TokenHex, so you know to not delete
that variable. You can also delete unwanted hex values if you're done with them.

On with the juicy part! To start finding tokens, select the Find option. If you have hex values
saved in the App var, you can choose one of those to get started. Otherwise, you have this
screen:

##################
#<0000>0         #
#??              #
#                #
#                #
#                #
#                #
#                #
##################

The four 0's are the hex value, and the 0 is a decimal value of that hex (I put that there for
reference). The ??'s below are the characters for the hex value.

Press the left key to go up a value, and press right to go down a value. Press ALPHA to do a
"quick jump" to a specific hex value without pressing left hundreds of times. You can also
press MATH to do a random hex value. Now, let's practice using the value selection. Press
ALPHA and adjust the 0000 hex value to BBDA. Press the up key to go up a value, down to
go down a value. Press 2ND or ENTER to confirm it. On the screen, it will show this:

##################
#<BBDA>48090     #
#%               #
#                #
#                #
#                #
#                #
#                #
##################

BBDA is the hex value for the % token! With that token, you can directly punch that in
on the home screen. It works like dividing a real number by 100.

##################
#93%             #
#            .93 #
#                #
#                #
#                #
#                #
#                #
##################

Now, let's do another one. Do a quick jump and select EF66. When you confirm it, you're going to
get an interesting result. Instead of a normal token (or two), you get a bad token. This is a
one-byte token, and contains a bunch of garbage characters.

##################
#<EF66>61286     #
#sêsësîsÜs¨s?s?s?#
#s?s/sLs?s?s?s?su#
#t°t?t?u?u?u^tOt@#
#t1t?tmt²uvu_s?vT#
#v=v)v2v6v;vAv^va#
#vFvkvpvvvyvñv?v #
##################

Whenever you press 2ND or CLEAR, the program saves the hex value and characters to a program called TOKENS, for reference.
So it's useful when you want to get special chaacters for a program. Be warned; lots of tokens are dangerous. If you save them
or try to recall them or display them in any way, shape, or form, you're gonna crash and possibly damage your calculator.
There are some tokens where it actually corrupts your Operating System immediatly. Some of them reeeeally crash your
calculator and can corrupt things in the archive.

 ______           _          __   _______    _             _       _ 
|  ____|         | |        / _| |__   __|  | |           (_)     | |
| |__   _ __   __| |   ___ | |_     | |_   _| |_ ___  _ __ _  __ _| |
|  __| | '_ \ / _` |  / _ \|  _|    | | | | | __/ _ \| '__| |/ _` | |
| |____| | | | (_| | | (_) | |      | | |_| | || (_) | |  | | (_| | |
|______|_| |_|\__,_|  \___/|_|      |_|\__,_|\__\___/|_|  |_|\__,_|_|

Well that's it. Hope you enjoy this program! I put a lot of work and... crashing to make sure this all works! Play around,
expieremnt, and explore all the exciting characters on the OS! Just as a side note, don't be stupid and intentionally try
to crash your calculator. Stay away from those bad tokens!