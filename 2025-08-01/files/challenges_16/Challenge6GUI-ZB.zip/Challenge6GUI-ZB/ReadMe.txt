<===================================This wide===================================>

Program: Graphical User Interface Creator
Author: Jonah Scheinerman a.k.a.
	Zaphod Beeblebrox
Version: 1.0
Date: 12/30/08
Included Files:
	ZDRAWGUI.8xp - main program
	ReadMe.txt - this
	EXAMPLE.8xp - example gui
		This works correctly for the window coordinates:
		xMin = 0	xMax = 94
		yMin = 0	yMax = 62

HOW TO USE:
-----------
This program takes information from any matrix [A] through [J] the program stores
the information from the given matrix into [J], so keep that in mind when using
this program. Once one creates a matrix with a specialized syntax (listed below),
one runs the program with the following syntax:

	matrix_n:prgmZDRAWGUI

In the syntax, matrix_n is a real integer number between 1([A]) and 10([J]). This
will draw the GUI on the screen and then start up a control sequence. There are 3
main keys used to operate the GUI: The enter key, the clear key, the tab key. The
enter key exits the execution, leaves the window drawn and returns a 1, signaling
that the information should be stored. The clear key exits the execution, leaves
the window and returns a 0. The tab key switches between editable components in-
definitely.

HOW TO CREATE THE INFO MATRIX:
------------------------------
The info matrix is a N by 7 matrix that can go in any matrix slot. The matrix
stores information by signal letters. Each row of the info matrix is a component
in the GUI. The first column in each line signals what kind of component the row
is, and therefore, determines the syntax for the rest of the line. There is one
required rows, and two sections of rows.

	THE REQUIRED ROW:
	------------------
	The first line of the matrix must set the key codes for each of the three
	controller keys. The key code is simply the standard TI-OS key code. (e.g.
	[ENTER] = 105). If the matrix is [A], the first line must look like this:
	
		[enter_keycode,clear_keycode,tab_keycode,0,0,0,0]

	THE FIRST SECTION OF ROWS:
	--------------------------
	The first section of rows is the section of uneditable components. These
	each occupy their own row and have their own syntax. There is a recommend
	-ed ordering of these elements which is inherent in their numbering.

		UNEDITABLE ELEMENTS:
		--------------------
		1:Frame
		[1,x1,y1,x2,y2,shadow,0]
		This creates a frame border for the current GUI.

		x1, y1, x2, and y2 are all corners of the frame that will be drawn
		from these specifications. The shadow controls the drop shadow
		made by this frame. If it equals 0, no drop shadow is made, if it
		equals 1, a drop shadow is made.
		--------------------
		2:Title
		[2,x1,y1,x2,strN,0,0]
		This creates a title line at the top of the frame for this GUI.

		x1, y1, and x2 are all equal to their counter parts in the frame
		component and MUST be the same, otherwise, weird stuff happens.
		StrN is a number 0 - 9 representing Strings Str0 - Str9, this
		string contains the title text.
		--------------------
		3:Vertical Separator
		[3,x,y1,y2,0,0,0]
		This creates a vertical line with given end points.

		X is the horizontal position of this component. Y1 and y2 are the
		vertical ends of this component.
		--------------------
		4:Horizontal Separator
		[4,x1,x2,y,0,0,0]
		This creates a horizontal line with given end points.

		X1 and x2 are the horizontal ends of this component. Y is the
		vertical position of this component.		
		--------------------
		5:Text
		[5,x,y,StrN,0,0,0]
		This displays text at a given point.
	
		X and y are coordinate points of the text. StrN is a number from
		0 - 9 representing the Strings Str0 - Str9, this string contains
		the text.
	

	>>>> IMPORTANT NOTE: <<<<
	The first section of rows must ALWAYS be ended be a blank row (all 0's).

	THE SECOND SECTION OF ROWS:
	---------------------------
	The second section of rows is the section of editable components. These
	each occupy their own row and have their own syntax. An editable component
	is a component that displays some value that can be controlled in some way
	by the user.

		EDITABLE ELEMENTS:
		------------------
		6:Spinner
		[6,x,y,lower,upper,inc,rValue]
		This creates a spinner which can be changed to display a number.
		
		X and y are the coordinates of the spinner.  Lower is lower limit
		on the value the spinner can hold, which is the initial value of
		the spinner. Upper is the upper limit on the value of the spinner. 
		Inc is the increment with which the spinner scrolls. rValue is the 
		current value of the spinner. After program execution, one can 
		access [J](N,7) to determine the result of the spinner. This spinner
		value can be incremented and decremented with the [^] and [v] keys
		respectively.
		------------------
		7:Check box
		[7,x,y,state,0,0,0]
		This creates a standard check box that is either filled or unfilled.
	
		X and y are the coordinates of the check box. State is 0 (unfilled,
		unchecked) or 1 (filled, checked). One can access this after
		program execution to determine the state of the checkbox. The state
		of the check box can be toggled using the [^] and [v] keys.
		------------------
		8:Text Box
		[8,x,y,limit,slotN,0,0]
		This creates a text box with editable text.

		X and y are the coordinates of the text box. Limit is the upper
		limit on characters for the text box. SlotN is the save slot. This
		will be explained momentarily. The box can have uppercase and
		lowercase letters typed into it (Toggled between using [ALPHA]).
		To delete a character (backspace) press [DEL]. To move through
		the text in order to insert letters or delete letters before the
		last one, use the [<] and [>] keys. All the standard keys for
		typing apply, except for the quote key ("). This is a "!" when
		in capital mode and a "." when in lowercase mode.

	>>>> IMPORTANT NOTE: <<<<
	When the GUI is finished being drawn and is usable, if a component is cur-
	rently selected, it will have a ">" behind it, this will occupy the four
	previous pixels. (3 pixels for the letter plus a space.)

>>> IMPORTANT NOTE ABOUT VARIABLE USAGE: <<<
--------------------------------------------
You may use any strings you want for the text element (5), however the program
uses certain strings for the text box element (8) that will always overwrite. These
are strings Str8, Str9 and Str0. You can use each of these strings for the text,
they will be displayed, however they will be overwritten during program execution,
so do not expect the end result to be the same.


HOW TO ACCESS THE RESULTS OF A TEXT BOX:
----------------------------------------
In the text box element (8), the slotN argument can be a value from 1-9. These are
the 9 text slots that you can save to (you probably won't need that many). All text
is stored to Str9. To access your text do the following:

(For this example slotN = 2 and 'E' refers to the little e [2nd][,])

:inString(Str9,"E2->A
:inString(Str9,"E",Ans+1
:sub(Str9,A+3,Ans-A-4

This will return the text of the text box.

----------------------------
Good Luck and Good coding...