controls:

to move cursor: use arrow keys.
to buy 1 stonk: press "2nd" key
to sell 1 stonk: press "ALPHA" key

to get the maximm number of stonks during trading: press "DEL" key
to sell all your stonks: press "STAT" key

to exit the "MENU" menu/stop trading early: press "MODE" key



(note: while trading, you can have no more than 8 stonks.)