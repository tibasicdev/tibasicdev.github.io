########################################################################
#                                                                      #
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@ Sudoku 1.0 @@@@@@@@@@@@@@@@@@@@@@@@@@@@ #
#                                                                      #
########################################################################

-----------------------------Introduction-----------------------------

Sudoku 1.0 is one of the best Sudoku GUI's out there.  You can save
your sudoku to finish it sometime later.  You can fill in possibilities,
just like some people do on paper.  And the best thing is, your sudokus
are randomly generated! Take note, other sudoku GUI's CLAIM to have
randomly generated sudokus, but the only thing that changes is the
numbers, not the arrangement of the numbers.  THIS IS NOT THAT!
To explain, my sudokus are chosen from one of 5 pre-solved sudokus, and
then scrambled randomly, in a few select ways that keep its validity.

-----------------------------Installation------------------------------

->Send SUDOKU.8xp to your calc.
->If [I] does not exist, hit the following sequence of buttons:

[2nd][MATRIX][<-][9][Enter][Enter][2nd][Quit]

This intializes [I] so you won't get an ERR:UNDEFINED.

-----------------------------Controls-----------------------------

>>>Menu

->Up/down	Choose
->2nd		Confirm

>>>In-game

->0-9		Fills selected box with that value (0 clears the box)
->Arrows	Moves selected box around
->Enter		Opens Possibilities UI
->Graph		Opens in-game menu
->Sto		Pauses, use [Enter] to resume.  Uses TI-OS APD feature,
			so you can leave it like that.

>>>Possibilities UI

-->1-9		Toggles that value in the possibilities box
-->Enter	Exits Possibilities UI

-----------------------------To Do List-----------------------------
(This is what I plan on adding)

=> Enter-your-own-Sudoku
=> Anything else that us suggested to harrierfalcon@yahoo.com that
	I think is worthy.

-----------------------------Variables-----------------------------
That are used:

[A]
[B]
[C]
[I]
[J]
A bunch of real variables
L1-L6, excluding L3
Str1

So just make sure nothing valuable is in any of those.

-----------------------------Errors-----------------------------

ERR:INVALID DIM
=>You have not saved a sudoku before.

-----------------------------Legal Stuff-----------------------------

I wrote this program from scratch, by myself, but with a little coding
from todlangweilig at unitedti.org. Do not use any of the source
without my permission.  If you want to use any part of the source,
e-mail me at harrierfalcon@yahoo.com to get permission.

-----------------------------End Notes-----------------------------

If you have any questions, bugs, or suggestions, e-mail me at
harrierfalcon@yahoo.com.
