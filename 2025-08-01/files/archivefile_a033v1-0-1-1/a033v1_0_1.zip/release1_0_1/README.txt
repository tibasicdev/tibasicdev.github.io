/+------------+/
/ADVENTURE GAME/
/  by:minxrod  /
/+------------+/

Description:
	A033 is a puzzle/exploration game written in pure TI-Basic for the homescreen of TI84SE and TI84CE. The objective of the game is to move the player character (pi) to collect points by earning (+) and (*) items, and avoiding contact with enemies (e), (i), and later in the game (n). By finding a stick (/) you can defeat enemies, and earn more points. When an adventure is ended, your highscore is saved and your moves are counted. There are 4 main worlds to explore, and 4 smaller bonus worlds.

Controls:
	Move (pi) with the directional buttons.
	End adventure with the CLEAR button.

Subprograms:
A033C	display program - creates dialogs
A033D	display program - updates player and score
A033L	map program	- maps are stored and loaded from here
A033M	display program - redraws the map to reflect current area
A033U	update program	- game mechanics are all here

Map creation:
	Maps are stored as strings to Str2 within subprogram A033L, following the format of chunks of 128 characters that defines each area. Each chunk is defined by its location in the map string. Area 0 is characters 1-128, Area 1 is characters 129-256, etc. When the player travels out of an area, depending on the axis of travel the game will travel to different locations as defined by variable W...

	           Area-W
	Area-1 [current area] Area+1
	           Area+W

Dialogs from the characters e and i are determined by Str3, following this format:

	auv##
	* A = area number
	* U = X offset (from left)
	* V = Y offset (from right)
	* ##= Number of characters in message. Must be two digits, range from 01 to 99.

This dialog is triggered when the player attempts to move to the location of an e or i character in the map. Note that the e and i used for dialog are different characters from the numbers e and i used as enemies.

Any character can be used as a tile. If a character does not have special interation deinfed in A033U, then it will have no interaction with the player.

end