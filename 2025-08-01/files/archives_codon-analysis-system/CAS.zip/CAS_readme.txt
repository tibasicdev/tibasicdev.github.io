Codon Analysis Software
Version 1.0
By Aaron Gaba

Codon Analysis System (CAS) is a biology program transcribes basic codons, tells you the amino acid it codes for, and gives its the tRNA anti-Codon.

Compatibility: TI-83+/84+/SE

File Size: 12�KB

Instructions
-Transfer the CAS file to your respective TI (83+/84+/SE) calculator, via TiConnect.

-To launch CAS, press PRGM and select CAS from the menu on your calculator.

Within CAS
-CAS is designed to take the DNA codon (not the mRNA codon).   You enter in the DNA codon through a three-step wizard.

EX.    The codon is ATG

In ENTER BASE ONE, you choose -A-
In ENTER BASE TWO, you choose -T-
In ENTER BASE THREE, you choose -G-

Within seconds, you will be presented with an analysis of the DNA codon.
To exit, press ENTER twice and then select QUIT.

