'-~-~-~-~-~-~-~-~-~-~-~-~-'
	BLACK JACK
,-~-~-~-~-~-~-~-~-~-~-~-~-,
	   v2.14

Programmed by Ray "Charles Oakwood" Wang


==================
Table o' Contents
==================
I. Introduction/History(?)
II. ZIP Contents
III. Setting up
IV. Controls
V. Known Errors/Bugs
VI. Contact
VII. Semi-Complete Credits list
VIII. Disclaimer
XXX. Inside Joke
=-=-=-=-=-=-=-=-=-=-=-=

I.
Introduction/History(?)

<If you don't want to know about my life, skip over this section.>

My version of Blackjack began when I was in eighth grade (I was in Geometry), with my TI-83+.
I was constantly programming things to get me to finish my homework faster, such as Area of Equilateral Triangle,
Distance Formula, Quadratic, etc. When I decided that I would try programming a game. BlackJack came to my mind
first, because it seemed easy(er) to program, as it didn't require any graphics (which I did not know how to use
at the time). I finished the program within two weeks, with some difficulty with the changing values of Aces.

Now on to ninth grade.
My friend got me a bunch of games (he had a TI-84+SE, I had a TI83+ without Graphlink), and one of those games was
a TI-BASIC game. I didn't notice that it was BASIC until I saw the Icon, as it was complete with Graphics and
everything (remember that I didn't know how to use graphics in BASIC programs). I looked through the coding of the
game, as I started to realize that BASIC games didn't just need to be text-based; they could use the Drawing
features along with the graph.

One of my games eventually froze, in which I had to take out the batteries, clearing my RAM, thus deleting my
first BlackJack program. I eventually decided to make a new (and better) version of my original BlackJack, using
my newfound knowledge of BASIC graphics. I began programming, checking, fixing, etc. a new BlackJack, with graphics
and all the cool stuff that programs should have. This time, I was done with the main program within three days
(I know I'm a slow programmer), with very few bugs.

And now it's completely done (not really), with graphics, etc. Now inlcudes betting. See section V list of known
bugs.
=-=-=-=-=-=-=-=-=-=-=-=

II.
ZIP Contents

In the ZIP folder you will find:
BLACKJACK.8xp (The game)
readmetodayandrecieveanonpoisonouscookie.txt (This file)
HOMESCREEN.bmp (A screenshot of the main menu of the game)
INGAME.bmp (A screenshot of ingame play in the game)
=-=-=-=-=-=-=-=-=-=-=-=

III.
Setting Up

TI-83+
Using your GraphLink thing, just send BLACKJACK.8xp to your calculator.
(I don't know how to do it; I don't have a TI-83+ anymore)

TI-84+/TI-84+SE
Using TI-Connect, send BLACKJACK.8xp to your calculator.
(I'm sorry I'm really bad at giving directions)
=-=-=-=-=-=-=-=-=-=-=-=

IV.
Controls

Press 1 or 2 or CLEAR at the Main Menu to start a new game or resume a game or exit the game, respectivey.
(Or press a different button to enter a cheat)

Press 1 or 2 or CLEAR ingame to hit or stay/stand or exit the game, respectivey.
=-=-=-=-=-=-=-=-=-=-=-=

V.
Known Errors/Bugs

The screen may display "BlackJack" even if you have less than 21.
The program may skip your turn if the dealer has two Aces.
Also note that the betting screen may display funny if the program is being run in Doors CSX or the sort.

If you find any other bugs, email me or something. (Check VI. Contact)
=-=-=-=-=-=-=-=-=-=-=-=

VI.
Contact

You may email me at the_pgf@yahoo.com
=-=-=-=-=-=-=-=-=-=-=-=

VII.
Semi-Complete Credits List

Ray "Charles Oakwood" Wang - Creator of the program
Zain Ali - Showing me the game that inspired me
Kunal Mehta - Recovering my program when my RAM was cleared
Alex Marcolina - Making the game that inspired me
=-=-=-=-=-=-=-=-=-=-=-=

VIII.
Disclaimer

The program or the programmer is not responsible for loss of memory, loss of calculator, loss of program,
loss of friends, loss of clothes, loss of home, loss of USB cord, loss of TI software, loss of hair,
loss of internet access, loss of food, loss of water, loss of other hardware, and/or loss of life.
=-=-=-=-=-=-=-=-=-=-=-=

XXX.
Inside Joke

If Hiroki, Eric, Sam, Alison, Dominic, Brandon, etc. might be reading this...
HYWTM.
=-=-=-=-=-=-=-=-=-=-=-=


       �2008 SuperUltraSpecialAwesome Ltd.
              Some rights reserved