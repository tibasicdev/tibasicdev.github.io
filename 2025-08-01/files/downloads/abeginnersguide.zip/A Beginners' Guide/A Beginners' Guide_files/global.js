
// break out of frames
if (window != top) top.location.href = location.href;
