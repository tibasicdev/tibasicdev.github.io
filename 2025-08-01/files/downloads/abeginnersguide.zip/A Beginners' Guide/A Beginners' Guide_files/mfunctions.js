
function mOvrCursor(src) {
	if (navigator.userAgent.indexOf("MSIE 5") != -1) {
		src.style.cursor = 'hand';
	}
	else {
		src.style.cursor = 'pointer';
	}
}

function mOutCursor(src) {
	src.style.cursor = 'default';
}

function mOvr(src) {
	mOvrCursor(src);
	src.style.backgroundColor = '#FFCC66';
	src.getElementsByTagName('a')[0].style.color = 'black';
}

function mOut(src) {
	mOutCursor(src);
	src.style.backgroundColor = '#FFEECC';
	src.getElementsByTagName('a')[0].style.color = '#003399';
}

function mClk(src) {
	if (src.tagName == 'TH' || src.tagName == 'TD') {
		document.location.href = src.getElementsByTagName('a')[0].href
	}
}
