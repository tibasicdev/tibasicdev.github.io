Mini Bomberman|By Battlesquid
------------
Requirements
------------
-Recommended for the 84+SE or 84+, but works on the 83+, just slower
-You probably want to GarbageCollect and make sure you have space on your calculator so the timer will work efficiently
---------
GAMEPLAY
---------
Cross= you
Solid block= unbreakable break
Block with hole= breakable block
Exit= located at bottom right corner of map
Bomb= four corners of a square

To make a new map in case the exit cannot be reached, press MODE
To lay a bomb, press 2nd
To quit, press CLEAR

Happy gaming!
