 
 README - MINES1
   Version  1.4.0
   First General Release
   May 18 2010

   By Michael Lee

   Contact at 
     deflect.4444@gmail.com

 Contents of zipfile
   > MINES1.8XE
   > readme_mines1.txt

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 Name of program: MINES1

 Description: 
   A minesweeper clone played on the homescreen with an 8x10 field
   Compatible with TI-83/84/+/SE
   Pure BASIC
   Only 2992 bytes (counting title)

 Features:
   Generates a random minefield with 13-16 mines
   Expands when an empty space is clicked
   Instantaneously exit by clicking [MODE], [DEL], or [CLEAR] - even when something is loading
   Contains instructions and contact info in-game
   Only one program
  
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 
 Instructions
   Press [MODE], [DEL], or [CLEAR] to quit at any time
   Use arrows or numbers to navigate menu
   Please be patient and wait when loading
   Use arrows to navigate minefield
   Press [Y=]    or  [2ND] to select a square
   Press [GRAPH] or  [ALPHA] to flag or unflag a square
   Press [TRACE] to reset the minefield
   When the mines are expanding, wait until the face starts smiling again
   All levels are random (unless you store the same number to rand, over and over again...)

   For more detailed instructions, see the botton of this document

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 Possible Issues and Bugs
   > This program has only been tested on TI-84+ SE, although it should work on others
   > This program should theoretically work and exit without crashing on Doors, MirageOS, etc... 
     but this has never been tested.
   > Expanding takes time

 Possible Future Improvements
   > Creating a faster and smarter expansion process
   > Making the initial loading time faster
   > General optimization
   > An options menu (to choose the number of mines, etc...)
   > Creating a timer
   > Creating a permenant high scores list
   > Using the graph screen instead of the home screen
   > Enlarging the minefield on the graph screen

 Please send all suggestions, comments, and complaints to 
   deflect.4444@gmail.com

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 Variables Used:
   A, B, K, L, N, Q, R, V, W, X, Y
   List MS
   [J]
   Str1
   All variables will be deleted when the program is finished.

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 
 What I mean by expanding:

 If I have a minefield and click the top left corner...
 +++++++++++
 +++++++++++
 +++++++++++
 +++++++++++
 +++++++++++
 +++++++++++
 +++++++++++
 +++++++++++
 
 This is an example of expanding.
      2+++++
      2+++++
 221 11+++++
 ++1 1++++++
 ++111++++++
 +++++++++++
 +++++++++++
 +++++++++++

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 Instructions (for the simpleton)

 > Placing the program on your calculator:
     I haven't got a clue - make sure you have your cable and install either "TI-Graph Link" 
       or "TI-Connect" from the Texas Instruments website.  (TI-Connect is more up-to-date, 
       although it might not work with TI-83)
       Try googling
     When it is on your calculator, press the [PRGM] button (to the left of the purple 
       [APPS] button) then navigate (using the arrows) to MINES1, then press [ENTER]

 > General infomation
     At any time, press [MODE], [DEL], or [CLEAR] to quit
     When playing, press [TRACE] at any time to reset
       [TRACE] is located under the smiley face near the botton right of the screen

 > Menu:
     Press 1 to play
     press 2 to read (simplified)instructions
     Press 3 for contact infomation
     Or use the arrows and the enter key to navigate

 > Loading screen
     Wait until the loading screen disappears and is replaced by the playing field
     The mines and the numbers are being created during this time - please be patient
     This process should take only about 8-9 seconds

 > Playing field
     Use the arrow keys to move your square (initially located in the top, left hand corner)
     Press [Y=] or [2ND] to select a square
       If you hit a mine, you lose
       If you hit a number, it will be shown
       If you hit an empty space, the game will take some time to expand. During this time,
         please wait until the emoticon near the botton right corner resumes smiling
     Press [GRAPH] or [ALPHA] to flag a square
     Press [GRAPH] or [ALPHA] on a previously flagged square to unflag

 > Winning or Losing
     You win if you correctly flag all of the mines
       If the number of flagged squares equals the number of mines (shown at the top right corner)
         then you have flagged some squares incorrectly (this is your fault, not mine)
     You lose if you select a square over a mine
       Either quit, or reset (losing is not my fault, either)
     If you lose, the locations of all the mines will be shown (times symbol)
       Incorrectly flagged squares will be marked with an 'X'
     You cannot replay any previous fields
       (unless you store a number to rand, and store the same number before playing each time)



