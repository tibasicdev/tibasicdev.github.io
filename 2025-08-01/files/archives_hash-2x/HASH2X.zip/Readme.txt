HASH 2X
.8xp version by Jason Lee
calccrypto@yahoo.com

.pyn version programmed by 
Daniel Rosenwasser

HASH 2X is a small and fast multivariable hash function originally designed to be run on the TI-83/84 graphing calculator family.

Rather than having fixed sizes for outputs while using specific versions of the hash function, this program uses the same algorithm to hash any and all inputs greater than 0, assuming that the computer can handle the input. There are only 2 lists  and one base string involved in the hash computation.

The calculator version of HASH 2X is slightly different from the computer version in that the input size may be only at most 256 characters. The output must be at least 8 characters long. The outputs are stored in Str1.

The computer version of HASH 2X is a more flexible version of the algorithm, being that it was not only written in Python, but the input and output sizes are only limited to anything greater than 0, and as much as one's computer can handle. It can be run on any platform that can perform simple arithmetic and hold a set of data in a list.

HASH 2X.8xP has not been edited since October 25, 2008 and HASH 2X.pyn has not been edited since October 28, 2008.

____________________________________________

Install:
.8xp version:
Install TIConnect, link a TI-83/84 family graphing calculator, and transfer. All shells (MirageOS, CrunchyOS, DoorsCS, ION, CalcUtil) should be compatable.

.pyn version:
Download and install Python 2.6 from http://python.org/download/
____________________________________________

Copying:
Until further notice, the supplied code is not to be used for any purposes without the authors's consent other than as a future SHA-3 implementation, in which both authors must still be contacted.
____________________________________________
Bugs for HASH 2X.8xp
-Memory limit of 256 characters.
-Only characters can be used as inputs. Tokens will be considered spaces

Bugs for HASH 2X.pyn:
- Memory limits may be evident upon length entry.
- Unicode should be used instead of standard string; will be fixed with Python 3.0;
    - Will not be compatible for Python 3.0.
- Throws exception for empty input.
____________________________________________