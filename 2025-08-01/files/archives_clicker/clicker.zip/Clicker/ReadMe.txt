Clicker
version 2.1.1

Email:boringcreations@gmail.com
Blog:http://boringcreations.blogspot.com
Clicker has been entirely programmed by Gon�alo Vieira.

This game is compatible with the TI-83+,TI-83+ SE,TI-84+ and TI-84+ SE calculators. Older models will be incable of running this programm.
The game is entirely contained in a single programm named CLICKER, this game requires 2820 bytes of free Ram for the game itself and an extra 105 bytes of Archive memory for the highscores saved under LCLICK.
This games uses no librabries of any kind and is compatible with MirageOS.

Instructions for the game can be found on the programm itself under "Instructions" on the Main Menu.

This game's source code has been left unprotected so anyone can read and edit it freely for learning porpuses. 