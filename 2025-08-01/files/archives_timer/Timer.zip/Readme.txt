>---TIMER README---<


____________________     ______     ___________     __________       __________
|______     _______|     |    |     |         |     |         |     |   _____  |
       |    |            |    |     |  _   _  |     |  _______|     |   |   |  |
       |    |            |    |     | | | | | |     |  |            |   |___|  |
       |    |            |    |     | | | | | |     |  |___         |          |
       |    |            |    |     | | | | | |     |      |        |    ______|
       |    |            |    |     | | | | | |     |  ____|        |    \
       |    |            |    |     | | | | | |     |  |            |  |\ \
       |    |            |    |     | | | | | |     |  |______      |  | \ \ 
       |    |            |    |     | | | | | |     |         |     |  |  \ \
       |____|            |____|     |_| |_| |_|     |_________|     |__|   \_\  
   




>---DESCRIPTION---<
Timer is a program containing a digital timer, which counts down to an asked time. 
It displays the hours/minutes/seconds and the total seconds(including hours and minutes) left. 
It also contains an analog clock which shows the current time. 


>--USING--<
Start the program and enter the time you want to count down to.
The program starts showing the digital view, hit ENTER to go to the analog view.
Hit enter again to go back to digital, and so on.
Hitting any key but enter makes the program stop, and clear everything(I mean ClrHome, ClrDraw, AxesOn, etc..)


>--WARNING--<
You must have the time in your mode menu set right, otherwise the program displays wrong information.
Don't use ON to get out of the program (err.Break) but hit any key but enter. This means less work on clearing. 


>--Information--<
Made by HJTP in November/December 2008
