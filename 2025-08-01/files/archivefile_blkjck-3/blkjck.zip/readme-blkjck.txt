Blackjack
By Michael K. Pellegrino
Written entirely in z80 Assembler

To Run it:
Download the file blkjck.8xp
Transfer it to your TI83/83+/84/84+ calculator
Run the command: Asm(prgmBLKJCK

Gameplay:
This is a very basic version of blackjack.

Aces are worth 1 or 11.  Face cards are all worth 10.  All other cards are worth their numeric value.


You can bet anywhere from the minimum bet -> your total bankroll (which starts at $3,000).   Blackjack (21) pays 1.5 times your bet.

If you bet $0 the game exits.

When you exit, your bankroll is stored in the calculator so you'll have the same amount the next time you play.

You and the dealer are each dealt 2 cards.

If either you or the dealer have total of 21 right away, the hand ends in either a win (if you have 21), lose (if the dealer has 21), or a push (if you both have 21).

Otherwise you can hit (take another card) until your total gets sufficiently close to 21 without exceeding it.  If you exceed it, you lose.

Once you stand, it's the dealer's turn.  The dealer must hit until they get at least a 17 nd then the dealer stands.

Once the dealer stands, the scores are compared and the higher of the 2 wins.

When you run out of money that's it - you won't be able to play unless you register your copy at: http://mkpelleg.freeshell.org/blackjack.html

that's it.

any questions, please visit: mkpelleg.freeshell.org/blackjack.html
