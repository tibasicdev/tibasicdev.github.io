DStar
by Scott Davis
OLS		www.olsoft.tk
UTI		www.unitedti.org
BASIC Limits	www.basiclimits.tk

Intro:
This is a remake of DStar by Joe Wingbermuehle and Jason Kovacs.  Although the game is based off of theirs, I have included some changes of my own.  My version includes an on-calc level editor and support of external levels.  Also, it still has everything the other version has too, save and load game features, built-in levels, etc.

Game:
The object is to move the + around and collect all 5 of the . with as little moves as possible.  You can also switch spots with the box.  Try to beat all of the levels and even make your own!

Controls:
In the game, press 2nd to switch the + and the box, Alpha to start the level over again, trace to save the game, graph to load the saved game, del to exit, and arrow keys to move the + around.

The level editor is so simple to use, I don't even need to explain it, just press enter when your done making it. (Note, it will only let you have 5  .   and 1  +  and 1  box.)

NOTE: if you delete a custom made matrix, you must change its corresponding number (1 for [A], 9 for [I]) in list DSD to 0.

If you have any questions, comments, suggestions, email me at scott_shortonideas@hotmail.com
