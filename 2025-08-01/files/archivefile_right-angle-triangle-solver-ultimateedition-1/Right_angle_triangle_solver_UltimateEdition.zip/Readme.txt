Right angle triangle solver Ultimate Edition

Program is for right angle triangles only.
This program Draws a labeled picture and uses Sine Arcsin Cos arccos Tan & Arctan
This program will ask for 5 inputs (2 angles and 3 side lengths) press the "X" key (and enter to submit) for 3 of them and enter the values of 2 known ones the ones that were entered as "X" will be solved no menus needed the logic in the program will do the thinking for you.

Right angle triangle solver Ultimate Edition- Draws a picture of a right angle triangle in a split screen with the angles and the sides (opposite adjacent and hypotenuse) labeled. There are no additional files needed. It will save and restore your Xmax Xmin Ymax and Ymin and turn the axes back on as long as the program is ran to completion.

This program is powerful and unique and small at 959bytes of memory. It has built in error checking to avoid bad input from a user. Since it is a right angle triangle the 2 angles must add up to 90 degrees or an angle can not be over 90 degrees or the program will throw up an error code and ask for the angles again. Another level to the error checking is that it will only allow 1 or 2 angles and a side... Or it will allow only 2 sides with no angle. It will put up an error message if the inputs are too many.  The best way to use this program is with one angle and a side OR two sides and let the program figure it out.
