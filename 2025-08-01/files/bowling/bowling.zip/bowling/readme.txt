
 Bowling
 By nitacku

 nitacku@gmail.com
	 
=============================================================

 Contents


 I.	Included Files
 II.	Installation Procedure
 III.	Features of Bowling
 IV.	Playing the Game
 V.	Controls
 VI.	Credits
 VII.	Contact Information

=============================================================

 I.	Included Files


 Bowling.8xk		The Bowling game of course!

 xLIB.8xk		An assembly utility created by
			Patrick Prendergast. Manages all
			the graphics in the game

=============================================================

 II.	Installation Procedure

-------------------------------------------------------------

 Step 1:	Send the apps xLIB.8xk
		and Bowling.8xk to your calc

-------------------------------------------------------------

 Step 2:	Open xLIB and make sure to enable it

-------------------------------------------------------------

 Step 3:	Open Bowling and it will install
		itself automatically!

		If you get an ERR:MEMORY, just reset your
		RAM by pressing: 2nd, +, 7, 1, 2

=============================================================

 III.	Features of Bowling


 *  Arcade options let you choose from 4 different styles
    of bowling

 *  Choose up to 7 players of human/computer combination

 *  Advanced formulas programed into the simulator
    create realistic bowling action

 *  Bowl your way to world champion in 4 fast paced
    tournaments

 *  Earn money and purchase items to aid you on your journey
    to become world champion

 *  Save up to 3 games at the same time

 *  Compact into one program for easier archival

=============================================================

 IV.	Playing the Game


   _____________________
  /	 Main Menu	\
 |_______________________|_______________________________
 |							 \
 |	Classic		Uses standard rules of bowling	  |
 |							  |
 |	Arcade		Presents the user with 3 options  |
 |			of gameplay			  |
 |							  |
 |	One player	Sets up a bowling game for one	  |
 |			bowler vs. the computer		  |
 |							  |
 |	Mutiplayer	Sets up a bowling game for a user |
 |			defined number of computer/human  |
 |			bowlers				  |
 |							  |
 |	Quit		Quits the game to the homescreen  |
 |							  |
 \_______________________________________________________/


   _____________________
  /     Arcade Menu	\
 |_______________________|_______________________________
 |							 \
 |	Perfect		The first bowler to complete the  |
 |			list of bowling tasks wins	  |
 |							  |
 |	FastLane	The bowler with the most number   |
 |			of strikes, spares, and splits	  |
 |			after 10 frames wins		  |
 |							  |
 |	SpeedWay	The first bowler to race their	  |
 |			car to the finish line by	  |
 |			strikes, splits and spares wins	  |
 |							  |
 |	Exit		Leave to the Main Menu 		  |
 |							  |
 \_______________________________________________________/


   _____________________
  /      File Menu	\
 |_______________________|_______________________________
 |							 \
 |	New		Choose a file to hold a new game  |
 |							  |
 |	Load		Load a game saved in a file	  |
 |							  |
 |	Delete		Delete a game saved in a file	  |
 |							  |
 |	Exit		Leave to the Main Menu 		  |
 |							  |
 \_______________________________________________________/


   _____________________
  /    Classic Menu	\
 |_______________________|_______________________________
 |							 \
 |	Bowl		After packing your bag, enter a   |
 |			tournament to bowl a game	  |
 |							  |
 |	Pack		Pack the items you wish to take   |
 |			with you to the tournament	  |
 |							  |
 |	Shop		Purchase items to improve your	  |
 |			spin, accuracy, and velocity	  |
 |							  |
 |	Records		View the current records held	  |
 |			in each of the gametypes	  |
 |							  |
 |	Save		Save the current status of your	  |
 |			game				  |
 |							  |
 |	Exit		Leave to the Main Menu 		  |
 |							  |
 \_______________________________________________________/


   _____________________
  /   Tournament Menu	\
 |_______________________|_______________________________
 |							 \
 |	Continue	Enter the bowling simulator to	  |
 |			bowl the current frame		  |
 |							  |
 |	Scores		View the current scores for the   |
 |			game				  |
 |							  |
 |	Records		View the current records held	  |
 |			in each of the gametypes	  |
 |							  |
 |	Leave		Leave to the Main Menu		  |
 |							  |
 \_______________________________________________________/

=============================================================

 V.	Controls


 2nd		Used in all menus and parts of the game for
		selecting

 Enter		Used in all menus and parts of the game for
		selecting

 Clear		Used all throughout the game to
		instantly quit to the homescreen

 Arrows		Used to move cursor, navigate, and apply
		spin to the bowling ball

 Alpha		Used during the bowling simulator to change
		the balls direction of orbital spin

=============================================================

 VI.	Credits


 Patrick Prendergast for creating xLIB, an awesome asm
 utility that add extra functionality to basic programs.
 http://www.ticalc.org/archives/files/fileinfo/359/35907.html

 Brendan Fletcher for creating Xtravar, an asm program that
 enables basic programs to use even more variables.
 http://www.ticalc.org/archives/files/fileinfo/391/39138.html

 Martin Warmer for creating BasicBuilder, a computer program
 that packs Basic programs into applications.
 http://www.ticalc.org/archives/files/fileinfo/321/32127.html

 Last but not least,
 United-TI for all of their support and help :)
 http://www.unitedti.org

 Special Thanks goes to:
 luby
 bananaman
 tifreak8x
 Harrierfalcon

 If I missed anyone, please let me know! 

=============================================================

 VII.	Contact Information


 I can be reached by email at nitacku@gmail.com

=============================================================

		 Thank you for downloading!
		 I hope you enjoy this game!

=============================================================