		 _____ _       ______ _  __  __                                  
		/  ___(_)      |  _  (_)/ _|/ _|                                 
		\ `--. ___  __ | | | |_| |_| |_ ___ _ __ ___ _ __   ___ ___  ___ 
		 `--. \ \ \/ / | | | | |  _|  _/ _ \ '__/ _ \ '_ \ / __/ _ \/ __|
		/\__/ / |>  <  | |/ /| | | | ||  __/ | |  __/ | | | (_|  __/\__ \
		\____/|_/_/\_\ |___/ |_|_| |_| \___|_|  \___|_| |_|\___\___||___/
_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-__-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

Six Differences
An Angel production
Programed by Alex Marcolina
Email: Builderboy2005@yahoo.com
Based off the flash game

Continents of this file:
	SIX.8xp------The Game
	L1SIX.8xp----The first Level Pack
	SIXEDIT------The Level Editor
	ReadMe-------Your Reading It


Table Of Contents:
	I)  Introduction
	II) Instructions
	III)Level Packs
	IV) Using the level editor
	V)  Errors
	VI) Conclusion

_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-__-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_


I) Introduction
	
	Six Differences is a find the difference game, based off of the Flash Game of the same name.
In the game, you ar epresented with two versions of the same scene, with 6 differences hidden throughout
that you must locate.  featuring outstanding graphics for a BASIC game, Six Differences is fun, easy to
use, and small in file size.  With 9 levels in each level pack, and 9 level packs compatable with the game,
Six Differences can provide many math classes of entertainment. ;)


_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-__-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_


II) Instructions

	When you first put the game onto your calculator, transfer SIX.8xp and L1SIX.8xp to your calculator.
Archive everything exept L1SIX and run the program.  This will install the first 9 levels onto your calculator
It will create lists S0 through S9.  Do not tamper with these lists, or you risk loosing your
progress, or worse.

	After you install the level pack, you should get a confirmation message.  If you ever get a memory error,
archive some things, and try again.  If the problem ensues, contact me at Builderboy2005@yahoo.com and i will personaly
help you get the program to work.  With the level pack installed, you are set to run the game.

	To play the game, make sure you have everything else archived (As this game takes up a lot of resources) and run
program SIX.  You shoukld be greeted buy the Angel Productions logo when you first run it.  The program SIX creates list SX
to store progress, so do not tamper with that list either.  On the main screen, use the arrow keys to scroll left and right 
through the options.  Select play to start your game.  You will be presented with a list of numbers (only 1 if you are new)
and select one to play it.  The program will procede to build the level.  do NOT breakj the program by pressing the on
button at any time, as this has a high risk of eliminating your progress.
	
	Once the level is created, the number six will apear in the top right corner.  This indicates the number of differences
left to find.  Your sursor (a pixel) starts at the top right corner.  Move it around with the arrow keys.  Press alpha to
swich modes, where your sursor moves 5 times as fast.  Press alpha again to switch back.  Press 2nd when you think your currsor
is over a difference.   You can move your cursor all around the screen, and is not limited to only the left side. Once you find all
the differences, you will unlock the next level.  You can go back and play any level over again by selecting it from the main menu.


_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-__-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_


III) Level Packs

	Every level pack is installed the same way as the first.  Each level pack overrights
any other level pack installed, so you can only have 1 level pack installed at a time.  The
game also saves your progress through each level pack individualy.  So if you have progressed
through level 7 in pack 1, and then install pack 2, your progress on pack 2 will be 1, but
if you go back and install pack 21 anagin, you will still be up to level 7.

	On the main menu, it displays a message as to which level pack
is installed at that moment.


_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-__-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_


IV) Level Editor

	The level editor has no ingame documentation, and is a bit confusing, so it is recomended that you
read this before yoiu create any levels.  When you first run the level editor, it will give you the option
of creating a new level or loading an old one.  Choose new to start your new level.
	You will be presented with the level editing menu with these options.
Draw
Object
Options
Differences
Save
Exit

DRAW:
	You start out with a blank screen.  Your cursor moves like in the game, but can only move through half
of the screen.  to start drawing a line, press 2nd, and then move your cursor to create your line.  Press
2nd again to stop and set your line.  Create your scene in this manner, keeping in mind which differences you 
want to add.  If you screw up, the undo button is del.  You can undo any num,ber of lines.


OBJECT:
	You will be allowed to scroll through the lines by pressing the up and down keys.  You can add lines to
	groups by pressing the numbers 0 to 6.  These groups represent the lines that are inside the differences.
	On one side of the screen, they will be inverted.  

	NOTE: they will NOT be transparent, just inverted.  An inverted black line will overite anything below it.

	Line groups 1 3 and 5 will be inverted on the right side of the screen and groups 2 4 and 6 will be inverted
	on the left side of the screen.  Group 0 will be present on both sides.

	You can also change the collor of a line by pressing 2nd when it is selected, this changes its natural
	collor from black to white, or from white to black.


OPTIONS:
	There are three options for a level.  
		You can choose for the two images to be shifted or reflected
		You can choose for the center collomn to be on or off
		You cna choose for the screen to be normal or inverted.

DIFFERENCES:
	Here, it will ask you for groups 1-6
	Using your cursor much like in the draw function, trace 6 boxes around the
	differences.  Whenever the cursor is clicked inside the box, the difference is considered to be found.

Save:
	First it will prompt you for a name.  It must be 16 characters at max, and any invalic characters will\
	appear as blank spaces.  It supports Uppercase, lowwercase, numbers, and some symbols.
	Then your level will be compiled and stored to list 1
	You can then store it to any list of your choice.
	
To play custom lists, scroll to custom on the main menu and type in the name of the list.


_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-__-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_


V) Errors
	A list of possible errors you might get durring gameplay

	Error Memory:
		Archive some stuff
	Error Undefined:
		You tried to enter the name of a non-existant list in the custom level
		prompt
	Error Data Type:
		You entered something else other than a list when you tried to load a list
		into the level editor
	There is also an error produced ingame that occures if you tamper with the list data
	in the lists S0-S9 or SX.  When this error occurs, it assumes the worst and erases all
	progress.  So DON'T TAMPER WITH THE LISTS!!
			

_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-__-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_


VI) Conclusion

	Six Differences is a fun, challenging spot the differences game with great graphics, and many levels
for hours of entertainment.  Hopefully you enjoy this program, and find it as much of a joy to play, as I found
it to write.  If you find any bugs, or you have any suggestions, questions, or comments, just email me at
Builderboy2005@yahoo.com
I read all my emails and should get back to you within the day.

Thankz                                                              