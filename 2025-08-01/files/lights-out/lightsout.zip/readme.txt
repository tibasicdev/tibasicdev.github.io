Lights Out
by: Scott Davis
OLS		http://www.olsoft.tk
UTI, forums at	http://www.redelf.net/providence/forums
BASIC Limits	http://www.basiclimits.tk

Intro:

This is a perfect clone of the classic Tiger handheld game.  It features normal, random, and custom modes as well as a nice win sequence at the end if you win.  It's fast and looks great. (and yes, I made this game in two days!  I'm pretty proud of that :)

Controls:

After you first run the game, press a number, 1-4, depending on what mode you want or if you want to exit.  During the game, use the arrow keys to move the cursor, 2nd to select, and del to exit.

That's about it.  If you have any questions, comments, or suggestions, email me at scott_shortonideas@hotmail.com

Thanks!