Yahtzee - V1.0
By: Brad Wentz
TopDoggB@yahoo.com

To install, just send to your calculator and run YAHTZEE.8xp.

Yahtzee is the classic dice game everyone knows.  Completely graphical, up to 4 players, save game option, saves high score, displays which categories you qualify for, and runs really fast.  This game actually includes all rules of the real game including using the yahtzee as a joker, which the other yahtzee games seem to have forgotten.  This shouldn't have any bugs in it, but if it does please email me.