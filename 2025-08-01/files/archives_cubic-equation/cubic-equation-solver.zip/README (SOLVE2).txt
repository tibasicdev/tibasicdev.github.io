SOLVE2.8xp

SOLVE2 is a very simple program to solve cubic equations. 

Install it using TIConnect, send it to your TI-83- or TI84-family calculator.

You can simply edit the program or its name using TI-GRAPH LINK, which can be
downloaded at TI's website.

If it doesn't work, change your settings ('Mode' menu) from 'Real' to 'a+bi'.
If it still doesn't work well, contact me, and I will try to solve it.
I like to be contacted for this, because I can learn from solving these problems.

Solve2 was made by me to practise programming on my TI-84 Plus. 
I uploaded it to be freeware, so anyone can use it.
If you wish to change or improve it, please do so.
I would just like to be mentioned in the credits or something like that, 
and please send me the changed or improved version.

	-theFLyingDutchman

	sjorsdekkers@hotmail.nl