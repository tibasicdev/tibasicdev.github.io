Banana Catch v0.1
by Yousername

Banana Catch is a game in TI-Basic where you are a monkey and have to collect bananas, but not X's. The goal is to get as many points as you can before the timer (60 sec) gets to 0. Bananas give you 1 point and X's take away 1 point. If you don't collect a banana, you will lose 1 point. Along with bananas and X's, power-ups also fall from the sky. There are four power-ups: ✱, which slows the falling objects down, /, which gets rid of X's, +, which adds time to the timer, and 2, which doubles the effect of bananas and X's. The effect of power-ups depends on the upgrades you have, which can be bought in the shop using the points you earned.
To play the game, run prgmBANANAC.

Controls:
◄ ► to move
Enter to select

Files included in .zip:
Banana_Catch_v0.1.8xg
Banana_Catch_Readme.txt

If you have any suggestions or problems with the game, write a comment at http://tibasicdev.wikidot.com/archive:banana-catch.

CC BY-NC (http://creativecommons.org/licenses/by-nc/4.0/)