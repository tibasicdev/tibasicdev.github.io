Minesweeper release version 1.1, revision version 3.1
-----------------------------------------------------
Author: Timothy Foster

Minesweeper v3.0 is the upgraded version from v2.4.  Minesweeper is a game where you attempt to clear the board
of all the none mine squares while at the same time avoiding the activation of mine squares.  You move your cursor
and click on a space you believe is not a mine.  The space will then reveal a number which tells you how many mines
that are adjacent to the square othogonally and diagonally.  When you clear all the squares, then you win; if you
hit a mine, you lose.  Scoring is how long it takes you to finish.

This version of minesweeper has three levels of difficulty with low scores for each and a custom input field.
You can flag mines that you believe might be a mine.  When you hit a zero square, all the surrounding squares will
also reveal.  The loading time is a little long, but it is approximately 2 times faster from v2.4.

For the program to function correctly, the calculator version must be any of which supports time functions.
(84+/SE/).  Other calculators can support main code, but will not function correctly with the time commands.  If
you want to play this game and have a calculator without time functions, then remove from the code the commands:
:startTmr?T and :checkTmr(T)?A
Furthermore, take to consideration that the lowscore system will not be accurate.

There should be no initial set up required.  The lowscores are stored to list MINE, and it is set up at the
beginning of the program.  If it fails, please set it up with
:SetUpEditor LMINE
:{999,999,999?LMINE

Instructions on use:
You can press enter at the intro screen to immediately go to the menu.
At the title screen, press enter to proceed.
At the menu, press the number button that applies to your desired choice.  Press Clear to exit.
At the highscore and instructions page, press Enter to continue back to the menu.
When you click on one of the built in difficulties, then the program will immediately begin loading.
Note that there is no pause during gameplay.
Under custom, the max height is 10, the max width is 20, and the max bomb number is four less than the area.
The min height is 3, the min width is 3, and the min bomb number is 3.
Inputing numbers beyond those bounds will just set automatically to the lower or higher value.
During gameplay, move with the arrow keys.  Flag or unflag squares with the + key.  Reveal a square with Enter.
End the game to the menu with Clear.
In an emergency, press On to break the program.
Here is the breakdown of the difficulties:

Beginner
Height=7
Width=10
Bombs=8

Intermediate
Height=8
Width=16
Bombs=20

Expert
Height=10
Width=20
Bombs=44

Loading time is determined by the number of bombs, not dimensions.  The more bombs, the longer the loading time.
For boards almost entirely strewn with mines, the loading time could be very very long.  Please take that into
consideration.

The gameplay interface displays the boundaries by which you can go.  It also displays the amount of mines you have
not flagged, and it shows the current time.  There is also another little surprise...

Revision History

1.1: Made optimizations.  Fixed bug where custom game was failing sometimes.

1.0: The Original

Please feel free to examine the code and learn from it as well as implement any techniques you may discover.

~Timothy Foster