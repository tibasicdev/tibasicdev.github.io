Asteroids 3 CE v.8.1 ICE
Nick Pease
LAX18 - TIBD
The REAL LAX18 - Cemetech.net
-----------------------------------------------
Contents:
ASTEROID.8xp            Game File (Assembly)
RAND.8xp                Dependent File for ^
ASTSRC.8xp              Game File SRc (ICE)
screen1.gif             Gif Screenshot
------------------------------------------------
Description:
This game places you as the pilot of a spacecraft
tasked with the task of destroying incomming asteroids.
For every asteroid that you hit you gain a point, for every
asteroid that you miss, you lose a point.
------------------------------------------------
Installation:
Copy ASTEROID.8xp and RAND.8xp to your calculator (or CEmu). Run
ASTEROID.8xp by going to the catelog and selecting Asm(. Paste pgrmASTEROID
in this so it looks like Asm(pgrmASTEROID. Hit enter to play!
------------------------------------------------
Controls:
[<] Move ship left
[>] Move ship right
[Mode] Pause (any key to resume)
[Del] or [Clear] Exit
[^] or [2nd] Shoot

