Author...: Iambian Zenith (Rodger Weisman)
Date.....: July 30, 2009
Version..: 3.09s [A60E.PTI / 0626.WEMU]
Project..: Celtic III
Platform.: TI-83+ \ TI-84+ series
OS.......: 1.13+ (may work on earlier versions)
Package..: I forgot
____________
: WARNING! |
-----------/
THE FOLLOWING SERIES OF DOTS MUST FIT ON ONE LINE.
.............................................................................
DO NOT VIEW THIS DOCUMENT USING WORD-WRAP.
DO NOT USE THIS APP UNTIL YOU HAVE MASTERED TI-BASIC.
DO NOT READ THIS FILE UNLESS YOU CAN TAKE A JOKE.
DO NOT ASK FOR HELP UNLESS YOU SHOW YOU HAVE TRIED TO HELP YOURSELF.

IF YOU ARE DEVELOPING USING CELTIC III,
DO YOURSELF A FAVOR AND PRINT A HARDCOPY
OF THIS MANUAL

(or two, depending on how many trees you want dead)

Advanced notes can be found in MORESTUFF/FunStuff.txt
Read at your own risk.

_____________________
: TABLE OF CONTENTS |
--------------------/
Use the search function on the keyword to get to the topic.
If you can't use a search function, get a better text editor/viewer.

c001: FORWARD - What this app is all about. And what it's not.
c002: INSTALLATION 1 - Basic instructions.
c003: INSTALLATION 2 - Semi-automated installation.
c004: HOW TO USE - Basic instructions on using the app's functions.
c005: ACCESSING GROUPS AND APPVARS - How to "".
c006: WHAT NOT TO DO - A very short list of no-no's.
c007: COMMAND SET - Notes relating to reading the command set
c008: det() Celtic III COMMANDS
c009: identity() PicArc COMMANDS
c010: real() xLIB COMMANDS
c011: real() Partial Omnicalc compatibility COMMANDS
c012: ERROR SYSTEM OUTPUT - What is output if something goes "wrong"
c013: COMMAND LIST SUMMARY - Very short. Very concise. Very... shorthanded.
c014: TROUBLESHOOTING - Pathetic excuse for a FAQ.
c015: SPECIAL/GENERAL THANKS - Gotta thank those special ones.
c016: VERSION HISTORY - Don't even bother looking at this section. Seriously.
c017: MORE INFORMATION - Interesting extras. For using CIII to its fullest.
c018: COPYRIGHT NOTICE - Lawful? Don't read. Chaotic? Have fun. Evil? Enjoy.
c019: SPARE NOTES - Personal release notes. A short todo list.

____________
: FOREWARD | c001
-----------/
  Celtic III is a Flash Application for the TI-83 Plus, TI-83 Plus Silver
Edition, TI-84 Plus, and the TI-84 Plus Silver Edition graphing calculators
[ TI-83/84+(SE) ], designed to extend the functionality of these calculators
so that BASIC games and utilities can perform actions that cannot easily
be done through the language itself.

  Celtic III supports its own command set focused more on file handling and
manipulation. It also supports a command set used for manipulating image
files and screen data. It also supports decent compatibility with the popular
xLIB library so you don't have to change anything.

  Celtic III is in perpetual development. Some bugs may not have been fixed.
Some commands may not be available. Go to http://www.unitedti.org and find
this app under the featured programs list. Register for an account / log in
and post your concerns in that subforum.
__________________
: INSTALLATION 1 | c002
-----------------/

  Celtic III needs to be sent to the calculator before you can run it. Do so
by using your favorite computer to calculator linking software, like
TI-Connect or TiLP. After you have sent it to the calculator, the application
should appear in the APPS menu.

  Push the APPS button. The top of the screen will have the inverted word
"APPLICATIONS" and the line underneath that should be "1:Finance...". If you
see something like this, you're in the right place. Use the arrow keys to
scroll down to where it says "Celtic 3". If you cannot find that, you may
need to resend the application. If you have, press ENTER when you've selected
"Celtic 3" and the application will start up.

  When you start the application, you should see "Celtic 3" written in poor
ASCII art. You are prompted to push any key to continue. You are taken to a
menu where it prompts you to push a numkey to continue. This is a key on the
number pad that corresponds to the numbered options. Push (1) to select
"INSTALL" (or "UNINSTALL", if the app thinks it's already installed) and
follow the onscreen prompts until you make it back to the main menu.

  If the application has been successfully installed, option (1) in the main
menu will now read "UNINSTALL". If it still reads "INSTALL", repeat the
procedure in the last paragraph. If the app will still not install, ensure
that you are asking Celtic III to erase any pre-existing hooks during the
installation, if you have been choosing not to do so. The application should
then be installed.

  When you get to the main menu, press (3) to quit the application. You
should now be able to use Celtic III. Skip to the "USAGE" topic.
__________________
: INSTALLATION 2 | c003
-----------------/

  The following method requires that Celtic III is already on the calculator
in question. If it is not, follow the instructions in the first paragraph of
"INSTALLATION 1". Then proceed here.

  Send the assembly program "AINSTALL" found in the MOREINFO/AINSTALL/8xp_bin
folder to your calculator using your favorite calculator to computer linking
software.

  Whether on the homescreen, or in an installation subprogram, run the
program by typing this on the line:

 0:Asm(prgmAINSTALL

  The zero and colon puts the real number "0" in the Ans var and lets you
execute another command right after it. You can find the "Asm(" token in
the catalog (2nd + 0) and you can recall the entire "prgmAINSTALL" by pushing
the PRGM button and selecting "AINSTALL" from the menu.

  You will not be given any visual confirmation that the install took place,
but you will be able to tell by using the following code in a BASIC routine:

 :If det([[1]])
 :Then
 :Disp "CIII NOT INSTALLED"
 :Stop
 :End

  If Celtic III is not installed, the code between Then:End is run. If it is,
then the code is not executed. The reason this works is because Celtic III
catches a 1x1 matrix input into the det( instruction and returns 0. If
Celtic III is not installed, it returns whatever the determinant of a 1x1
matrix is (which is just the number itself).

  Even if you do not install Celtic III in this manner, it is good to check
for whether or not the user installed Celtic III using the manner shown
above.
______________
: HOW TO USE | c004
-------------/

  Celtic III catches certain commands as inputs for the application. The
first argument for any of these catched commands is always the command's
function number, which tells the application what it should do. These
commands are the following:

 det(
 identity(
 real(

  The det( and the identity( tokens will work as they normally do if used
as they were originally intended. Celtic III is smart enough to know whether
or not the command is for the TI-OS or for itself. (with the sole exception
of finding the determinant of a 1x1 matrix, but who would do that?)

  The real( token cannot be used as it was originally intended because xLIB
was that way, and the use of the real( token was to make it binary-compatible
with xLIB.

  The arguments after the function number are inputs for that particular
function. If a "real number" is specified, it can either be an immediate
value (such as 42) or a letter variable containing the real number
(such as K). Understand that this number MUST be real and not a complex
number (such as 3+2i). It'll make Celtic III choke in a heartbeat. You can,
however, pass negative numbers as arguments. The result will simply be the
two's compliment of the said number. Signed math is not performed.
If a "string" is specified, it can either be an immediate value
(such as "this is a string") or a string variable (such as Str7). A few
functions may make further restrictions, but they will be clearly explained
in the command set listing.

  Examples of commands are as follows (parens added for readability):
  
 det(0,"FOOBAR",4)    //uses the TOGGLESET command to delete program FOOBAR
 identity(0,"FOO",0)  //Formats program FOO for image database usage.
 real(0,1)            //Clears the screen buffer, then updates the display.

  The command set will define what is output from each of these functions.
If some sort of number or string is output, it will be that function's
"result" and can then be used as part of another function. An example is as
follows:

 det(29,det(31,det(28,"AAAA"),det(28,"5555"),2))

Explanation: The two inner det(28...) converts "AAAA" and "5555" from their
             hex notation into real numbers. They compose the first two
             arguments of det(28...), which is a command used to perform a
             bitwise logic operation on them. The 2 indicates that the OR
             logic is to be applied. The result of that is 65535
             The outer det(29...) takes one argument, and this is to convert
             a number to a hexadecimal string.
             
             The final result is the string "FFFF"

  I know, I know. It's easy to drown in that many det(...) commands, but your
for normal everyday uses, it won't be that confusing when you get down to
writing your own code.

  Sometimes one of these commands will NOT output a value. If the command set
does not mention an output, do not assume there will be any.
________________________________
: ACCESSING GROUPS AND APPVARS | c005
-------------------------------/
  Some commands will require a string containing the name of a program file.
Most commands will allow you to substitute the name of a program file for the
name of an application variable (appvar). The main benefit of using appvars
is that it doesn't clutter the programs menu, and they aren't readily
accessible by the user. The downside is that applications that use appvars
will EXPECT their own appvars to remain intact.

  In order to tell a command that it should be accessing an appvar instead of
a program file, insert the "rowSwap(" token at the beginning of the name.
An example is as follows:
 
 det(5,"FOOBAR",1)               //Outputs the first line of program FOOBAR
 det(5,"rowSwap(FOOBAR",1)       //Outputs the first line of appvar FOOBAR
 
  NOTES: You do not close the parenthesis on the rowSwap( token, as this can
         cause "File Not Found" errors at worst or if you're creating a file,
         an extra token at the end of the file that renders it inaccessible
         from any BASIC programs. Also, you can use lowercase letters to
         refer to appvars but NOT programs. If you try to name a program
         using lowercase letters, you'll get similar results as closing that
         parenthesis, except much worse.

  A select few commands require that the file specified is a group file.
Unfortunately, you are forced to use the "*row(" token as a prefix to tell
Celtic III that it is a group, even though the command does not take any
other type of file. You'll just have to deal with it.

 det(13,"*row(FOOBAR",1)         //Outputs size of first extractable far from
                                 //the group FOOBAR

  The parenthesis note also applies to this.
_________________
: WHAT NOT TO DO| c006
----------------/
  Obviously, don't try to use Celtic III in ways it wasn't intended. Sure,
you can abuse Celtic III to peform what you want, but I'm not responsible if
it crashes because you tried to input messed up arguments.

  Also, do not run BASIC programs that use this app from shells such as
MirageOS and DoorsCS. The Celtic III application has known compatibility
problems between itself and MirageOS. I don't know much about DoorsCS, but
I wouldn't trust the running of BASIC programs from it, either. If you're
rather adventurous, you could try, but I wouldn't recommend it.
_______________
: COMMAND SET | c007
--------------/
  For the first line of any command description is the command spelled out.

  The use of square brackets [ ] indicate an OPTIONAL input. If you do not
include that argument, the command will default that argument to zero (0) in
det( and identity( commands, and 32 in real( commands.

  The use of double-quotes indicate that a string is the argument. The stuff
in the quotes is simply a description of what is supposed to go in the string

  Any reference to "FILENAME" refers to a program, an appvar, a group, or
perhaps any combination of the above. It all really depends on the exact
nature of the command being used. See the ACCESSING APPVARS AND GROUPS
section if you don't understand that blurb. No, for real. Go read it. It
might give you ideas.

  Any commands that does not make the argument optional MUST HAVE A VALUE
IN THE ARGUMENT.

=================================================================== c008 ====
== CELTIC III BASE COMMAND SET ==============================================
=================================== Uses the det() token ====================
=============================================================================
| Code/Name     | Command Description
-----------------------------------------------------------------------------
|00             | det(0,"FILENAME",[function_number])
|               | 
|  TOGGLESET    | Performs an action with a file given the function_number
|               | provided. If function_number is...
|               | 
|               | 0 = Archive/unarchive a file. The output will be zero if it
|               |      has been unarchived. Some other number if archived.
|               | 1 = Lock/unlock a file. The output is 0 if unlocked, 1 if
|               |      it is locked, 2 if you attempted this on an appvar.
|               | 2 = Program to appvar and vice versa. A "1" will be output
|               |      if the operation was a success.
|               | 3 = Hide/unhide a file. Outputs 0 if the file is visible,
|               |      1 if it is now hidden.
|               | 4 = Delete. Just. Deletes a file. Not undoable. Be careful
|               |      on how you use this.
|               | 5 = Create. Creates a zero-sized file with the name you
|               |      choose. There so you can insert your own stuff in it.
|               | 6 = Prog to string. Outputs the entire program file into
|               |      a string so you can paste it into some other file.
|               | 7 = Output stats. Somewhat complicated. It outputs three
|               |      letters followed by five digits indicating its size.
|               |      Those three letters will tell you a lot about the file
|               |      
|               |      1st letter: A= archived, R= in RAM
|               |      2nd letter: H= hidden,   V= visible
|               |      3rd letter: W= writable, L= locked (uneditable)
|               |      
|               |      Naturally, archived files are uneditable.
|               |      To get just the size of the file, do this:
|               |      expr(sub(det(0,"FILENAME",7),4,5))
|               |      
|               | If you omit the function number, the command defaults to
|               | the archive/unarchive function. Useful for saving bytes.
-----------------------------------------------------------------------------
|01             | det(1,variable_of_any_real_type)
|               | 
|  NUMTOSTRING  | Converts any variable of the real type to a string. This
|               | includes real vars, real lists, and matrices. Useful if you
|               | want to store variables into program files, perhaps as a
|               | high score or just data storage for later use. Note that
|               | storing numbers this way takes up a whole lot less space
|               | unless your numbers are sporting many decimals.
|               | 
|               | If your input is a list and it is in quotes, you'll also be
|               | able to read that list even if it's from archive. For rules
|               | about inputting a list, see the GETLISTELEM command (02)
-----------------------------------------------------------------------------
|02             | det(2,"LISTNAME",[get_this_element])
|               | 
|  GETLISTELEM  | Gets an element from a list. If you could use the standard
|               | TI-OS function on it, you should, but this command is very
|               | useful if the list is ARCHIVED. Otherwise, it works just
|               | like your standard L1(n) command. If you omit the list
|               | element, or set it to zero, this function will return the
|               | dimensions of the list.
|               | 
|               | RULES:
|               | If the name is predefined (L1 thru L6), just put that in
|               | quotes. If it is a user-defined list, you must prefix the
|               | name with that little "L". This is done automatically if
|               | you paste the name of the list from the list variable list.
-----------------------------------------------------------------------------
|03             | det(3,argument_of_any_type)
|               | 
|  GETARGTYPE   | Outputs a real # depicting the type of variable that was
|               | input. A table follows of the possible non-erroneous input
|               | that can be made:
|               | 
|               |     Real = 0 
|               |     List = 1 
|               |   Matrix = 2 
|               | Equation = 3 
|               |   String = 4 
|               |  Complex = 12
|               | Cpx List = 13
|               | 
|               | Useful for determining whether or not an output to a Celtic
|               | III command was a number or an error. To prevent this from
|               | altering the Ans variable, use this command within
|               | If() statements and the like.
-----------------------------------------------------------------------------
|04             | det(4,function)
|               | 
|  CHKSTATS     | This is a multi-purpose command used to read some of the
|               | system's status. Just provide a function, and an output
|               | will result:
|               | 
|               | 0 = Outputs value of free RAM
|               | 1 = Outputs value of free ROM (Archive)
|               | 2 = Hex string output of first ten digits of calc serial
|               |     (still not quite enough to identify each calc)
|               | 3 = Get calc's OS version (string, such as "1.13")
|               |     (note that the period will be bugged. It still works)
-----------------------------------------------------------------------------
|05             | det(5,"FILENAME",read_this_line,[by_this_many_more_lines])
|               | 
|  LINEREAD     | Reads a file (BASIC program) starting at the specified line
|               | and, if included, reads that many more lines. If a number
|               | of lines is included, it adds that many more to the output.
|               | For example, if you wanted to read from the first line and
|               | grab one more line after that from the file "FOO", you'd
|               | have the following:
|               | det(5,"FOO",1,1)
|               | 
|               | If you just want to find how many lines there are in the
|               | file, just try to read the 0th line. It'll output a real
|               | number containing the number of lines in the file
-----------------------------------------------------------------------------
|06             | det(6,"FILENAME","STRINGTOWRITE",start_at_this_line) 
|               | 
|  LINEWRITE    | Writes the contents of a string to a file starting at the
|               | specified line. A newline character is appended to the end
|               | of the string you want to write, so you do not need to
|               | include it.
-----------------------------------------------------------------------------
|07             | det(7,"FILENAME",delete_this_line,[and_these_many_more])
|               | 
|  LINEERASE    | Deletes a line from a file starting at the specified line
|               | and if specified, deletes that many more lines from the
|               | file. This is NOT an undoable operation, so be careful.
-----------------------------------------------------------------------------
|08             | det(8,"FILENAME","STRINGTOREPLACE",start,[and_continue])
|               | 
|  LINEREPLACE  | Replaces the specified line at start with the contents of
|               | your string. If you specified a continue, it would
|               | truncate that many more lines.
|               | 
|               | For example, if you wanted to replace 4 lines with just the
|               | word "BAR" from the second line from the file "FOO"...
|               | det(8,"BAR","FOO",2,3)
-----------------------------------------------------------------------------
|09             | det(9,["SEARCHPHRASE"])
|               | 
|  FINDPROG     | The search phrase is NOT part of the filename. It is,
|               | instead, the leading characters in the file you want to
|               | search for. The output will be a space-delimited
|               | (separated by spaces) string containing the names of the
|               | files that match the search phrase. For example, say you
|               | had a few programs that start with ":CCN". You would get
|               | all files that would match that if you did
|               | det(9,":CCN")
|               | 
|               | If you wanted to get a complete program/appvar file listing
|               | then you'd just omit the search phrase. You will get some
|               | oddly-named program files as the first of the results,
|               | since they are system-reserved program files with illegal
|               | file names.
|               | 
|               | A neat little example with this command is locating all
|               | ION-type files. For that, you'd use an additional command
|               | inline with this one.
|               | 
|               | det(9,det(17,"BB6DC930"))
|               | 
|               | That command uses the HEXTOBIN command to convert the hex
|               | to the binary that ASM programs (w/ION Head) are stored in.
|               | 
|               | NOTE: This command is not to be confused with GETPROGLIST,
|               |       which outputs a string consisting of files whose
|               |       NAMES start with the specified characters.
-----------------------------------------------------------------------------
|10             | det(10,"GROUPFILENAME",[option])
|               | 
|  UNGROUPFILE  | Fully ungroups files using an experimental routine designed
|               | to overcome the OS version @ | > 1.13 limit. Buggy, but
|               | should still work for program-type-only group files.
|               | 
|               | Default behavior is to skip any pre-existing files, but
|               | if [option] is set to 1, the behavior changes to overwrite.
|               | Careful when you do this because overwritten files are
|               | gone. Forever if in RAM and in archive if a garbage-collect
|               | was done over after the file went missing.
-----------------------------------------------------------------------------
|11             | det(11,"GROUPFILENAME")
|               | 
|  GETGROUP     | This generates a space-delimited string containing all the
|               | file names of programs and appvars that are found in the
|               | group in the order that they are found. The order is
|               | important, as it lends itself well to the next command
-----------------------------------------------------------------------------
|12             | det(12,"GROUPFILENAME",extract_this_item)
|               | 
|  EXTGROUP     | Extracts the nth item from a group in the order it was
|               | found from the previous command.
|               | 
|               | Outputs a real "1" if this command was successful.
-----------------------------------------------------------------------------
|13             | det(13,"GROUPFILENAME",get_size_of_this_item)
|               | 
|  GROUPMEM     | Instead of extracting the nth item from a group, this
|               | determines how much data is in the file. Add some
|               | reasonable number, like 13, and you have the amount of
|               | memory this file would take up in RAM if you were to
|               | extract this. Great for group extraction managers.
-----------------------------------------------------------------------------
|14             | det(14,"FILENAME",start_at_this_byte,read_this_many_bytes)
|               | 
|  BINREAD      | Reads a file starting at a specified byte and continues
|               | reading for the specified number of bytes. The output will
|               | be a hex string representing those bytes.
|               | 
|               | The zeroth byte is the start of the file.
|               | 
|               | Additional note: The starting point will accept a negative
|               | number but it'll only work correctly if the file is in RAM.
-----------------------------------------------------------------------------
|15             | det(15,"FILENAME","HEXSTRING",start_at_this_byte)
|               | 
|  BINWRITE     | Converts the hex string into bytes and then inserts that
|               | data into a file starting at the specified byte.
|               | 
|               | The zeroth byte is the start of the file.
-----------------------------------------------------------------------------
|16             | det(16,"FILENAME",start_here,delete_this_many_bytes)
|               | 
|  BINDELETE    | Deletes a number of bytes from a file starting at the
|               | specified location.
|               | 
|               | The zeroth byte ...meh.
-----------------------------------------------------------------------------
|17             | det(17,"HEXSTRING")
|               | 
|  HEXTOBIN     | Outputs the binary equivalent of an input string. For
|               | example, if you did this
|               | det(17,"41424344")
|               | The result would be:
|               | "ABCD"
|               | Since each of those hex digits equate to the tokens 'A',
|               | 'B','C', and 'D' in that order.
|               | Very useful if you want to provide input that would other-
|               | wise be impossible from BASIC, such as the start of an ION
|               | shell header for the FINDPROG command, or supplying binary-
|               | only input for some of the few commands that require it.
|               | 
|               | This command replaces the TOKENCODE command, since using
|               | HEXTOBIN is more convenient due to the fact that most token
|               | equates are in hexadecimal, not decimal. You can also grab
|               | as many tokens as you want through this.
|               | 
|               | For a listing of tokens, see the contents of the MOREINFO
|               | folder located within the main folder of the Celtic III
|               | distribution.
-----------------------------------------------------------------------------
|18             | det(18,"BINSTRING")
|               | 
|  BINTOHEX     | Just the opposite of the HEXTOBIN command. This converts
|               | a binary string back to hexadecimal. Useful for making
|               | sense of some ASM code/data files.
-----------------------------------------------------------------------------
|19             | det(19)
|               | 
|  FASTCOPY     | It calls the IonFastCopy routine. lolwut? 
|               | 
|               | It updates the screen with the plotsscreen buffer. lolwut?
|               | 
|               | It copies the buffer to the screen. lolwut?
|               | 
|               | It... If you get down to here, you fail. At life.
-----------------------------------------------------------------------------
|20             | det(20,"HEXSTRING")
|               | 
|  EXECHEX      | It converts up to 767 bytes into code (1534 hex characters)
|               | and executes it from the savesscreen buffer, useful for
|               | implementing simple stuff that was missed by a library as
|               | large as Celtic III.
|               | 
|               | Although it automatically appends a C9 (RET) instruction at
|               | the end of the string, you can still seriously screw up
|               | your calculator if used with erroneous ASM code.
-----------------------------------------------------------------------------
|21             | det(21,StringVar,at_this_byte,replace_with_this_byte)
|               | 
|  EDIT1BYTE    | Replaces a byte in some string variable, Str1 to Str0,
|               | using a decimal number 0 thru 255 in replace_with_this_byte
|               | within that string at this specified offset (at_this_byte),
|               | all of which start at zero. You will get an error if you
|               | try to overwrite something past the end of this string.
|               | 
|               | Since the specified string is edited directly, there will
|               | be no output and thus keep Ans intact, except if an error
|               | occurred. This means you cannot put in an immediate string
|               | as nothing but a discarded temporary variable will have
|               | been changed. Useful for quiety editing a string.
-----------------------------------------------------------------------------
|22             | det(22,function,offset,[newvalue])
|               | 
|  MODECHANGE   | Allows one to read or change stuff in Celtic III's hidden
|               | appvar. Used for settings or reading status of delayed
|               | functions. The offset starts at 0.
|               | 
|               | If function= ...
|               |  0: Reads data at offset.
|               |  1: Writes [newvalue] to the offset. Old value is read out
|               | 
|               | More information about which offset does what will be
|               | explained later.
|               | 
|               | Try not to pass bogus values into this command, as you CAN
|               | cause improper application function if used incorrectly.
|               | 
-----------------------------------------------------------------------------
|23             | det(23,"FILENAME","INDEXNAME")
|               | 
|  INDEXFILE    | Creates an index of a program file and stores it as another
|               | program file as indicated by INDEXNAME. This is for use
|               | with the following command, LOOKUPINDEX.
|               | 
|               | Any pre-existing files will be overwritten automatically,
|               | as if to udate the index, so please take care that an
|               | important file is not specifed. If the new index cannot
|               | be fit in memory after the old one is deleted, a new one
|               | is not created. Unfortunately, you will have lost the old
|               | index. Keep a tight rein on memory.
-----------------------------------------------------------------------------
|24             | det(24,"FILENAME","INDEXNAME",this_line,[by_this_many])
|               | 
|  LOOKUPINDEX  | Uses the index file specified for quicker and much more
|               | consistent lookup of lines in a file. Very useful for large
|               | data files that would take a while to scan through using
|               | the normal lookup method.
|               | 
|               | The major drawback is that once a file is indexed, the file
|               | cannot be changed unless re-indexed by command 23.
|               | 
|               | A good feature is that for purely read-only purposes, 
|               | BOTH the program and index files can be archived.
-----------------------------------------------------------------------------
|25             | det(25,function,Str?) ****NOT FULLY IMPLEMENTED****
|               | 
|  ERRORHANDLE  | Executes BASIC code with an error handler installed.
|               | That means if the code you execute can do anything it wants
|               | including divide by zero. The execution will end but an
|               | obvious system error will not trigger. Instead, this
|               | function will return with a value that indicates the
|               | error condition.
|               | 
|               | If function = 0, the indicated string contains the name of
|               |    the program to execute with these special parameters.
|               | If function = 1, the string contains the program code
|               |    itself. Just don't do anything complicated in it.
|               | 
|               | Do not recurse and certainly try not to call this command
|               | inside any program or subroutines you've already called
|               | this command in. If you attempt to do so, the original
|               | calling routine will be lost.
-----------------------------------------------------------------------------
|26             | det(26,Matrix#)
|               | 
| MATTOSTR      | Outputs a hex string based on the input matrix, for use
|               | with PicArc's STRINGTILE command.
|               | 
|               | Any entry in a matrix over 255 will be treated as
|               | matrix_element modulo 256.
-----------------------------------------------------------------------------
|27             | det(27,"binstring",start,readthismany)
|               | 
| STRINGREAD    | Works almost identical to BASIC's sub() command, except
|               | that the output will be in hexadecimal and two-byte
|               | tokens will read as two instead of one byte. Useful for
|               | extracting data from a string that may contain nonsensical
|               | data that simply needs to be manipulated.
|               | 
|               | If you allow the start point to be zero, the size of the
|               | string in bytes is taken.
|               | 
|               | For data manipulation, you should use the EDIT1BYTE
|               | command.
-----------------------------------------------------------------------------
|28             | det(28,"HEXSTRING")
|               | 
|  HEXTODEC     | Converts up to 4 hex digits back to decimal. Useful for
|               | the previous command. If you pass a string longer than 4
|               | digits, only the first four are read.
-----------------------------------------------------------------------------
|29             | det(29,SomeRealNumber,[autooverride])
|               | 
|  DECTOHEX     | Converts a number between 0 and 65,536 to its hexadecimal
|               | equivalent. The number of hexadecimal output to the string
|               | will have its leading zeroes stripped so inputting 15 will
|               | result in "F" and 16 will result in "10". Set autooverride
|               | to 1 to output all leading zeroes, which may be useful for
|               | routines that require four hex digits at all times but
|               | cannot spend the memory/time whipping up a BASIC solution
|               | to fill the missing zeroes.
-----------------------------------------------------------------------------
|30             | det(30,Str?,starting_byte,replace_with_this_word)
|               | 
|  EDITWORD     | Note: A "word" in this sense is two bytes. Useful for
|               |       editing a binary string which entries are all two
|               |       bytes in length, such as a special string tilemap.
|               |       You're required, however, to specify offset in bytes.
|               |       Also know that all words are stored little-endian.
|               |       That means that the least significant byte
|               |       is stored before the most significant byte is.
|               | 
|               | This command, otherwise, works just like EDIT1BYTE. Its
|               | documentation is rewritten here for convenience.
|               | 
|               | Replaces a word in some string variable, Str1 to Str0,
|               | with a replacement value 0 thru 65535 starting at some
|               | specified byte (start is at 0).
|               | 
|               | The string supplied is edited directly so there's no 
|               | output, per se. See EDIT1BYTE for more details.
|               | 
|               | The replacement is written in little-endian form and if the
|               | number is between 0 and 255, the second byte is written in
|               | as a zero.
-----------------------------------------------------------------------------
|31             | det(31,value1,value2,logic)
|               | 
|  BITOPERATE   | Performs a bitwise operation between value1 and value2
|               | using a supplied logic value.
|               | 
|               | Logic: NONE=0 AND=1 ; OR=2 ; XOR=3
|               | 
|               | These numbers are converted to a 16-bit number and then the
|               | operation is carried out in order to maintain simplicity.
|               | 
|               | If the numbers are out of bounds, then the function will
|               | exit out with an error. If a negative number is introduced,
|               | it will be treated as 65536-abs(value).
|               | 
|               | This command really helps mask out hex digits but if you
|               | use strings to store those digits, you'll need to use
|               | the HEXTODEC command for each value you need. This can
|               | easily be done inline, as the example shows:
|               | 
|               | det(31,det(28,"AAAA"),det(28,"5555"),2)
|               | 
|               | That example should turn out to be 65535, or "FFFF" if you
|               | were to extend the idea of functions:
|               | 
|               | det(29,det(31,det(28,"AAAA"),det(28,"5555"),2))
|               | 
|               | Crazy, huh?
-----------------------------------------------------------------------------
|32             | det(32,"SERACHSTRING",SearchType)
|               | 
| GETPROGLIST   | This function will return a space-delimited string
|               | consisting of the names of programs/appvars that match
|               | partial name of the SEARCHSTRING. Which is to say...
|               |
|               | det(32,"TEMP") 
|               | 
|               | would return all program names that start with the
|               | characters "TEMP", which may be something like "TEMP001 "
|               | or "TEMP001 TEMP002 TEMP003 ", etc.
|               | 
|               | If SearchType = 1, appvars will be searched for
|               | If SerachType = 2, groups will be searched for
|               | 
|               | This function will not look for lists. This is easy enough
|               | to do using other BASIC commands and Celtic III commands.
|               | 
|               | NOTE: This command is NOT to be confused with FINDPROG,
|               |       which outputs a string consisting of files whose
|               |       CONTENTS starts with the specified string.
|               |
|               |       Also use the fact that the final name in the list
|               |       is terminated with a space to make extracting names
|               |       from the list easier.
|               |
|               |       Unlike all the other commands, this one will not
|               |       find hidden variables. You'll have to manually use
|               |       the starting character that the file was hidden by.
|               |       Celtic III gives you all the tools needed to do this
|               |       but you'll need to read the CIII tutorial to find out
|               |       how to do this. (tutorial coming eventually)
-----------------------------------------------------------------------------
|33             | det(33
|               | 
|  DOLINK       | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
-----------------------------------------------------------------------------
|34             | det(34
|               | 
|  ONBLOCK      | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
-----------------------------------------------------------------------------
:
:
:
:
:
:                               THIS SPACE IS
:                            INTENTIONALLY BLANK
:                                    LOL
:
:
:
:
:
:
=================================================================== c009 ====
== CELTIC III PICARC EXTENDED COMMAND SET====================================
=========================================== uses the identity() token =======
=============================================================================
| Code/Name     | Command Description
-----------------------------------------------------------------------------
|00             | identity(0,"DATABASENAME",function,db_arg1,db_arg2)
|               | 
|  DBQUERY1     | A nifty little function that allows many kinds of
|               | operations to take place with the PicArc database.
|               | The db_argument will vary depending on what you
|               | are going to do, but not by that much. Just read below.
|               | 
|               | If function = ...
|               | 
|               | 0 = Format this database. Just like anything that says
|               |     "FORMAT", you lose all preexisting data if that
|               |     file happens to already exist. This is not an undoable
|               |     action, so take care. If the file does not already
|               |     exist, it is created and then formatted. After you
|               |     use this command, you will be able to work around
|               |     with the file as a PicArc database. No arguments needed
|               | 
|               | 1 = Append a picture file. db_arg1 will be the pic number
|               |     you want to refer to. For Pic1, argument will be
|               |     1, for Pic9, it'll be 9. For Pic0, it'll be 10. Keep
|               |     in mind that this command only appends Pic files. No
|               |     insertion is available, so be careful on the order of
|               |     Pic files you append.
|               |     
|               | 2 = Delete an entry. Starting at db_arg1 = 0, this command
|               |     removes the specified entry off of the database. This
|               |     command is NOT undoable, so exercise extreme caution.
|               |     
|               | 3 = Retrieves the number of entries in the database.
|               | 
|               | 4 = Works just like function 1, except that this command
|               |     will attempt to compress the pic. It automatically
|               |     chooses the method of best compression so you'll always
|               |     get the smallest entry that the application is capable
|               |     of making, but using this command may be a little
|               |     slower than its counterpart. All the other commands
|               |     transparently decompresses compressed entries without
|               |     much of a speed loss.
|               | 
|               | 5 = Copies the entry denoted by db_arg1 to the graph
|               |     buffer with the logic indicated by db_arg2.
|               |     0: REPLACE, no screen update.
|               |     1: AND,     no screen update.
|               |     2: OR,      no screen update.
|               |     3: XOR,     no screen update.
|               |     4: REPLACE, the screen is updated.
|               |     5: AND,     the screen is updated.
|               |     6: OR,      the screen is updated.
|               |     7: XOR,     the screen is updated.
|               | 
|               | 6 = Copies an entry from the database as denoted by
|               |     db_arg1 (starting at zero) to a Pic file as denoted by
|               |     db_arg2. For example. to copy entry 6 of the database
|               |     "FOO" to Pic1, do the following:
|               |     identity(1,"FOO",6,6,1)
-----------------------------------------------------------------------------
|01             | identity(1,pic_number,function,[arg_1,arg_2...])
|               | 
|  TOGGLEPIC    | This command takes Pic X (Pic0 = 10) and performs an action
|               | designated by a function number. If arg_1 = ...
|               | 
|               | 0 = Copies Pic file to the graph buffer using logic method.
|               |     arg_1 specifies the Pic file
|               |     arg_2 specifies the logic code. The supported codes are
|               | 
|               |     0: REPLACE, no screen update.
|               |     1: AND,     no screen update.
|               |     2: OR,      no screen update.
|               |     3: XOR,     no screen update.
|               |     4: REPLACE, the screen is updated.
|               |     5: AND,     the screen is updated.
|               |     6: OR,      the screen is updated.
|               |     7: XOR,     the screen is updated.
|               | 
|               | 1 = Creates a new pic file using the contents of the
|               |     graph buffer. Any preexisting picture will be replaced.
|               | 2 = Swaps a pic file between archive and RAM. If it is now
|               |     in RAM, the output is 0, else it is some other number.
|               | 3 = Deletes a picture. This is not an undoable action,
|               |     so be cautious while using this function.
|               | 
-----------------------------------------------------------------------------
|02             | identity(2,"GROUPFILENAME")
|               | 
|  GETPICGROUP  | Outputs a list containing all the names of the pic files
|               | in the TI-OS group file. Each name is denoted by a number.
-----------------------------------------------------------------------------
|03             | identity(3,"GROUPFILENAME",pic_name_in_group)
|               | 
|  EXTPICGROUP  | Copies a pic by name from the group and puts it into a pic
|               | file of its corresponding number. Any preexisting pic files
|               | are overwritten.
-----------------------------------------------------------------------------
|04             | identity(4,"BINSTR",xPos,yPos,Width,Height,StartX,EndX,
|               | SStartY,SEndY,Pic#,Logic,TileSize,Update_LCD,2ByteMode)
|  STRINGTILE   | 
|               | See xLIB command "DrawTileMap" for information regarding
|               | the inputs. The only difference is that "Matrix_name" is
|               | replaced with "BINARYSTRING". For this, you supply a hex
|               | string converted to binary with the HEXTOBIN command.
|               | The Height and Width property of the command is used to
|               | provide a two-dimensional matrix feel to an inherently one-
|               | dimensional structure that is a string.
|               | 
|               | If 2ByteMode is set to something other than 0, then the
|               | input string is considered words instead of bytes. This
|               | allows the user to use 4 hex ditgits (two bytes) per tile
|               | so up to 65536 different tiles can be accessed using this
|               | command.
|               | 
|               | All other arguments function as they do with the xLIB
|               | command.
|               | 
|               | As a developer, you should develop your tilemaps in hex
|               | and then use the HEXTOBIN command to convert it to the
|               | format required by this command. To edit this tilemap, you
|               | should use the EDIT1BYTE command while this tilemap is in
|               | its binary format.
|               | 
|               | Note that any missing arguments will default to the value
|               | of zero (0) instead of 32 as in xLIB.
-----------------------------------------------------------------------------
|05             | identity(5,"HEXSTRING",x,y,w,h,logic,flip,update_lcd)
|               | 
|  PUTSPRITE    | Works just like the xLIB command real(1,...) except that 
|               | the Pic and the coordinates on that Pic file are not
|               | defined.
|               | 
|               | Instead, a string consisting of hex digits is used to
|               | define the sprite as inline data. For example, if you
|               | wanted to draw a black 8*8 block at the top-left corner of
|               | the screen with XOR logic and drawn immediately...
|               | 
|               | identity(5,"FFFFFFFFFFFFFFFF",0,0,1,8,3,0,1)
|               | 
|               | Useful for those that want to display sprites without the
|               | use of bulky image files.
|               | 
|               | For large sprites, each byte goes LEFT first, then DOWN,
|               | so specifying "80FF0180000180000180FF01" would relate to
|               | such a perfect box 3 bytes wide and 4 pixels down.
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | 
|               | Note that any missing arguments will default to the value
|               | of zero (0) instead of 32 as in xLIB.
-----------------------------------------------------------------------------
|06             | identity(6,shift_number_of_times,direction,screen_update)
|               | 
|  SHIFTSCREEN  | Shifts the image on the graphbuffer a number of times in
|               | a direction indicated below.
|               | 
|               |       left : 1
|               |      right : 2
|               |         up : 4
|               |    up-left : 5
|               |   up-right : 6
|               |       down : 8
|               |  down-left : 9
|               | down-right : 10
|               | 
|               | If screen_update is zero, the screen will not update.
|               | Otherwise, it will update.
-----------------------------------------------------------------------------
|07             | identity(7,x_left,y_top,x_right,y_bottom,display_method)
|               | 
|  DRAWBOX      | Draws a box which corners are (x_left,Y_top) and
|               | (x_right,y_bottom) using a specified display method.
|               | 
|               | Since this display method code is not complete, let's say
|               | that it is xLIB-compatible with the drawshape command,
|               | minus three. Add 128 to this number and the screen will
|               | also be updated.
-----------------------------------------------------------------------------
|08             | identity(8,"HEXSTRING",Right,Down,LOGIC,UpdateLCD)
|               | 
|  FILLMAP      | A command that fills the screen with the same 8 x 8 tiles
|               | as defined by 16 hex digits. Along with the right and
|               | down shift arguments, this command makes scrolling
|               | backgrounds far easier.
|               | 
|               | The hexstring, as said before, is 16 digits long, 8 pairs
|               | which makes up an 8 by 8 pixel tile.
|               | 
|               | The right and down arguments determine how many pixels
|               | the filled map should be shifted. You can either choose
|               | not to shift or shift in either direction up to 8 pixels.
|               | Since the routine does mod 8, you can actually have these
|               | numbers increment and decrement bounded by -65565 to 65535
|               | so you should not actually have to test for bounds save for
|               | those already mentioned.
|               | 
|               | LOGIC applies a method used to write the tiles to the
|               | buffer. 0=overwrite ; 1=AND ; 2=OR ; 3=XOR
|               | 
|               | If UpdateLCD is anything other than zero, the screen is
|               | updated with whatever was just written to the buffer.
|               | 
|               | Additional note: The bounds are actually -99999 and 99999
|               | and it'll still function properly due to how the custom
|               | float to integer routine works. This "bug" is not likely
|               | to be fixed. It's not hurting anything. It's safe. No one
|               | is gonna wait at a menu for as long as it takes to cycle
|               | through the routine *that* many times.
-----------------------------------------------------------------------------
|09             | identity(9,x,y,w,h,Dir,Type,Repeat,LCD_update)
|               | ***NOT FULLY IMPLEMENTED YET***
|  BOXSHIFT     | This command shifts or rotates within a box-shaped area on
|               | the screen (and may be the whole screen if you want).
|               | 
|               | x = top-left corner x, 0 thru 11. (each 8 pixels is a byte)
|               | y = top-left corner y, 0 thru 63.
|               | w = width of box object, 1 thru 12. Specifies byte widths.
|               | h = height of box object, 1 thru 64
|               | 
|               | Dir : Each will have a basic direction followed by
|               |       what you must add to it in order to perform
|               |       a different type of shift.
|               |       left = 1
|               |      right = 2
|               |         up = 4
|               |    up-left = 5
|               |   up-right = 6
|               |       down = 8
|               |  down-left = 9
|               | down-right = 10
|               | 
|               | Type: Determines what type of shifting is to take place
|               |       0 = Keep bit being shifted in
|               |       1 = Shift in a black bit (for black backgrounds)
|               |       2 = Shift in a white bit (for white backgrounds)
|               |       3 = Let bit that shifts out reappar on other side
|               |           (for scrolling backgrounds)
|               | 
|               | Repeat: A number that repeats the shift operation as 
|               |         many times as specified. Cannot be zero.
|               | 
|               | LCD_update: If it is a number other than zero, the screen
|               |             is updated with the results.
|               | 
|               | Notes: The routine does not perform clipping. All
|               |        coordinates and dimensions must remain onscreen.
|               | 
|               | Tips: If you don't update the LCD, this command is real
|               |       useful for dynamically editing tilemaps by loading
|               |       them to the buffer, using this command to edit them,
|               |       then store them back to the pic file, all without the
|               |       buffer ever being updated. The procedure is fast
|               |       enough to be dismissed as a slight slowdown due to
|               |       the BASIC parser.
-----------------------------------------------------------------------------
|10             | identity(10,flag,[x,y],"TEXT")
|               | 
|  DRAWTEXT     | Draws text to the graph screen with the coordinates x,y
|               | using the small font. The screen is NOT updated. If you
|               | wanted to updated it, you should've used the Text() command
|               | instead.
|               | 
|               | If you omit the x,y coords, the text is drawn to the last
|               | coordinate the previous DRAWTEXT command ended up. Does not
|               | line-wrap. It's your duty to do that yourself.
|               | 
|               | If you don't want the text to be modified in any way, set
|               | flag to zero. If you want to modify, you should do addition
|               | to the value using these numbers:
|               | 
|               | +1 = Draw using large font.
|               | +2 = Erase 1 row of pixels below the small font base
|               | +4 = Invert text
|               | +8 = Hex string is used in place of text to use font map.
|               |      If you know the character's hex value, you can use it.
|               |      Advantage: Get chars you can't access any other way.
|               | +16= Update screen anyway. Just a throwback.
|               | 
|               | Example: I want to use the large font AND invert text
|               |          at x=4 and y=8 using "THIS IS TEXT" as text.
|               | identity(10,0+1+4,4,8,"THIS IS TEXT")
|               | - or -
|               | identity(10,5,4,8,"THIS IS TEXT")
|               | [ note that the flags have been condensed ]
|               | 
-----------------------------------------------------------------------------
|11             | identity(11,...)
|               | 
|  COPYBOX      | Not implemented yet. Hope to implement it soon, as it will
|               | be one of the more useful functions in the Celtic III
|               | PicArc extension code.
|               | 
|               | 
|               | 
|               | 
|               | 
-----------------------------------------------------------------------------
:
:
:
:
:
:                               THIS SPACE IS                          (ALSO)
:                            INTENTIONALLY BLANK
:                                    LOL
:
:
:
:
:
:
=================================================================== c010 ====
== CELTIC III - XLIB COMPATIBILITY COMMAND SET===============================
=============================================== uses the real() token =======
=============================================================================
| Code/Name     | Command Description
-----------------------------------------------------------------------------
|00             | real(0,update_lcd)
|               | 
|  ClearScreen  | Clears off the graph buffer.
|               | update_lcd=...
|               | 0: Do not update
|               | 1: Update the cleared screen
-----------------------------------------------------------------------------
|01             | real(1,x,y,w,h,pic_n,pic_x,pic_y,logic,flip,update_lcd)
|               | 
|  DrawSprite   | Draws a sprite on the screen at (x,y), being the top-left
|               | corner of the sprite.
|               | 
|               | W = width in bytes. i.e. 1=8pixels, 2=16pixels, etc to 11=.
|               | H = heigth of sprite in pixels.
|               | 
|               | pic_n refers to the pic # to source the sprite from. Pic1=1
|               | , Pic9=9, Pic0=10. Use your imagination for other numbers.
|               | 
|               | pic_x and pic_y are the top-left coordinates to start
|               | sourcing the sprite from. pic_x MUST be 0 thru 11 as they
|               | are "aligned". On-screen, this is a multiple of 8.
|               | 
|               | "logic" is a number 0 thru 3, refers to sprite drawing
|               | method to employ.
|               | 0:Overwrite
|               | 1:AND
|               | 2:OR
|               | 3:XOR
|               | 
|               | If 4 is added to "logic", the sprite will be inverted.
|               | 
|               | If "flip" = 1, horizontal flipping is applied to sprite.
|               | 
|               | If update_lcd is set to something other than zero, the LCD
|               | will be updated along with the sprite draw.
-----------------------------------------------------------------------------
|02             | real(2,Matrix_name,x_offset,y_offset,Width,Height,SStartX,
|               |      SEndX,SStartY,SEndY,Pic#,Logic,TileSize,Update_LCD)
|  DrawTileMap  | 
|               | Probably the most complicated function. I don't understand
|               | it fully, so I'm just gonna copy out of the manual, with a
|               | bit of paraphrasing to fit the line limits. Later, I'll
|               | revise this section with my findings.
|               | 
|               | Matrix_name: Name of matrix with map data. 0=[A], 9=[J]
|               | x_offset: x-offset for the part of map you want to draw.
|               | y_offset: y-offset for the part of map you want to draw.
|               | Width: width of the tilemap
|               | Height: height of the tilemap
|               | SStartX: column to start drawing. 0-12 (8x8) or 0-6 (16x16)
|               | SEndX: column to end drawing. 0-12 (8x8) or 0-6 (16x16)
|               | SStartY: row to start drawing.  0-12 (8x8) or 0-6 (16x16)
|               | SEndY: row to end drawing.  0-12 (8x8) or 0-6 (16x16)
|               | Pic#: Pic file to start looking for tiles from.
|               | Logic: 0=Overwrite; 1=And ; 2=Or ; 3=Xor
|               | tile_size:set to 16 for 16x16 tiles. Otherwise, it's 8x8.
|               | Update_LCD: If this is !=0, the screen updates.
|               | 
|               | The SStartX, SEndX, SStartY, and SEndY allow you to draw a
|               | "windowed" map so you can fit things on the side, like an
|               | HUD or something. Drawing will also be accelerated for
|               | smaller maps. For example, if you wanted to draw an 8x8
|               | tilesized map with a 1 tile blank border on all sides...
|               | SStartX : 1
|               | SEndX   : 11
|               | SStartY : 1
|               | SEndY   : 7
|               | 
|               | This routine supports up to 65535 tiles, each starting from 
|               | the Pic number you specified and following to each
|               | numerically adjacent Pic # for each overflow. lolwut?
|               | 
|               | Let's say your starting Pic# is 5 and you want to access
|               | tile 4324. There are 96 tiles per pic on 8x8 mode, so...
|               | (4324 / 96 ) = 45.04...
|               | 
|               | In order to access that tile, Pic50 must exist on the calc,
|               | else all will be drawn is a BLANK tile.
|               | 
|               | Just like any of the useful functions, Pic data will be
|               | read from archive if need be. It'll be slower, though.
|               | 
|               | An additional feature added into the sprite routine is the
|               | ability to invert the sprite prior to displaying. To do
|               | this, add 4 to whatever you use for LOGIC. For example, to
|               | invert a sprite and use XOR display logic, use 7 since 3+4
|               | is 7.
|               | 
-----------------------------------------------------------------------------
|03             | real(3,pic_num,logic,update_LCD)
|               | 
|  RecallPic    | Recalls a pic file denoted by pic_num (0-255) and copies
|               | it to the buffer using the following logic codes:
|               | 
|               | 0:Overwrite
|               | 1:AND      
|               | 2:OR       
|               | 3:XOR      
|               | 
|               | If update_LCD is anything other than 0, the screen updates.
-----------------------------------------------------------------------------
|04             | real(4,scroll_direction,scroll_step,update_LCD)
|               | 
|  ScrollScreen | Scrolls the screen a number of steps in a certain direction
|               | as defined by a code:
|               | 
|               | 0 = Up
|               | 1 = Down
|               | 2 = Left
|               | 3 = Right
|               | 4 = UpLeft
|               | 5 = UpRight
|               | 6 = DownLeft
|               | 7 = DownRight
|               | 
|               | If update_LCD is != 0, the screen is updated w/ result.
-----------------------------------------------------------------------------
|05             | real(5,function,value)
|               | 
|  Change       | If function is...
|  Contrast     | 
|               | 0: Set contrast to value, 0 thru 39.
|               | 1: Current contrast is returned by the function (Ans)
|               |    (value argument is ignored for this)
-----------------------------------------------------------------------------
|06             | real(6)
|               | 
|  UpdateLCD    | See det(20) [FASTCOPY] for more details. lolwut?
-----------------------------------------------------------------------------
|07             | real(7,value)
|               | 
|  RunIndicator | Turns on or off the run indiator according to the value...
|               | 
|               | 0 : Turn off the run indicator
|               | 1 : Turn on the run indicator
-----------------------------------------------------------------------------
|08             | real(8)
|               | 
|  GetKey       | Reads the keypad for any keypress. This function will not
|               | wait, and it'll return zero if no keys were pressed at the
|               | time. This routine supports multiple arrow key presses.
|               | 
|               | The key codes are as follows as it appears on the keyboard:
|               | (in decimal)
|               |---------------------------------------------------
|               ||   F1        F2        F3        F4        F5    |
|               || [ 53 ]----[ 52 ]----[ 51 ]----[ 50 ]----[ 49 ]  |
|               ||                               ______________    |
|               ||   2nd       MODE      DEL    / 7    Up    8 \   |
|               || [ 54 ]----[ 55 ]----[ 56 ]  |     / 4  \     |  |
|               ||                             | Left 2 3 Right |  |
|               ||   Alpha     x,T,0,n   STAT  |     \ 1  /     |  |
|               || [ 48 ]----[ 40 ]----[ 32 ]  |  5   Down   6  |  |
|               ||                              \______________/   |
|               ||   MATH      APPS      PRGM      VARS      CLEAR |
|               || [ 47 ]----[ 39 ]----[ 31 ]----[ 23 ]----[ 15 ]  |
|               ||                                                 |
|               ||   X^-1      SIN       COS       TAN       ^     |
|               || [ 46 ]----[ 38 ]----[ 30 ]----[ 22 ]----[ 14 ]  |
|               ||                                                 |
|               ||   X^2       ,         (         )         /     |
|               || [ 45 ]----[ 37 ]----[ 29 ]----[ 21 ]----[ 13 ]  |
|               ||                                                 |
|               ||   LOG       7         8         9         *     |
|               || [ 44 ]----[ 36 ]----[ 28 ]----[ 20 ]----[ 12 ]  |
|               ||                                                 |
|               ||   LN        4         5         6         -     |
|               || [ 43 ]----[ 35 ]----[ 27 ]----[ 19 ]----[ 11 ]  |
|               ||                                                 |
|               ||   STO       1         2         3         +     |
|               || [ 42 ]----[ 34 ]----[ 26 ]----[ 18 ]----[ 10 ]  |
|               ||                                                 |
|               ||   ON        0         .         (-)       ENTER |
|               || [ N/A]----[ 33 ]----[ 25 ]----[ 17 ]----[ 9  ]  |
|               |---------------------------------------------------
|               | Other (unofficial) codes:
|               | 57 = left/right
|               | 58 = left/right/down
|               | 59 = up/down
|               | 60 = up/left/down
|               | 61 = up/right/down
|               | 62 = up/right/left
|               | 63 = all arrow keys mashed
-----------------------------------------------------------------------------
|09             | real(9,function,pic#)
|               | 
|  CreatePIC    | Performs a function with a pic defined by pic# (1-255)
|               | according to the following function code:
|               | 
|               | 0 = Update the screen from buffer and copy what's there
|               | 1 = DeletePic (not undoable. Exercise caution)
|               | 2 = Copy image from buffer to pic without updating screen
|               | 
|               | Pic1=1, Pic2=2... Pic9=9, Pic0=10, so says the TI-OS. You
|               | will get weird tokens in the memory menu if you attempt to
|               | store to image files not between 1 and 10. This is normal,
|               | since the TI-OS doesn't have "names" to give to those pics.
|               | But, because of naming issues, you'll have to group them if
|               | you want to transfer them off your calc.
-----------------------------------------------------------------------------
|10             | "PRGMNAME
|               | real(10,function,temp_prog_number)
|  Execute      | :prgmXTEMP0XX  or  :Asm(prgmXTEMP0XX), depending on format.
|  ArchivedProg | 
|               | Complicated to use, eh? Ans contains the name of the
|               | program you want to use in a string, then you use the
|               | function, then you run the generated temporary program file
|               | according to the number you gave it. But, you'll need to
|               | know the function codes to further explain how this works.
|               | If function = ...
|               | 
|               | 0 = Copy file to a file numbered by temp_prog_number
|               | 1 = Delete a temporary file numbered by temp_prog_number
|               | 2 = Delete all temporary files.
|               | 
|               | Okay. Say you wanted to copy an archived program "FOO" to
|               | prgmXTEMP002, do the following:
|               | "FOO":real(10,0,2):prgmXTEMP002
|               | 
|               | If you wanted to do this to an ASM program "BAR" and have
|               | it copied to the 12th temporary file, do the following:
|               | "BAR":real(10,0,12):Asm(prgmXTEMP012)
|               | 
|               | If you decided you are done with the copy of "FOO" from
|               | the first example and you wanted to delete it, do this:
|               | real(10,1,2)
|               | 
|               | That will delete prgmXTEMP002 but will not touch the
|               | original file.
|               | 
|               | If you want to clean up (get rid of all temp files), you
|               | can do the following:
|               | real(10,2)
|               | 
|               | According to tr1p1ea when he wrote his readme, files will
|               | not be overwritten if you attempt to copy to a preexisting
|               | temp file. Says something about preventing accidents...
-----------------------------------------------------------------------------
|11             | real(11)
|               | 
|  GetCalc      | Outputs a number indicating which type of calculator being
|  Version      | used. The code refers to the calculator model, which are...
|               | 
|               | 0: 83+
|               | 1: 83+ SE
|               | 2: 84+
|               | 3: 84+ SE
-----------------------------------------------------------------------------
|12             | real(12,shape_type,x1,y1,x2,y2,update_LCD
|               | 
|  DrawShape    | If update_LCD != 0, the screen updates with the result.
|               | 
|               | (x1,y1) and (x2,y2) define points. For a line, those are
|               | the endpoints. For a box, those are the top-left and
|               | bottom-right points, respectively. This routine will draw
|               | the following shapes, given that shape_type is...
|               | 
|               | 0  = Draw a single BLACK LINE.
|               | 1  = Draw a single WHITE LINE.
|               | 2  = Draw a single INVERTED LINE.
|               | 3  = Draw an EMPTY RECTANGLE with BLACK OUTLINE
|               | 4  = Draw an EMPTY RECTANGLE with WHITE OUTLINE
|               | 5  = Draw an EMPTY RECTANGLE with INVERTED OUTLINE
|               | 6  = Draw a RECTANGLE with a BLACK FILLING
|               | 7  = Draw a RECTANGLE with a WHITE FILLING
|               | 8  = Draw a RECTANGLE with an INVERTED FILLING
|               | 9  = Draw a WHITE RECTANGLE with a BLACK OUTLINE
|               | 10 = Draw a BLACK RECTANGLE with a WHITE OUTLINE
-----------------------------------------------------------------------------
|13             | real(13,function,[character])
|               | 
|  TextMode     | Performs a text-related function if function is...
|               | 
|               | 0 = Unsets the text inverse function
|               | 1 = Sets text inverse
|               | 2 = Sets lowercase access. (press Alpha twice)
|               | 3 = Unsets lowercase support
|               | 4 = See note below.
|               | 
|               | Some menus in the TI-OS will reset these flags.
|               | 
|               | Note: For command 4, you can output a character onto the
|               | screen given a character ASCII code, some number between 0
|               | and 255. As a hint, the space is 32, the upper-case letter
|               | "A" is 65, and the checkerboard cursor is 241.
-----------------------------------------------------------------------------
|14             | real(14)
|               | 
|  CheckRAM     | Returns amount of RAM free as function output (Ans)
-----------------------------------------------------------------------------
:
:
:
:
:
:                               THIS SPACE IS                          (ALSO)
:                            INTENTIONALLY BLANK
:
:                                  *RAWR*
:
:
:
:
:
=================================================================== c011 ====
== CELTIC III - OMNICALC PARTIAL COMPATIBILITY COMMAND SET ==================
========================================== also uses the real() token =======
=============================================================================
-----------------------------------------------------------------------------
|20             | real(20,pic#,picx,picy,w,h,x,y,logic)
|               | 
| sprite()      | pic# : A number 0 thru 9 that corresponds to a Pic file
|               | picx : 0-94 x position in pic. Must be in multiples of 8.
|               | picy : 0-62 y position in pic for source
|               | w    : 0-92 width of sprite. Must be in multiples of 8.
|               | h    : 0-62 height of sprite.
|               | x    : 0-94 displays sprite at this x coordinate onscreen
|               | y    : 0-62 displays sprite at this y coordinate onscreen
|               | logic: Optional. If omitted, defaults to option zero (0)
|               |        0 = Draw OR sprite, draw in buffer and screen
|               |        1 = Draw OR sprite, update buffer only. No display
|               |        2 = Draw XOR sprite, draw in buffer and screen
|               |        3 = Draw XOR sprite, update buffer only. No display
|               |        
-----------------------------------------------------------------------------
|33             | real(33,"HEXSTRING")
|               | 
| ExecAsm()     | Works the same as Celtic III's EXECHEX command, with the
|               | same limitations as that command, which may mean that some
|               | routines that are supported by Omnicalc won't be correctly
|               | executed in Celtic III. We'll find out eventually.
-----------------------------------------------------------------------------
|               | 
|               | 
|               | 
|SPARE LINES    | 
-----------------------------------------------------------------------------
_______________________
: ERROR SYSTEM OUTPUT | c012
----------------------/
If a trappable error has occurred, Celtic III will output a string containing
the code of that error instead of letting the system run its course (either
your standard ERR: message, or a system crash). The following codes describe
the error:
=============================================================================
Long/short   | The following may be
codes        | interpreted as...
-------------+---------------------------------------------------------------
.P:IS:FN  .1 | A variable already exists and Celtic III will not overwrite it
.NULLSTR  .2 | An input of some kind exists but contains nothing.
.L:NT:FN  .3 | A line of code or an object was not found during a search.
.S:NT:FN  .4 | An input string was not found.
.E:2:LNG  .5 | Entry was too long.
.NULLVAR  .6 | Some provided variable did not contain any useful content.
.P:NT:FN  .7 | A program or file you searched for doesn't exist.
.PGM:ARC  .8 | A program or file you selected is archived; cannot be edited.
.NULLINE  .9 | The line that was found didn't contain anything.
.STR:ARC  .A | A string variable that was in use was archived.
.G:NT:FN  .B | A group that you was looking for wasn't found.
.NT:EN:M  .C | Not enough memory to complete operation
.NT:A:ST  .D | Input provided was not a string variable
.NT:REAL  .E | Input provided was not a real number
.NT:A:GP  .F | Input was not group file. Forgot the prefix?
.2:M:ARG  .G | Too many arguments were passed to Celtic III. Check your args.
.I:NT:FN  .H | Pic file not found.
.D:INVAL  .I | Database is not compatible with this version.
.E:NT:FN  .J | Database entry number was not found (too great?)
.INVAL:S  .K | String used was invalid for some reason.
.INVAL.A  .L | Arguments used was invalid. Check number of arguments used
.NT:A:LS  .M | The argument supplied was not a list
.SUPPORT  NS | Whatever happened means it was not supported by Celtic III.
=============================================================================
All that these "errors" indicate is that the normal, documented function of
the command you used could not be run to completion. This may or may not be
a good thing, especially if the commands are used in a function outside of
its documented use, but may otherwise be perfectly safe. An example might be
attempting to read a line out of a file simply to determine whether or not
it even exists.

Be creative. Let us know on UTI what you could make Celtic III do. The
further outside the specifications, the better! I'm still, however, not
responsible for any crashes that may happen.
________________________
: COMMAND LIST SUMMARY | c013
-----------------------/
TOGGLESET     00 det(0,"FN",f#) 0=Arc;1=Lk;2=PA;3=Hid;4=Del;5=Crt;6=PS;7=Stat
NUMTOSTRING   01 det(1,var) Out:type code
GETLISTELEM   02 det(2,"LN",elem) out:lNAME(elem) -> Real/Cpx
GETARGTYPE    03 det(3,argofanytype) filetype code
CHKSTATS      04 det(4,f#) 0=RAM 1=ARC 2=ID 3=OSVER
LINEREAD      05 det(5,"FN",line#,[#oflines])
LINEWRITE     06 det(6,"STR","FN",line#)
LINEERASE     07 det(7,"FN",line#,[#oflines])
LINEREPLACE   08 det(8,"STR","FN",line#,[#oflines])
FINDPROG      09 det(9,["SEARCH"])
UNGROUPFILE   10 det(10,"GFN")
GETGROUP      11 det(11,"GFN")
EXTGROUP      12 det(12,"GFN",item#)
GROUPMEM      13 det(13,"GFN",item#)
BINREAD       14 det(14,"FN",bytestart,#ofbytes)
BINWRITE      15 det(15,"HEX","FN",bytestart)
BINDELETE     16 det(16,"FN",bytestart,del#ofbytes)
HEXTOBIN      17 det(17,"484558")
BINTOHEX      18 det(18,"BIN")
FASTCOPY      19 det(19) LOLWUT?
EXECHEX       20 det(20,"C9")
EDIT1BYTE     21 det(21,Str?,StartByte,ReplaceWithThisByte)
MODECHANGE    22 det(22...) Not implemented
INDEXFILE     23 det(23,"FILENAME","NEWINDEXNAME")
LOOKUPINDEX   24 det(24,"FILENAME","INDEXNAME",line#,[#oflines])
ERRORHANDLE   25 det(25,function,string)
MATTOSTR      26 det(26,Matrix#)
STRINGREAD    27 det(27,"binstring",start,readThisMany)
HEXTODEC      28 det(28,"HEXSTRING")
DECTOHEX      29 det(29,SomeRealNumber,[autoOverride])
EDITWORD      30 det(30,start_byte,replace_with_this_word)
BITOPERATE    31 det(31,value1,value2,logic)
GETPROGLIST   32 det(32,"SEARCHSTRING",[type]) 

DBQUERY1      00 identity(0,"DB",f#,args) 0=fm;1=ad;2=dl;3=di;4=ac;5=cb;6=cp
TOGGLEPIC     01 identity(1,pic#,f#) 0-7=picToBuf;8=newPic;9=TARC;10=del
GETPICGROUP   02 identity(2,"GFN")
EXTPICGROUP   03 identity(3,"GFN",pic#)
STRINGTILE    04 identity(4,"BSTR",xS,xE,yS,yE,W,xO,yO,pic#S,displogic)
PUTSPRITE     05 identity(5,ScrewDocumentingThisCommand)
SHIFTSCREEN   06 identity(6,sft#,sftDir,scrnUpdate)
DRAWBOX       07 identity(7,x1,y1,x2,y2,dispmeth)
FILLMAP       08 identity(8,"HEXSTRING",right,down,LOGIC,updateLCD)
BOXSHIFT      09 identity(9,x,y,w,h,shiftType,shiftRepeat,updateLCD)
DRAWTEXT      10 identity(10,flag,[x,y],"TEXT")
COPYBOX       xx identity(xx,x1s,y1s,x2s,y2s,x1d,y1d,x2d,y2d,dispmeth)

ClearScreen   00 real(0,ULCD)
DrawSprite    01 real(1,x,y,w,h,p#,pX,pY,flp,ULCD)
DrawTileMap   02 real(2,MTRX#,xO,yO,W,H,xS,xE,yS,yE,p#,LOGIC,tSiz,ULCD)
RecallPic     03 real(3,p#,LOGIC,ULCD)
ScrollScreen  04 real(4,scrDir,scrStep,ULCD)
ChngConstrast 05 real(5,f#,val). 0=SetContrast;1=ReturnCurrentContrast
UpdateLCD     06 real(6) See FASTCOPY. LOLWUT?
RunIndicator  07 real(7,value) 0=off;1=on
GetKey        08 real(8) Returns keycode
CreatePIC     09 real(9,f#,p#) 0=stoPic;1=DelPic
ExecArcPrgm   10 real(10,f#,tPrg#) Pass Ans="FN"
GetCalcVer    11 real(11)  Returns calcver. 0=83+;1=SE;2=84+;3=SE
DrawShape     12 real(12,shapeType,x1,y1,x2,y2,ULCD)
TextMode      13 real(13,f#,[chr]) 0=inv;1=un;2=lwrcse;3=un;4=outputchar
CheckRAM      14 real(14) Returns amount of free RAM.

sprite()      20 real(20,pic#,picX,picY,w,h,x,y,[logic])
ExecAsm()     33 real(33,"HEXSTRING")

___________________
: TROUBLESHOOTING | c014
------------------/
(1Q) The screen is wavy or stuff doesn't display right, even while installing
(1A) Download "LCD Fix" from ticalc.org. The link is as follows:
     http://www.ticalc.org/archives/files/fileinfo/366/36608.html
     Then run it on your calclulator to fix the LCD driver, if you happen to
     have a TI-83+SE or higher. Otherwise, you're just out of luck.

(2Q) Celtic III doesn't seem to stay installed, or after I install it, the
     functions doesn't seem to work.
(2A) If Celtic III doesn't seem to stay installed, you should try to re-
     install the application. Upon another attempt, Celtic III should notice
     that the required hooks are in use and you will have one of a few
     options. If you are desperate enough, you can use the "POWER INSTALL"
     command, which will kill all other hooks on the calculator. If you must
     use the command, consider it a lazy work-around until one can figure out
     which application's hooks are responsible for taking Celtic III's away.

(3Q) Your puny troubleshooting section doesn't solve my problem!
(3A) Go away.
     j/k.
     If you think you found a bug, login (and possibly register) on UnitedTI
     so you can post in my subforum's stickied "Bug Reports" thread. Be sure
     to read the first post, as I'm going to try to make it a point to keep
     track of all the bug reports there. Be sure to follow the instructions
     posted in that post and make sure that bug you've found wasn't already
     mentioned.
     
     Bug reports can also include documentation bugs, so be sure to post
     those, too.
     
_____________________________________
: SPECIAL THANKS AND GENERAL THANKS | c015
------------------------------------/
"Darth Android"   -- Without his request for the original Celtic (a simple
                     linereading program), this project would've never
                     existed. Biggest thanks fly out to him.
"tifreak8x"       -- The one person who's been a big help and a real
                     confidence boost. I feel happy that some projects would
                     not have been possible without this, or this program's
                     predecessor.
"Jon"             -- For those cool little routines you gave me. Thanks!
"CoBB"            -- Much thanks for having that really fast line drawing
(Patai Gergely)      routine just sitting there on ticalc's archive. And as
                     per the agreement in the source, you have your credits,
                     both here and in source. Much thanks.
"BrandonW"        -- Basically, the conversion of the program to an app is
                     all thanks to this guy, if the only thing he did was
                     answer all my stupid little questions regarding stuff I
                     might've been able to find in the wiki. And the
                     information he provided regarding calculator linking.
"Weregoose" and   -- For assisting me by putting up a forum on the UnitedTI
"DarkerLine"         boards so my project could further develop. That
                     opportunity has been immensely valuable to my progress.
"vuurrobin"       -- Great work testing out this app for all its little bugs
                     and suggesting ideas to make this app better. For all.
"nitacku"         -- For some seriously solid testing and bug reporting.
                     You basically did all the testing work for me :)
"tr1p1ea"         -- For having an application to look up to, and hopefully
                     surpass. Thanks for the support with what will
                     eventually be the next standard BASIC library.
James             -- For providing a version of a sprite routine with
Montelongo           clipping on the WikiTI. Very useful.
____________________
: ADDITIONAL CREDS |
-------------------/
-- The DragonFire IRC Network, for putting up with all my rants and raves
-- Joe That-Name-I-cannot-pronounce, for creating ION. It's a wonderful lib.
-- All those who got WikiTI to what it is today. Check it out!
-- The guy who made PindurTI. It's the best emu. I like it over Wabbitemu.
-- Behind-my-back flamers at #TCPA. It adds name recognition :P
___________________
: VERSION HISTORY | c016
------------------/
 Seriously. I haven't kept track. At all.
 This section is just here as a placeholder
 for when the application makes an "official"
 release and things have been changed afterward.

____________________
: MORE INFORMATION | c017
-------------------/
There should be more documents found in this release other than this.
They are found in the MOREINFO folder. They have good stuff too.

DevMan.txt   : Contains information ABOUT the source code
ExecHEX.txt  : Contains codes for the ExecHex command. Useful?
FunStuff.txt : Contains tips and tricks for the use of Celtic III
Tokens.txt   : Info about the retrievable tokens for use with HEXTOBIN
ErrCodes.txt : TI-OS error codes that have been catched by the error handler.

FILEBACK\info.txt     : Information regarding the FILEBACK folder's purpose.

AINSTALL\*.*          : Files used to create the ASM util AINSTALL.

____________________
: COPYRIGHT NOTICE | c018
-------------------/
This section has changed to be more concise and to cut a few jokes. (NO!)

Celtic III is (C) Copyright 2007-2009 to Rodger Weisman
Subroutines that are not written by me are Copyright to their respective
owners. Such indication will appear in the source file where they are
found.

Celtic III, unmodified, may be freely distributed. If Celtic III has been
modified by anyone not me, there must be a prominent notice that Celtic III
has been modified placed either in the manual of whatever Celtic III is being
distributed with, or within the application's title screen, or both. This is
to keep me from being bugged by bugs that I didn't have anything to do with.

Celtic III may be freely used as long as due credit has been given. Keep in
mind that some of these routines were not made by me, and these people have
to have credit given to them, too. Also, the sea turtles need saving, so
please try to do something to save them while you're at it.

As a restriction to the previous paragraph, you may NOT use this application
as an automatic light dimmer, no matter how creative you get with the code.
I will hate you forever (probably not) and I will demand information as to
how you got Celtic III to perform that function if you go against those
wishes. Either way, you should nuke the whales since they tend to eat
sea turtles, which need to be saved.

While this application is written with stability in mind, there are
a few functions that simply are not. Also, this ReadME file has been
written with both informativeness and crude jokes in mind, but that doesn't
mean I'm gonna be responsible if anything goes wrong with either YOU or
YOUR CALCULATOR (in no particular order). Celtic III and its accompanying
ReadME is distributed AS-IS. You've seen that clause quite a number of times
and you know what it means already. It means:

The fact you are using this application means you assume ALL RESPONSIBILITES
of having read this ReadME file and/or using Celtic III. I assume nothing but
the right to have a bag of popcorn while I watch you nuke yourself trying
to (ab)use Celtic III and/or the readme.

I did not proofread. (NOT)

Also, if you've managed to keep a straight face throughout reading that
debacle, you can pretty much get away with NOT doing anything this copyright
notice says you can't do. Except ignore the disclaimer. That's for your
safety. Which I hadn't said anything about. So, I'll say it here. BACKUP.
_______________
: SPARE NOTES | c019
--------------/

Sprite clipping needs to be addressed.
Line drawing routine in drawshape may be replaced with romcall.
Cruddy drawshape command STILL needs work.


.END
.END