=========================
PONG v2.5 (first public version)
=========================
Programming: Viktor Crabeels (or just Viktor/Vikt0r)
Contact viktor.crabeels@gmail.com

Table of contents:
I. Installation
II. How to play
III. About
IV. Earlier versions + planned features



I. Installation
To install just move the program (filename: Pong v2.5.8xp) into your calculators RAM memory using TI-connect / any link-program.
This program can also be ran from the archive with mirageOS.

II. How to play
Controls:
Enter + Arrows : menu navigation
Left/Right arrow keys (tap repeatedly) : move paddle left/right
Game objective:
try to keep the ball from hitting the floor as long as possible, the game gets harder over time.



III. About
Pong 2.5 is yet another interpretation of the classic pong arcade game.
The initial game stays the same but my version however doesn't show loops and I tried to keep it interesting by making it getting harder over time.
There's an implemented highscore feature that tells you how good you are, as you're highscore gets higher you get a better rating/achievement.
This is my first TI-Basic game I'm only 15 so please mail me at viktor.crabeels@gmail.com for tips, ideas or any questions.



IV. Earlier versions + planned features
	Pong v0.1 >>>>> v2.4
		-Game in development and not public yet.

	Pong v2.5 (released january 2012)
		-First publicly released version
		-No know bugs

	Pong v2.5.1 (released january 2012)
		-Stopped using ugly caps, makes it a bit larger
		-You no longer have to copy a highscore-list to your calc, the game creates it when it isn't there.
		-Slightly (not really noticeable) faster/smoother gameplay

Planned features
	-Generally faster/smoother gameplay
	-Customizable graphics
	-Two-calculator multiplayer (already in development!! ;D)




_________________________________________
Report any bugs/issues at viktor.crabeels@gmail.com
