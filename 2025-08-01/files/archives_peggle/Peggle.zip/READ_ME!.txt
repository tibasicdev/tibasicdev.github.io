 ______                   _        
(_____ \                 | |       
 _____) )____  ____  ____| | _____ 
|  ____/ ___ |/ _  |/ _  | || ___ |
| |    | ____( (_| ( (_| | || ____|
|_|    |_____)\___ |\___ |__)_____)
             (_____(_____|     

Peggle: An Angel Production
Builderboy2005@yahoo.com
Alex Marcolina

I-----Intro
II----Instructions
III---Powerups
IV----Making levels
V-----Known Bugs
VI----Conclusion


-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

I:Introduction

	Peggle is a fun and adicting physics based game.  The game consists of 9 levels composed of several 
different types of blocks.  You are given 9 balls to shoot into the arena to try to hit as many blocks as possible,
resulting in them being erased at the end of a turn.  If all blocks are erased, you procede to the next level.  
Sophisticated scoring also allows for highscores to be made even if a level is not beaten.  You can choose
to play as one of 4 characters, each character having there own powerup accesable by hitting a special block.
With chalanging gameplay, stunning graphics, and great replayability, Peggle is a must for all calculator gamers!

-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

II:Instructions

	When you first load up peggle, you will be greeted by the Angel productions logo (which is only displayed once), and the main screen will load.  You can then choose to play a game, play a custom level, or look at the
highscores.  When playing a game, you will first need to select a character to play as.  There are 4 characters
and their respective powerups are described more in section III.  
	Once you select your character, the main game screen will load.  Once you are given control, you will be
able to move a dot around the screen in the game arena.  To switch between slow and fast moving, press alpha.  The
apparatus at the top will always shoot the ball directly at the dot that you control, so this is very helpfull for
aiming.  when you are ready, press second or enter to fire the ball and watch as it bounces around the screen.

	Once it falls below the bottom of the screen, that turn has ended, and all the blocks that have been hit
will be erased, and you will be given points based on the quality of your shot.  Bonuses are given out if you manage
to double the maximum number of blocks hit.  If you manage to hit no blocks at all, you are given a point penalty
and a new ball.  
	Once you have used up all of your nine balls, the screen is cleared and your points are tallied up in front
of you.  If you get a highscore, your score is added to the highscore table, and if you clear all the blocks
then you unlock the next level.  There are nine levels in total, each being more difficult than the last.  Once you 
beat all nine levels, you are given a choice to which levels you want to play.


-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

III:Powerups

	There are 4 characters in peggle, and therefore 4 powerups:

Master Hu--------Gravity Ball
Splork-----------Light Ball
Reinfield--------Ghost Ball
Warren-----------Extra Ball

-Gravity ball removes all the gravity in the arena for one turn, making it a lot more difficult for the ball to slow down and fall to the bottom

-A Light ball activates when it hits a block, sending out many bursts of light that destroy blocks around it, but
it only works once.

-A Ghost ball will go back to the top of the screen if it falls to the botttom, and it only works once.

-Extra ball simply gives you an extra ball.


Powerups are triggered when you hit the powerup blocks (a plus), and are activated on the next turn.  You will see
your next ball transform into the corosponding powerup ball when this happens.  Some powerups can be layered, meaning 
if you hit more than one powerup block in one turn, it will have more effects the next turn.  Light Ball,
Ghost ball, and Extra Ball, are all this way.


-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

IV:Making levels

	The game also comes with a simple level editor, so you can make your own levels.  When you run the program
it will firsty ask you if you want to make a new one, or edit a pre-existing level.  Choosing either
will eventualy lead you to the edit screen where you can add or deleat blocks.  to add a block, you simple press the
number on the keypad that corosponds with it. To save the level, press enter, and the data will be saved to L1
you must save it to custom lists for it to be playable in Peggle. They also must not contain numbers.

	Playing custom levels in peggle is also simple.  Select the 'Custom' option on the main menu and enter the
name of your list into the prompt when it shows up.  You can then procede to play it like you would a normal level,
although highscores and level progress is not updated.


-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

V:Known Bugs

	There are some minor problems witht the ball physics engine that have been overlooked simple for the sake of
speed.  The ball can, on ocasion, get stuck on the top of a block.  when this happens you must cancel out of the turn 
by pressing any key.  This will keep the game from crashing from lack of memory (all the memory will go to accounting for colisions, which now will never end).  You can also use the key quit out to quit out of any turn that you want to.


-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

VI:Conclusion

	I would like to thank you so much for downloading my game.  if you have any problems or
questions, feel free to contact me at Builderboy2005@yahoo.com.  As always, the program stays unlocked for
you new to programing, and feel free to ask me any questions about the code.

Thanks again!

-Builderboy