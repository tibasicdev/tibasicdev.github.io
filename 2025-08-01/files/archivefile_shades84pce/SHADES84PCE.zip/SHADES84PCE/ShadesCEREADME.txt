 ######  ##     ##    ###    ########  ########  ######
##    ## ##     ##   ## ##   ##     ## ##       ##    ##
##       ##     ##  ##   ##  ##     ## ##       ##
 ######  ######### ##     ## ##     ## ######    ######
      ## ##     ## ######### ##     ## ##             ##
##    ## ##     ## ##     ## ##     ## ##       ##    ##
 ######  ##     ## ##     ## ########  ########  ######

////////////////////////////////////////////////////////
Shades CE - created by Michael2_3B and PT_
for the TI-84+ CE Calculator
version 1.2 - 4/26/17

----------------------------------
Original iOS Game created by UOVO
https://itunes.apple.com/us/app/shades-a-simple-puzzle-game/id888683802?mt=8
----------------------------------

===[[Installation]]===
-Send both SHADESCE.8xp and ZSHADES.8xp to your TI-84+ CE using your cable and TI-Connect CE.
-Run program "SHADESCE".

===[[Description]]===
Shades is a simple, zen-like game that is like a merge between Tetris and 2048. Combine tiles together in order to rack up the most points you possibly can, and don’t let the tiles stack to the top of the screen!

HOW TO PLAY:
- Using the arrow keys, move the falling tiles into the best position to combine tiles and clear entire rows. Use the down arrow key to hard drop a tile.
- Put 2 of the same color tiles on top of each other to merge them into a single tile of a darker color.
- You can clear a row by having the whole row be the same color tiles.
- You lose when your tiles are stacked all the way up to the top of the screen.

Press [mode] at any time to pause the game.
Press [clear] at any time to quit the game. Your score will be saved.

===[[Contact]]===
You can post a comment directly on the forum here: cemete.ch/t11845
Cemetech: Michael2_3B
Cemetech: PT_


===[[Changelog]]===
v1.0 - 10/19/15
 initial release

v1.1 - 10/22/15
 optimizations
 bug fixes

v1.2 - 4/26/17
 [2nd] button acts as an enter/selection key
 [mode] button pauses the game
 tile dropping is now instantaneous
 minor graphical additions & changes