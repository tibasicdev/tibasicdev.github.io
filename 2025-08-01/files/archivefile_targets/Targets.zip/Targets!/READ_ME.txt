				     *
	T A R G E T S !		     *
**************************************
	.ZIP Archive Info
File Name: Targets!
Program Name: TARGETS
.zip Archive Size: 1.89MB
	Program File Size:
	-Original Version-
Name: TARGETS
Size: 2796 Bytes
Lines of code: 229
Libraries: No
	-Sequel Version-
Name: TARGETS 2
Size: 4145 Bytes
Lines of code: 358
Libraries: No
Save Data List Format: {Streak, Longest Streak, Strikes, Hits, Wins, Losses, Damage Given, Damage Taken, Skin, COM Skin, Game Mode
			Default: {0,0,0,0,0,0,0,0,1,1,2
	Game Description:
This is a game where you go around the screen and hunt down your target as quick as possible, and kill the COM before it kills you. This is a very fun game,
and can be very addicting (for some). This game is well-made, and has no memory leaks. Enjoy!

