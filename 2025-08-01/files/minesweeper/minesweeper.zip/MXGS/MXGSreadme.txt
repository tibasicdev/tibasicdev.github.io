<------------------------------------------------------------------------------------------>

MXGS - MineSweeper GreyScale

Offically Released on May 23rd 2006

(c) 2006 CDI Games & Fred Sparks

Installation-

Send xLIB.8xk to your 83/4+/SE calculator
Press APPS, select xLIB press 1 then 3
Send MXGS2.8xg to your 83/4+/SE calculator
Press 2nd then + then UP then ENTER then RIGHT then select MXGS2

Running-

Press PRGM then select MXGS
Enter your # of mines (this is an 8x8 feild, fixed)
Use the arrows to move, 2nd to uncover, and ALPHA to flag

HAVE FUN!