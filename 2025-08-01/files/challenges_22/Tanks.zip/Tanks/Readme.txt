Width should be:
---------------------------------------------------------------------------------

|-------\
|Readme |
|---------------------\
| 1. What is this?    |
| 2. Controls         |
| 3. Thanks           |
|---------------------|

1. What is this?
	This is my entry for the program challenge 8. The challenge was for a
program under 1024 bytes.  Therefore, it does not accurately display my
best work.  However, it is in fact playable.  It is a two player game, in
which both users have to share the same calc.  If I had more byte usage, I
might have done two player via link cable.

	This game is a tank game in which you select two points, and then
shoot at the other tank.  The interface is with two points in which you
must select to create an arc to aim for the other tank.  See controls for
more info.

2. Controls
	The controls are simple.  You have two cursors that you must deal
with. Due to the byte constraint, I am unable to make it so that you can
distinguish between the two points.  Sorry.  One point is Controlled via
the arrow keys, and the other is controlled by 2 being down, 4 being left,
6 being right, 8 being up.

	Press 2nd when you have both points in place, and want to fire.  The
dot you move with the arrow keys should be below and to the right of the
point controlled by the number keys, but only if you are the left tank.  If
you are the right tank, then you must have the point controlled by the arrow
keys below and to the left of the one controlled by the number keys.  That is
because it arcs from the tank, to the point controlled by the number keys, to
the point controlled by the arrow keys.

3. Thanks

Thanks for downloading, or, at least testing my program.