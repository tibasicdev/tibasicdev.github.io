Donut Quest II
by Mikhail Lavrov (DarkerLine) of United-TI

http://mpl.unitedti.org/	(My TI-related Blog)
http://www.unitedti.org/	(the United-TI home page)
misha.p.l@gmail.com		(my email)

The files in the .zip file you just opened are:
	DONUT.8xp - Donut Quest II, the program - send this to your calculator
	DQOLD.8xl - The six levels from Donut Quest I
	readme.txt - what you're reading right now


I. About the Game

Donut Quest II, the sequel to Donut Quest, is a TI-Basic game of revolutionary quality. It uses no libraries of any kind, in fact, you don't need anything other than the game program to play it. 

Your task in each of the levels is to eat all the donuts, then walk off the edge of the screen. There will be various obstacles you'll have to get by in order to do so. 

There are 8 all-new levels built into Donut Quest II. In addition, the level pack DQOLD contains all six of the old Donut Quest levels. Finally, you can use the level editor to make your own levels.

II. How to play

When you start the game, get a choice of the default levels (the built-in 8-level scenario included in Donut Quest II) or external levels (which anyone can make using the level editor - DQOLD is an external level pack with the six levels from Donut Quest I). Donut Quest uses named lists for its external levels.

Once you get to actually playing the game: the arrow keys control the character, represented by a rather blocky smiley face. Pressing CLEAR resigns the level, and offers you the choice of restarting or exiting. Should you manage to solve a level, you'll usually be given the choice of continuing to the next, or returning to the main menu.

There are many tiles in Donut Quest II, with various functions. They include:

DONUTS - you'll usually have to eat all of these to solve the level
WALLS - you can't push or move through these, you have to walk around
BLOCKS - you can't go through them, but you can push them around (one at a time).
KEY - push this into a door to open it (one-time use).
DOOR - you can't open this until you find a key.
WATER - if you fall in you'll die (you can't swim). But you can use blocks to "fill it in."
?! - I'm not sure what this does.

...and more!


III. Frequently Asked Questions

Q:The game said ERR:MEMORY and exited! What do I do?
A:Free up some memory, archive some stuff.

Q:Why do I lose the game every time I walk into an electric fence?
A:Because it's an electric fence.

Q:How many donuts are there on the last level?
A:23.

Q:How do I get across the chasm in Act 2?
A:Build a bridge.

Q:I can't solve level X! Help!
A:I don't have solutions. Keep trying. If you get desperate, email and I'll help.

Q:What happens if I type in the wrong thing as an external level?
A:Your calculator blows up. I am not liable. You've been warned.

IV. Credits

As far as I know, all the code in Donut Quest II is my own, and if you find something that looks like someone else's code, all that means is that that person is also an awesome TI calculator programmer. Nevertheless, I have a list of people to thank.

Weregoose (United-TI) for bringing text-sprites to my attention.
elfprince13, alexrudd, and others for persuading me that Donut Quest was pretty awesome.
All of United-TI, for helping me find the motivation to finally finish this darn thing.
The entire TI-community, if it didn't exist, I'd have to find another equally geeky hobby.