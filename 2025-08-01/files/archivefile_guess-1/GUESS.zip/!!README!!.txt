YOU HAVE DOWNLOADED THE PROGRAM �GUESS� BY CONOR O'BRIEN. BY USING THE APPLICATION AND BY READING THE !!README!!.txt INCLUDED IN THE DOWNLOAD, YOU AGREE TO THE CONDITIONS INCLUDED WITHIN !!README!!.txt.

By using this software, you agree to the following conditions:

  1. The leaser (�Conor O'Brien�) is not responsible for any damage dealt to your (�the user�) calculator. Any memory issues that would resolve in the compromise of any data on the calculator on which the program resides, whether related or not, will not be compensated for by the leaser, nor will the leaser be held responsible for said damage. Furthermore, the user will be held responsible for said damage in the event of legal repercussions.
  
  2. The user may not make a reproduction of the software without permission from the leaser. The leaser withholds the right to remove the user's privilege of modifying the software.
  
  3. Any modifications may be made to the program, but the modified program may not be published without explicit permission from the leaser, after you have given information as to the edits you have made. The leaser then reserves the right to use any such modifications in any new release of the program.
  
The following disclaimers are made by the leaser:

  1. I do not own Texas Instruments, and further I am not affiliated with them in any way.
  
Thank you for using the program! I would love to hear back from you.