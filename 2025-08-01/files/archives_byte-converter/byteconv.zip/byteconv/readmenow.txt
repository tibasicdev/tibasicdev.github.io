/--------------------\
| Byte Converter 1.0 |
\---------||---------/
/---------||---------\
|By RandomProductions|
\--------------------/

+===================+
+ Table of Contents +
+===================+
- Disclaimer
- Program Description
- Calculator Requirements
- Instructions
- Program Controls
- Files included in byteconv.zip
- Author Information
- Copyright

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! Disclaimer ! Please read this section first !
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
RandomProductions is not liable for damages to your calculator as a result of using this program. This includes, but is not limited to:
- RAM clear
- Loss of all data

+=====================+
+ Program Description +
+=====================+
This simple to use byte converter is like nothing seen so far, not even on ticalc.org. It allows you to convert between any unit for memory measurement, from bits to terabytes, even the nybble unit. The size might be a bit much for your liking, but it's worth it. This program allows you to convert between all the units of memory the home user may encounter today.

+=========================+
+ Calculator Requirements +
+=========================+
You will need at a TI-83+ or better. TI-83 users cannot use this file due to the program format (8xp).

+==============+
+ Instructions +
+==============+
Here are the instructions to get BYTECONV.8xp onto your calc.
1) Locate BYTECONV.8xp
2) Transfer to your calculator using the appropriate link cable and software
3) Run BYTECONV from the PRGM menu or your favorite assembly shell.

+==================+
+ Program Controls +
+==================+
Up/Down: Move between menu items.
Enter: Select highlighted menu item (Menu Screens), advance to next screen (Input/Result Screens).
Number Keys: Select menu item (Menu Screens), input a number (Input Screens).

+================================+
+ Files Included in byteconv.zip +
+================================+
NOTE: If some of these files did not come with the .zip file, please download the zip file from tibasicdev.wikidot.com or www.ticalc.org
>COPYING.txt - the GNU GPL v3 license
>readmenow.txt - this file
>byteconv.8xp - the program

+====================+
+ Author Information +
+====================+
To contact RandomProductions, please email to this address:
pidayman{dontmindus}[at]{ellogovenr}gmail[dot]com
Remember to remove the things in {} and replace the [] with appropriate symbols.

+===========+
+ Copyright +
+===========+

Copyright 2008 RandomProductions

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or 
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

-Have Fun!-