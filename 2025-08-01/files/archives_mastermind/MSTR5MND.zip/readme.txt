Master mind v.5.3
From Lavalamp Gaming
By bsch2734

Files in the .zip you opened
MSTR5MND.8xp------Master mind game program
Screenshot.bmp
readme.txt--------readme file (hint- you're reading it)

1)About

	This game is a classic brain challenge in which you guess a secret code.  It is written in pure Ti-Basic, with 
assembly code or anything like that.  The code is all my own work, but there are a couple of lines I got from 
Ti Basic Developer ;).   This version uses numbers in the code instead of colors because, well, it's not for 
Ti-Nspire CX.  The game and the play is simple, but the challenge it gives can be difficult.

2)How to play

	I included how to play as part of the game, in a "Rules" and "Tips" section of the program.  The rules are 
pretty simple, but if you don't understand after reading them there is some very good info on Wikipedia, including
strategies.  For program size, however, I omitted the keys used (which are listed below)

Left and right arrows		move cursor left and right
numbers 1-6			enter a number into the current guess
enter button			finalize guess, get feedback
del button			delete number over cursor
clear button			clear current guess
Y= to Trace buttons		jump cursor to respective spot
2nd button			pause (so calc. will auto shut off)

3)Editing

	Feel free to read, edit, and optimize this code.  I'm leaving it completely unprotected.  If you have a good 
optimization, and it actually works, please e-mail me at thepretzelmanwins@gmail.com.Including the rules and tips 
added a lot of file size to the program.  If you feel you need to free up some RAM, feel free to delete the code for 
these sections and open up about 600 RAM units.  I've made this easy.  Just delete everything between and including 
lbl Y and lbl N, and the two choices from the startup menu.  This will not effect the game, only remove the tips and 
rules. If you really want you can delete the Lavalamp logo and win sequence portions of the code, saving 826 and 332 
RAM units, respectively.

4)Bugs

	There are no bugs in this program that I know of.  If you find any, please notify me at 
thepretzelmanwins@gmail.com I'll be glad to fix them (no, really, I will be).

5)Special Thanks

	Even for a solo project, there are always a few sources to credit.  First, the community at Ti basic developer,
for answering all my questions promptly and thoroughly.  Next, all those who left the code to their programs open, for
helping me learn new technique and faster routines.  I'll always return the favor.  And finally, to the countless 
people who tested this program and found more errors than gallons of water of the Mississippi.  Never would have 
finished without you :).


Look for updates with loads of new features in the future.  I've got ideas, but I'll probably never get to them 
because I'm moving on to bigger and better things...

























