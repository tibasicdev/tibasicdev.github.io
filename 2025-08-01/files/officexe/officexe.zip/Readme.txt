Office XE - v1.0
By: Brad Wentz
TopDoggB@yahoo.com


To install, just send each file to your archive and unarchive the one you want to use.
All together they take up a lot of space so it is recommended to only have one or two in your RAM at a time.

Here are the details of each program in the Office XE Package:


-------
Draw XE
-------

Draw XE is an amazing drawing program. All drawing is done on the fly and is very easy to get the hang of. Each tool has many options. Tools such as the circle command have options that have never been seen before. Use the built-in help for what the keys are and how to use the program.

Draw XE's features are:
* Completely graphical (obviously)
* Blinking cursor, can move 1 or 5 pixels at a time
* Pen (Black, white, or inverted)
* Line (Black or white)
* Circle (Black outline, white outline, black filled, white filled, inverted filled)
* Box (Black outline, white outline, black filled, white filled, inverted filled)
* Fill (Black or white)
* Text (Small normal, small inverted, large normal, large inverted)
* Invert screen
* Black out the screen
* Save up to 9 pics (pic 0 used during program execution)


-----------
Document XE
-----------

Document XE is a fast, advanced text editor with an easy to use interface.

Document XE's features are:
* Completely graphical, all input done on graph screen
* Blinking cursor (move with arrows)
* Graphical scrollbars
* Text scrolled by page or by line using cursor
* Large character set
* Select, copy, and paste options
* Insert text into any place in the document (by typing or pasting)
* Goto command, jumps to specified line
* Find command, searches for text and moves cursor there
* Stats command, displays number of characters, words, and sentences
* Saves all files into one string with names (up to 22 character names)
* Export text to a string without name or format characters for use outside of Document XE


--------------
Presetation XE
--------------

Presentation XE is an easy to use slideshow maker with a simple way to organize pics and create a presentation.

Presentation XE's Features:
* Completely graphical
* Pic viewer to verify which pics are which from within the program
* Option to open Draw XE and edit pics for your slideshow
* All-in-one setup screen that uses arrow keys to change options
* Unlimited number of slides in your slideshow (slides can be repeated)
* Put a pause or a delay (in seconds) between slides
* Several transitions to put between slides
* Save slideshows for later viewing


Office XE shouldn't have any bugs or errors, but if it does please email me.