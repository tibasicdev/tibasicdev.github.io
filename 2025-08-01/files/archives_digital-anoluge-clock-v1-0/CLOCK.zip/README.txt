##################################
## Digital + Anoluge Clock V1.0 ##
##          By dan769           ##
#################################

 This is my first program I have
made so critisism is welcome!
 In essence this is a good looking
anoluge clock with a digital date 
and time aswell. Be sure to set
your calc's clock first! Press
any key to exit the program when
it is running.

Adding Soon:
-Moon Phase Calc

