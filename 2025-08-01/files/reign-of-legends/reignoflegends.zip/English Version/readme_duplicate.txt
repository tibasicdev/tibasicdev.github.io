Version 1.63

You cannot change the future
But if there is no future
You have to create one

Everything that has a beginning
Has an end�


IMPORTANT: THE REIGN OF LEGENDS 3 IS NOT AN ORDINARY BASIC GAME! 
IT HAS A LOT OF DATA AND FEATURES SO READ THIS README CAREFULLY 
BEFORE USING IT ?.

1: Introduction
2: Minimum requirements
3: Installing the game
4: Story
5: How to play
6: Controls
7: Orbs
8: Battles
9: Menu
10: Features
11: Bugs
12: Version History
13: Frequently asked questions
14: Special thanks
15: Disclaimers 


1: Introduction

Thanks for downloading The Reign of Legends 3 (a.k.a. RL3)! I hope you'll enjoy it. RL3 is a 
RPG (Role Playing Game) where magic and monsters takes place. You have to explore lots of 
forests, caverns and dungeons to collect treasures while fighting many foes. If you played many 
RPGs so far, then you'll be able to get into this game very quickly. The only difference in this 
one compared to other TI-calc ones is that it's incredibly huge and even more complete. Making 
this game required more than 900 hours of hard work!


2: Minimum requirements

-This game will require the full speed of the TI-83+ Silver Edition, TI-84+ or TI-84+ Silver 
Edition.
-TI-OS 1.14 or higher or OS 1.13 with MirageOS 1.2 shell.
-The game is HUGE! It takes around 120 KB of memory. I suggest you to have 1 MB or free 
archive memory if you use a Silver Edition to increase archiving speed.
-All your RAM.
-Patience (it's a BASIC game and it's a little slow)


3:Installing the game
 
1) Before installing the game, make sure you have 24KB of RAM free and 200 KB of Archive 
memory.
2) If you have anything in the Archive memory that isn't a group or a Flash app, please delete 
it!!!!!!!!!
3) Open TI-Graph-Link, click on Link/Send to/Archive and locate the rl3/English Version folder. 
Click on Add all then click on OK. NOTE: You can use any other software to send the group to 
the calc but the procedure may vary.
4) Go to your calc and go in the MEM menu and choose the Group option. Choose Ungroup and 
look for ROL3A and ungroup it.
5) Go into memory manager, archive all the programs and delete ROL3A.
6) Go in the MEM menu and choose the Group option. Choose Ungroup and look for ROL3B 
and ungroup it.
7) Go into memory manager, archive all the programs and delete ROL3B.
8) Go in the MEM menu and choose the Group option. Choose Ungroup and look for ROL3C 
and ungroup it.
9) Go into memory manager, archive all the programs and delete ROL3C.
10) Go in the MEM menu and choose the Group option. Choose Ungroup and look for ROL3D 
and ungroup it.
11) Go into memory manager, archive all the programs and delete ROL3D 
12) Go in the MEM menu and choose the Group option. Choose Ungroup and look for ROL3E 
and ungroup it.
13) Go into memory manager, archive all the programs and delete ROL3E.
14) Go in the MEM menu and choose the Group option. Choose Ungroup and look for ROL3F 
and ungroup it.
15) Go into memory manager, archive all the programs and the Pic files and delete ROL3F .
16) Go to your calc and go in the MEM menu and choose the Group option. Choose Ungroup and 
look for ROL3G and ungroup it.
17) Go in the memory manager and delete ROL3G. prgmR and prgmLEGENDR3 must stay 
in the RAM.
18) To run the game, simply run LEGENDR3 (on OS 1.13 you must run it from MirageOS 1.2) 
and prepare to enter where legends reigns�

IMPORTANT NOTE!!!!!!!!!!!! For unknown reasons, the main program will not work on some 
calculator OS (mostly happens on TI-84+/SE. Upon launching the game an ERR:UNDEFINED 
will occur. If this happens, simply unarchive prgmRL3, prgmZ, prgmZDEL, prgm0 and execute 
prgmRL3 from the PRGM menu to play the game. In this case you cannot use MirageOS.


4:Story

The story mainly occurs in the future. Lekens, Zanik and Nomesi start in 2235 A.D., a post-
apocalyptic world where chaos reigns and they are the *only* survivors to the emperor attack. 
They must kill him, but unfortunately, they run into three monsters and can't defeat them, so the 
humanity ends here. 382 years later, Xemeca, a mysterious man, decides to return in 2200, where 
Lekens lives to give magic to him, as well as to the two others. You must find Zanik and Nomesi 
so Xemeca can explain them the quest�


5:How to play

When the game starts, the screen will *shut down* (it's normal). After 5 seconds you should 
have this screen:
 

DON'T PANIC!!!!! Although the game uses ASM programs to run archived pictures and 
programs, it still need to do some archiving/unarchiving to avoid crashing the calculator and 
destroying all your files so it will take A LONG time to load (except on the TI-84+). Because 
archiving and unarchiving fragment the Flash ROM and take more and more time to find enough 
space to write a prgm in the archive memory, you must garbage collect periodically. It will load 
faster if the only game you have on your calc is this one ?. If you have a TI-84+, archiving will 
be faster because it only has 480 KB of archive memory so finding a space in the Flash ROM is 
easier. If the loading bar freezes, it's due to the fact the calc is writing data in the archive so it can 
be useful to see if you need a garbage collection. 



After it's finished, a menu with options will appear. Select "NEW GAME" and wait for the intro 
is finished. 


In a RPG, you have to talk to citizens, explore and fight powerful monsters to get useful treasures 
and clues. As you fight and gain experience points, you level up and become more powerful. To 
face more powerful foes, you'll need to fight a lot.

Although it's important to fight, you may need to buy orbs (a mix with items and magic) to heal 
yourself or defeat monsters faster. 


6:Controls

Keys used in that game are almost the same than in my previous releases but you may want to 
know them.

Title screen menu
-Arrows: Toggle options
-Enter: Confirm
-( - ): Cancel
-Clear: Enter the CLEAR menu	
-ON: Quick exit 

Main menu
-Arrows: Toggle options/configuration
-Enter: Confirm
-( - ): Cancel
-Clear: Enter the CLEAR menu	
-ON: Quick exit 

CLEAR menu
-Clear/enter/( - )/1: Resume
-2: Turn the calculator OFF to save batteries (no data loss)
-3: Garbage collect
-4: Exit the game safely
-Clear: Enter the CLEAR menu
-ON: Quick exit 





Walking
-Arrows: Walk
-Enter: Talk/enter the airship
-( - ):  Enter the main menu
-Clear: Enter the CLEAR menu
-ON: Quick exit 

Airship
-Left/right: Change direction
-Up: Accelerate
-Down: Stop
-Enter/( - ): Land and exit
-Clear: Enter the CLEAR menu
-ON: Quick exit

Shopping
-Arrows: select number of orbs to buy
-)/(: Toggle orbs
-( - ): Exit the shop
-Clear: Enter the CLEAR menu	
-ON: Quick exit 

Going to the inn
-Arrows: Toggle options
-Enter: Confirm
-( - ): Exit the inn
-Clear: Enter the CLEAR menu	
-ON: Quick exit 

Talking
-Arrows: Toggle options (if there are any)
-Enter/( - ): Display the next part of text/stop talking
-Clear: Enter the CLEAR menu	
-ON: Quick exit

Battles
-Up/down: Toggle battle commands
-Left: Show hidden command (WAIT)
-Right: Show hidden command (FLEE)
-Enter: Confirm
-( - ): Cancel/skip the character turn
-Clear: Enter the CLEAR menu	
-ON: Quick exit




7: Orbs

The Reign of Legends magic system work a bit differently than other RPGs. In RL, items act as 
magic (orbs). For example, you can have 30 PYROs and if you use one, the number decrease by 
1. You can buy these items in shops and each unity cost an amount of GP. This means that if you 
run out of PYRO, you can use something else. No more Magic Points required! Note that you can 
have a maximum of 99 of each kind of orbs.


8:Battles

When you walk or talk to someone, you may be engaged into a battle. Be prepared for anything!


Be warned! If you  encounter these monsters in the game, escape!!!



Early in the game, you can only use the FIGHT, FLEE and WAIT commands. Later, you can get 
abilities allowing you to use the more advanced ones. You can display hidden commands with 
LEFT/RIGHT arrows. Here is the description of commands:

-FIGHT: Attack a monster
-STEAL: Yes! One of the first calculator RPG with a STEAL command! Steal orbs from foes
-SPIRIT: Sacrify HP to attack all enemies
-SPY: View monster's LV, HP, EXP and GP
-ORB: Use consumable magic to attack or heal. There is more than 10 orbs in total.
-WAIT: Wait for next turn
-FLEE: Escape from battles. You cannot escape from bosses.
Basically, you must keep your HP high to not get killed. Orbs that resurrect dead members cost A 
LOT of money. Also bring lot of orbs with you and don't waste powerful healing orbs outside of 
battle. After winning a fight, you can get experience points and when you reach a certain amount, 
you level up and your stats increases.


9: Menu

Here you can view your stats and change many things.
-The ORBS option allow you to heal party members. You just have to select an highlighted orb 
name and then select the character to heal.
-The STATUS option allow you to see how many exp points you need to level up. You can also 
view your attack power, your defense and your battle commands.
-You may not believe it, but you are really seeing a ROW option in the screenshot! Trust me, it's 
really in the game� yes!!! In a calculator RPG!!!! The ROW option is useful to put low HP 
fighter or orb users in back or in the middle (yes!!! There is even three rows in this game! ? ). If 
you put your character in front, his weapon attack power will increase but his defense will 
decrease against physical attack. If you put him in the back, he will have a better defense against 
physical attack, but less weapon attack power. If you don't want to be a piece of meat in a new 
game, you may want to keep everyone in the back.
-CONFIG (you can even CONFIG THE GAME!!!) allow you to change the battle speed, the 
status box emplacement in battle and turn on or off the ATB (Active Time Bar) gauge.
-SAVE is to save the game. You can choose one of the two save files.


10: Features

You probably wondering why this game takes that much space. It's because of all the features.

-One of the only TI-RPG coming from Quebec (Canada)
-Fast loading in menu and battles.
-A storyline with over 16 hours of game play
-3 characters
-Magic Feed-back (a.k.a. New Game + in Chrono Trigger)
-Enhanced graphics using Codex, Zpic and Basic Tools programs
-ERR:MEMORY free
-Garbage Collect are really rare
-Some programs are copied in the RAM with Flash Gordon to avoid archiving/unarchiving
-High quality magic animations
-Changing character row in battles
-Each character has different abilities (including stealing items from foes)
-4 world maps
-You can travel in time (like in Chrono Trigger)!
-Over 70 cool looking monsters
-Huge boss graphics
-Different battle scenes
-30 locations with over 1000 screens
-More than 10 magic orbs 
-Shop and Inn
-Interaction with NPCs (Non-Playable-Characters) outside and inside the houses
-Big villages (16 x 20 tile-map instead of 8 x 16)
-Mini-games
-Many side-quests
-Over 17 KB of movies (around one hour)
-Specials events
-Airship
-2 compressed save files (They used to be 700 bytes and they shrinked down to 160!)
-And many others features I forgot� ?


11: Bugs

This game was programmed on a TI-83 Plus Silver Edition under OS 1.14. The game should be 
compatible with all OS available for the TI-83 + SE and the TI-84 serie. However, there may be 
some compatibility issues. Most of them are avoidable if you read this section carefully.
-For unknown reasons, the main program (LEGENDR3) will not work on some calculator OS 
(mostly happens on TI-84+/SE). Upon launching the game an ERR: UNDEFINED will occur. If 
this happens, simply unarchive prgmRL3, prgmZ, prgmZDEL, and prgm0 and execute prgmRL3 
from the PRGM menu to play the game.
-The game has near 145 sub-routines (programs) so it will not work properly with the OS 1.13. 
This OS crashes with over 50 programs in the PRGM menu. Make sure you have the OS 1.14 or 
higher. To play without any problem on OS 1.13, you need MirageOS 1.2 shell.
-If you have a TI-83+ (black model), the game will run really slowly if you don't overclock your 
calculator (go at http://ftp83plus.net/. They have a good tutorial about overclocking your 
calculator).


12:Version history

-1.63: Fixed bug with VITAL orb.
-1.60: Now compatible with MirageOS 1.2 (which is required to run RL3 on OS 1.13)
-1.56: Fixed a bug with LIFE and RETURN orbs.
-1.55: No more archiving/unarchiving in random battles. At high level, a random fight will now 
last 30 seconds instead of  4 minutes!
-1.50: Faster loading bar when the game starts (use Line( instead of reverse-video text), less 
archiving/unarchiving. Some bug fixes.
-1.26: Entering the menu and saving your game now load as fast as a lightning!
-1.16: Some balance with some enemies strength/reward ratio. The ERR:UNDEFINED with the 
"SAINT" orb have been fixed.
-1.15: Flash Gordon issues when using orbs in battles and playing mini-games had been fixed. 
-1.10: The game now uses Flash Gordon, eliminating ERR:MEMORY in battles. The game is 
slightly faster and there is less Garbage Collection messages. The game lost 2000 bytes. Also as 
it took 10 seconds to exit the menu before, now it takes only less than one second!
-1.00: Full-version!
-0.96: Beta version. The final boss works.
-0.95: Third demo. Some bug fixes.
-0.93: Second demo release. The final dungeon now works and the game now use Codex 1.2 
instead of Codex 1.0 and doesn't use Zflash anymore.
-0.81: First demo release.




13: Frequently asked questions

You probably have some questions about my game. Instead of e-mailing me 50 times about the 
same questions, look here. You may find your answer. Some questions here came from 
Maxcoderz forum. If the answer isn't here, post them at http://omnimaga.dyndns.org/index.php?showforum=58 
or e-mail me.

-Q: RL1 and RL2 were in French. This time, is there an English version?
A: Many people requested an English version of RL1 and RL2 so they are now in French and in 
English (check http://omnimaga.dyndns.org).

-Q: I can't believe it! Is it really BASIC?
A: Yes but the game use 1400 bytes of ASM utilities, allowing me to move sprites, and make 
awesome looking animations, fade-in and fade-out� everything that ASM can do but slower. 

-Q: When I start the game, the calc shut down! I press ON and nothing happens. So I remove a 
battery and when I press ON again, my memory is still here! What the heck?
A: LOL!!! This happens to new RL3 users that believe that the game is 100% BASIC. When 
something loads pixel-by-pixel (for example, a map loading), the contrast go lighter so you 
cannot see all the crappy things and glitches appear on the screen. Just wait at least 50 seconds. 
The screen should come back before that. If nothing happens after 50 seconds, maybe you did 
something wrong ?.

-Q: Where are those orbs?
A: Wait 'til you find Nomesi and return back in 2200 A.D. with him. You'll find shops which sell 
orbs and the ORBS command will be available in battles. Some monsters also give orbs.

-Q: Are you kidding???? Is there really a ROW and CONFIG option in the game or is it a fake 
screenshot you show here?
A: Do you really think I would release a game with fake information? Just go in the menu and 
look by yourself ?. There is even three rows instead of two.

-Q: I can't defeat the Erten in the Gaia Volcano. Help!
A: You suck! No I'm kidding ?. Make sure your HP is at maximum before entering the volcano 
and only use physical attacks. I beaten him at LV 2.

-Q: The game is SLOW!!!!!!
A: What did you expect? This game use archive, sprites and the graph screen and it's in BASIC. 
If you want speed, download The Reign of Legends 2.

-Q: It takes 1.5 seconds to move Lekens around the screen.
A: I guess you're playing on a normal TI-83+ (black model). This game is for the 15 MHz 
calculators (83+SE/84+/84+SE) only. Try to get a cheap one at Ebay.

-Q: I'm bored of those little calculator RPGs. I beaten the largest ASM game in 5 hours. Did I got 
the right RPG?
A: Yes. Well, some of my other release are even longer. It takes 16 hours to beat RL3 but it can 
take between 25 and 40 hours to beat Illusiat 12. I hope people will take example of this RPG to 
create more decent games.

-Q: It took me 25 hours to beat RL1 and 20 hours to beat RL3, and RL3 is like twice bigger! 
What the hell???
A: It's because RL3 is more complex and have greater graphics. Maybe it's also because RL3 is 
easier to beat ?.

-Q: Even if it was slow, I was impressed about your game so I hacked it to see your code and I 
don't understand anything. How long did you take to make it?
A: Six months (without the debugging). I never took that long to program others games I made 
before. It took me one and half a month to write RL1 and two months for RL2. I had to re-write 
the whole code to make it graphical and you know, making good graphics is one of the hardest 
part of the game making, especially with small sprites. I did optimization (although it's still 
slow). When Justin Whales released Codex in December 2nd 2003, I though: "BASIC will never 
be the same again". I started drawing my sprites the same day and the next morning I officially 
announced my new project at Maxcoderz forum. The project never died. I'm inactive in the TI-
community during summers and holidays, but I'm always coding� YOU HACKED MY 
GAME??????? 

-Q: Can I take part of your code for my future project?
A: NO! You can inspire yourself with the sprites, but try learning and do the coding by yourself. 
Everyone can learn TI-BASIC ?.

-Q: The loading at the beginning of the game is soooo long! Why???
A: Try to free up some archive space or garbage collect. I integrated a failsafe system in all the 
Reign of Legends games because I know there is n00bs and hackers who don't even read this 
README and archive/unarchive anything that should not be archived/unarchived so the 
calculator do it for them. This feature attempt to archive programs that needs to be archived and it 
takes between 40 and 60 seconds to load. If you unarchive programs that are always archived 
during game play, it may take up to 20 minutes so don't hack my game. Maybe I should release 
two different versions of the game: Normal Package and n00b package� no it would be dumb� 
Ok PLEASE READ README FILES WHEN YOU DOWNLOAD SOMETHING!!!!

-Q: I know FFTOM by Hitoshi has an ERR:MEMORY detector and things similar to that in the 
game. Did you do the same thing?
A: No. In fact I don't need that because RL3 is 100% ERR:MEMORY free. It runs under 10000 
KB of RAM in battles (version 1.10 or later) and archive useless programs when needed. In the 
final version, big programs like half of the battle engine stay archived, even when executed. 
Pictures I've created stay in the archive too. The only thing it detect is if a variable is archived, 
you get an error and on-screen instructions.

-Q: When I select my save file, It says that the file is empty or damaged!!!!
A: This happens when you hack the save files. Morale: Don't hack my games. The save files are 
encrypted and compressed so if you think you can modify them you're doing a big mistake.

-Q: Zapi, an ASM utility would allow you to display maps instantly, making the game loading 10 
times faster. Why don't you use it?
A: Because my game has near 1000 maps and I would have to recode everything again. 1000 
8x12 maps would add between 10 KB and 90 KB to the file size. I would also need to convert the 
sprites too. Anyway, I can't get this function to work.

-Q: Oops!!!  I exited with ON. I know it's a huge RPG. Is my saved game damaged?
A: No because they are saved into list. That's why you can have more than one game on one 
calculator. 

-Q: Will you learn ASM?
A: I'm learning it, but I'll not make huge RPGs like that. I'll use the ASM to make sub-routines 
for my future projects.


14: Special thanks

-Justin Whales for the Codex program
-Kevtiva Interactive for Zpic and Flash Gordon
-Toaster_7 for having found Flash Gordon on the web
-Michael Vincent for BASIC Tools
-All the great support on DragonFire Programming, Maxcoderz, Unitedti, Calcgames,  Greenfire 
and French Forum TI.


15:Disclaimers

-You may not use code of this game in your programs. To do so, you must use The Reign of 
Legends 1 code.
-I cannot be held  responsible of any damage caused to your calculator.














� 2004, by K�vin Ouellet.  
http://omnimaga.dyndns.org
Email me at omnimaga@gmail.com
