Wheel Of Fortune by Brian Smith(a_bretherino) Copyright (c) 2017, a_bretherino. All rights reserved.
Both of the group files in the containing folder are required for the game to work properly.

-=Introduction=-
Wheel of Fortune: a game for 2-3 players modeled exactly after the original game show.

Here is the order of rounds
Round 1: Tossup $1000
Round 2: Tossup $2000
Round 3: First normal round
Round 4: Second normal round
Round 5: Prize Puzzle
Round 6: Tossup $3000
Round 7: Third normal round
Round 8: Final Spin
Round 9: Tossup $1000 if there is a tie
Round 10: Bonus Round


-=Compatibility=-
Only TI 84+CE/CSE
This is because these are the only ones with a 26x10 screen.


-=Installation=-
Use TI Connect or a similar software to transfer WOFF.8xg to your calculator.


-=How to play=-


Tossups:

Letters appear randomly on the board. The first person to press their 
buzzer gets a chance to guess the puzzle. If they get it correct, they
get the prize money. Otherwise, they are out for that round. 
The buzzers are as follows:
Player 1: "y="
Player 2: "."
Player 3: "graph"
*To make the game 2-player, when it asks for your name, set Player 2's name to "OUT".*
If you make the game 2-player (^) the buzzers are:
Player 1: "y="
Player 2: "graph"

Normal Rounds:

You can spin(by pressing 1), solve(by pressing 2), chose a vowel(by 
pressing 3), or quit(by pressing 4). You must have at least $250 to 
buy a vowel. The prize for solving is $1000. If you spin a bankrupt,
you only lose the money you got that round.


Final Spin:

Pat spins the wheel and adds $1000 to the spin. You get to chose 1 
letter before trying to solve. You only get the money you accumulated
that round if you solve the puzzle. 


Bonus Round:
R,S,T,L,N, and E are given for you. Then you choose 2 consonants, THEN
one vowel. IMPORTANT: You MUST put the vowel LAST. In the real show, you
get 10 seconds to solve the puzzle, but hardly anyone can type that fast
so you just get 4 tries. 

==========
IMPORTANT: WHENEVER YOU ARE TYPING AND SEE THE LITTLE BLINKER, YOU MUST PRESS "alpha" BEFORE EACH LETTER(or 2nd+alpha before the phrase).
==========
