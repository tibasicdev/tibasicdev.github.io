     _____ _   _      _    
    / ____| | (_)    | |   
   | (___ | |_ _  ___| | __
    \___ \| __| |/ __| |/ /
    ____) | |_| | (__|   < 
   |_____/ \__|_|\___|_|\_\
   | |  | |                
   | |__| | ___ _ __ ___   
   |  __  |/ _ \ '__/ _ \  
   | |  | |  __/ | | (_) | 
   |_|  |_|\___|_|__\___/  
        / ____|  ____|     
       | |    | |__        
       | |    |  __|       
       | |____| |____      
        \_____|______|     
                           
                           
        ______      ______       
  _____|______|____|______|_____ 
 |______|____|______|____|______|
  _____|______|____|______|_____ 
 |______|____|______|____|______|
  _____|______|____|______|_____ 
 |______|    |______|    |______|
                                 

This is Stick Hero CE, a Stick Hero port by _iPhoenix_!

Stick Hero is a game by Ketchapp, ported to the CSE by PT_, who graciously gave me permission to port it to the CE with an “uhh sure” via SAX.

I took massive inspiration from his port, so I’ll link to both the original game and his CSE port below. 

- _iPhoenix_ (https://www.cemetech.net/forum/profile.php?mode=viewprofile&u=17249)

PT_’s port: https://www.cemetech.net/programs/index.php?mode=file&id=1408
PT_’s Cemetech Profile: https://www.cemetech.net/forum/profile.php?mode=viewprofile&u=10064

Original Game: https://play.google.com/store/apps/details?id=com.ketchapp.stickhero&hl=en

Check it out!
