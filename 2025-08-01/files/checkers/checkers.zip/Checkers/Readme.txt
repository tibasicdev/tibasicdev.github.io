
 AI Checkers for the TI-83+ or TI-84+

 By Jeremy Ouillette (aka nitacku)

 email - nitacku36@yahoo.com

===============================================================

 Contents:


 I.	Included Files
 II.	Installation Instructions
 III.	Features of Checkers
 IV.	Using the Program
 V.	Controls
 VI.	Credits
 VII.	Contact Information

===============================================================

 I.	Included Files:


 Checkers.8xp	Main program
 pic8.8xi	Picture file

===============================================================

 II.	Installation Instructions:


 Step 1:	Send file Checkers.8xp to your TI-83+/TI-84+
 Step 2:	Send file Pic8.8xi to your TI-83+/TI-84+

===============================================================

 III.	Features of Checkers:


 *  Advanced AI with 3 levels of difficulty
 *  AI can play for any side including against itself
 *  Complete control through 8 customizable options
 *  Error detection prevents errors from occuring
 *  AutoSave option
 *  AutoLoad option

===============================================================

 IV.	Using the Program:


 To start the game, run program Checkers from the PRGM menu
 or run Checkers through MirageOS.

 This Checker game uses standard checker rules (available
 at http://www.jimloy.com/checkers/rules2.htm) with the
 exception that jumps are NOT mandatory.

 Below is a list of what each option does in the menus


 Main Menu:
		new		Stops any current game and
				clears the board for a new
				game

		load		Loads the last saved game

		save		Saves the current game

		extra		Opens the Extras Menu

		quit		Quits the game to the
				homescreen

 Extras Menu:
		white		Lets you choose between a human
				or AI player for white

		black		Lets you choose between a human
				or AI player for black

		AI level	Lets you choose the strength of
				the AI (level 1-3)

		thinking	Turns the AI's thinking on/off

		setting		Changes the type of game.
				Original uses the standard
				rules of checkers. Jyop (Jump
				Your Own Piece) allows you to
				jump over your own piece but
				won't remove it from the
				board

		turn		Changes which player's turn
				it currently is

		AutoLoad	Turns the AutoLoad on/off

		AutoSave	Turns the AutoSave on/off

		reset		Resets Checkers. Re-creates
				Pic0 (board) in case of
				deletion/overwritten. Returns
				all settings to original
				defaults

		about		Shows the Title Screen

		to menu		Returns back to the Main Menu

		to game		Resumes back to the current
				game

===============================================================

 V.	Controls:


 Title Screen:
		CLEAR		Quits game
		any key 	Continues game

 Main Menu:
		Y=		Starts a new game
		WINDOW		Loads the last saved game
		ZOOM		Saves the current game
		TRACE		Opens the Extra Menu
		GRAPH		Quits game
		CLEAR		Quits game
		down arrow	Resumes a game in progress


 Extras Menu:
		2ND		Selects option
		ENTER		Selects option
		arrows		Moves cursor
		CLEAR		Quits game


 During game:
		2ND		Selects/Un-selects piece
		ALPHA		Ends turn after jumping a piece
		TRACE		Opens Main Menu
		arrows		Moves cursor
		CLEAR		Quits game

===============================================================

 VI.	Credits:


 All content has been created and developed by
 myself (Jeremy Ouillette) and is my own original work

===============================================================

 VII.	Contact Information:


 If you have any comments or questions please feel free to
 email me at nitacku36@yahoo.com

===============================================================

		Thank you for downloading!
		I hope you enjoy this game!

===============================================================