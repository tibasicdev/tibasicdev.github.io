

extern int gif_base_delay_start;
void handle_screenshot();
