#include <stdio.h>
#include <string.h>
#include "calc.h"
#include "gif.h"
#include "lcd.h"
#include "gifhandle.h"

#define SCRXSIZE 96
#define SCRYSIZE 64

char *generate_gif_name(char *fn, int num, char *dest) {
	int i;
	for (i = strlen(fn) - 1; 
	 	 i && fn[i] != '.';
	 	 i--);
	 	 
	if (i) fn[i] = '\0';
	
	sprintf(dest, "%s%d.gif", fn, num);
	
	if (i) fn[i] = '.';
	return dest;
}

void handle_screenshot() {
	FILE* testfile;
	int result;
	LCD_t* lcd = calcs[gslot].cpu.pio.lcd;
	int i, j, s, marked;
	static char gif_fn_backup[MAX_PATH];
	BOOL running_backup = calcs[gslot].running;

	if ((gif_write_state != GIF_IDLE) && (!calcs[gslot].running)) gif_write_state = GIF_END;
	
	calcs[gslot].running = FALSE;
	switch (gif_write_state) {
		case GIF_IDLE:
		{
			gif_newframe = 0;
			break;
		}
		case GIF_START:
		{
			strcpy(gif_fn_backup, gif_file_name);
			
			if (gif_autosave) {
				/* do file save */
				if (gif_use_increasing) {
					char fn[MAX_PATH];
					FILE *test = (FILE*) 1;
					
					for (i = 0; test; i++) {
						generate_gif_name(gif_file_name, i, fn);
						test = fopen(fn, "r");
						if (test) fclose(test);
					}
					
					strcpy(gif_file_name, fn);
				}
			} else {
				if (SetGifName(TRUE)) {
					gif_write_state = GIF_IDLE;
					break;
				}
			}

			gif_xs = SCRXSIZE;
			gif_ys = SCRYSIZE;
			gif_base_delay = gif_base_delay_start;
			gif_time = 0;
			gif_newframe = 1;
			
			if (gif_colors == 2) {
				GIFBWLCD();
			} else {
				GIFGREYLCD();
			}
			for (i = 0; i < SCRYSIZE; i++) {
				for (j = 0; j < SCRXSIZE; j++) {
					gif_frame[i * gif_xs + j] = lcd->gif[i * LCD_PIX_WIDTH + j];
				}
			}
			break;
		}
		case GIF_FRAME:
		{
			gif_time += 1;
			if (gif_time >= gif_base_delay) {
				gif_time -= gif_base_delay;
				gif_newframe = 1;
				if (gif_colors == 2) {
					GIFBWLCD();
				} else {
					GIFGREYLCD();
				}
				for (i = 0; i < SCRYSIZE; i++) {
					for (j = 0; j < SCRXSIZE; j++) {
						gif_frame[i * gif_xs + j] = lcd->gif[i * LCD_PIX_WIDTH + j];
					}
				}
			}
			break;
		}
		case GIF_END:
		{
			gif_newframe = 1;
			gif_file_num++;
			
			strcpy(gif_file_name, gif_fn_backup);
			break;
		}
	}
	calcs[gslot].running = running_backup;
	
	if (gif_newframe) {
		gif_newframe = 0;
		gif_writer();
	}
}




