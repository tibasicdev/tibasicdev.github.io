#ifndef SAVESTATE_H
#define SAVESTATE_H


typedef struct {
	char tag[4];
	int pnt;
	int size;
	unsigned char* data;
} CHUNK_t;


typedef struct {
	int version_major;
	int version_minor;
	int version_build;
	int model;
	int chunk_count;
	char author[32];
	char comment[64];	
	CHUNK_t* chunks[512];
} SAVESTATE_t;


#define CUR_MAJOR 0
#define CUR_MINOR 0
#define CUR_BUILD 0


#define DETECT_STR		"*WABBIT*"
#define DETECT_CMP_STR	"*WABCMP*"

#define NO_CMP			0
#define ZLIB_CMP		1

#define SAVE_HEADERSIZE	116


#define INFO_tag		"INFO"
#define CPU_tag			"CPU "
#define MEM_tag			"MEMC"
#define ROM_tag			"ROM "
#define RAM_tag			"RAM "
#define TIMER_tag		"TIME"
#define LCD_tag			"LCD "
#define LINK_tag		"LINK"
#define STDINT_tag		"STDI"
#define SE_AUX_tag		"SEAX"



void WriteSave(const char * , SAVESTATE_t *, int );
void LoadSlot(SAVESTATE_t* , int );
SAVESTATE_t* SaveSlot( int );
SAVESTATE_t* CreateSave(char* , char* , int );
SAVESTATE_t* ReadSave(FILE* ifile);
char* GetRomOnly(SAVESTATE_t* save,int*);
#endif

