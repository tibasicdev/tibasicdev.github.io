#ifndef PRINT_H
#define PRINT_H
#include <stdarg.h>
#include "disassemble.h"

void mysprintf(Z80_info_t*, char *, const char *, ...);

#endif
