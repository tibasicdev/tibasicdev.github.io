#ifndef LABEL_H
#define LABEL_H



typedef struct {
    char *name;
    unsigned int value;
} label_struct;

typedef struct {
	int page;
	int total_labels;
	label_struct label_array[6000];
} page_labels_t;

typedef struct {
	int total_pages;
	page_labels_t* page[256];
} labels_t;

int labels_app_load(int slot, int app, char* fn);
char* FindAddressLabel( int slot, int p, unsigned int address);
//void ImportBcalls(char* fn);
char* FindBcall(int address);
void FindFlags(int flag,int bit, char **flagstring, char **bitstring);
void VoidLabels(int slot);
int lookup_label(char *label);
#endif

