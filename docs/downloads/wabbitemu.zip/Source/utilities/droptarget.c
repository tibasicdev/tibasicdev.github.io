//
//	from DROPTARGET.CPP
//
//	By J Brown 2004 
//
//	www.catch22.net
//
//  this is 'pure C' version
#define STRICT

#include <windows.h>
#include "wbded.h"

HRESULT CreateDropTarget(HWND hwnd, WB_IDropTarget **ppDropTarget);
void DropData(HWND hwnd, IDataObject *pDataObject);

extern POINT drop_pt;
extern BOOL do_drag;
//
//	QueryDataObject private helper routine
//
static BOOL QueryDataObject (WB_IDataObject *pDataObject)
{
	FORMATETC fmtetc = { CF_HDROP, 0, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };

	// does the data object support CF_TEXT using a HGLOBAL?
	return pDataObject->ido.lpVtbl->QueryGetData((LPDATAOBJECT)pDataObject, &fmtetc) == S_OK ? TRUE : FALSE;
}

//
//	DropEffect private helper routine
//
static DWORD DropEffect(DWORD grfKeyState, POINTL pt, DWORD dwAllowed)
{
	DWORD dwEffect = 0;

	// 1. check "pt" -> do we allow a drop at the specified coordinates?
	
	// 2. work out that the drop-effect should be based on grfKeyState
	if(grfKeyState & MK_CONTROL)
	{
		dwEffect = dwAllowed & DROPEFFECT_COPY;
	}
	else if(grfKeyState & MK_SHIFT)
	{
		dwEffect = dwAllowed & DROPEFFECT_MOVE;
	}
	
	// 3. no key-modifiers were specified (or drop effect not allowed), so
	//    base the effect on those allowed by the dropsource
	if(dwEffect == 0)
	{
		if(dwAllowed & DROPEFFECT_COPY) dwEffect = DROPEFFECT_COPY;
		if(dwAllowed & DROPEFFECT_MOVE) dwEffect = DROPEFFECT_MOVE;
	}
	
	return dwEffect;
}

//
//	IUnknown::AddRef
//
static ULONG STDMETHODCALLTYPE idroptarget_addref (WB_IDropTarget* This)
{
  return InterlockedIncrement(&This->m_lRefCount);
}

//
//	IUnknown::QueryInterface
//
static HRESULT STDMETHODCALLTYPE
idroptarget_queryinterface (WB_IDropTarget *This,
			       REFIID          riid,
			       LPVOID         *ppvObject)
{

  *ppvObject = NULL;

//  PRINT_GUID (riid);
  if (IsEqualIID (riid, &IID_IUnknown) || IsEqualIID (riid, &IID_IDropTarget))
    {
      idroptarget_addref (This);
      *ppvObject = This;
      return S_OK;
    }
  
  else
    {
      return E_NOINTERFACE;
    }
}


//
//	IUnknown::Release
//
static ULONG STDMETHODCALLTYPE
idroptarget_release (WB_IDropTarget* This)
{
    
  LONG count = InterlockedDecrement(&This->m_lRefCount);

  if(count == 0)
	{
		g_free(This);
		return 0;
	}
	else
	{
		return count;
	}
  
}
//
//	IDropTarget::DragEnter
//
//
//
static HRESULT STDMETHODCALLTYPE idroptarget_dragenter(WB_IDropTarget* This, WB_IDataObject * pDataObject, DWORD grfKeyState, POINTL pt, DWORD * pdwEffect)
{
	// does the dataobject contain data we want?
	This->m_fAllowDrop = QueryDataObject(pDataObject);

	if(This->m_fAllowDrop)
	{
		// get the dropeffect based on keyboard state
		*pdwEffect = DropEffect(grfKeyState, pt, *pdwEffect);

		SetFocus(This->m_hWnd);

		drop_pt = pt;
		do_drag = TRUE;
	}
	else
	{
		*pdwEffect = DROPEFFECT_NONE;
	}

	return S_OK;
}

//
//	IDropTarget::DragOver
//
//
//
static HRESULT STDMETHODCALLTYPE idroptarget_dragover(WB_IDropTarget* This, DWORD grfKeyState, POINTL pt, DWORD * pdwEffect)
{
	if(This->m_fAllowDrop)
	{
		drop_pt = pt;
		
		*pdwEffect = DropEffect(grfKeyState, pt, *pdwEffect);
	}
	else
	{
		*pdwEffect = DROPEFFECT_NONE;
	}

	return S_OK;
}

//
//	IDropTarget::DragLeave
//
static HRESULT STDMETHODCALLTYPE idroptarget_dragleave(WB_IDropTarget* This)
{
	do_drag = FALSE;
	return S_OK;
}

//
//	IDropTarget::Drop
//
//
static HRESULT STDMETHODCALLTYPE idroptarget_drop(WB_IDropTarget* This, IDataObject * pDataObject, DWORD grfKeyState, POINTL pt, DWORD * pdwEffect)
{
	if(This->m_fAllowDrop)
	{
		do_drag = FALSE;
		drop_pt = pt;
		DropData(This->m_hWnd, pDataObject);
		*pdwEffect = DropEffect(grfKeyState, pt, *pdwEffect);
	}
	else
	{
		*pdwEffect = DROPEFFECT_NONE;
	}

	return S_OK;
}

static WB_IDropTargetVtbl idt_vtbl = {
  idroptarget_queryinterface,
  idroptarget_addref,
  idroptarget_release,
  idroptarget_dragenter,
  idroptarget_dragover,
  idroptarget_dragleave,
  idroptarget_drop
};

void DropData(HWND hwnd, IDataObject *pDataObject)
{
	// construct a FORMATETC object
	FORMATETC fmtetc = { CF_HDROP, 0, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
	STGMEDIUM stgmed;

	if(pDataObject->lpVtbl->QueryGetData(pDataObject, &fmtetc) == S_OK)
	{
		// Yippie! the data is there, so go get it!
		if(pDataObject->lpVtbl->GetData(pDataObject, &fmtetc, &stgmed) == S_OK)
		{
			// we asked for the data as a HGLOBAL, so access it appropriately
			PVOID data = GlobalLock(stgmed.hGlobal);

			SendMessage(hwnd, WM_DROPFILES, (WPARAM) data, 0);
			//SetWindowText(hwnd, (char *)data);

			GlobalUnlock(stgmed.hGlobal);

			// release the data using the COM API
			ReleaseStgMedium(&stgmed);
		}
	}
}

void RegisterDropWindow(HWND hwnd, WB_IDropTarget **ppDropTarget)
{
	WB_IDropTarget *pDropTarget;
	
	CreateDropTarget(hwnd, &pDropTarget);

	// acquire a strong lock
	CoLockObjectExternal((struct IUnknown*)pDropTarget, TRUE, FALSE);

	// tell OLE that the window is a drop target
	RegisterDragDrop(hwnd, (LPDROPTARGET)pDropTarget);

	*ppDropTarget = pDropTarget;
}

void UnregisterDropWindow(HWND hwnd, IDropTarget *pDropTarget)
{
	// remove drag+drop
	RevokeDragDrop(hwnd);

	// remove the strong lock
	CoLockObjectExternal((struct IUnknown*)pDropTarget, FALSE, TRUE);

	// release our own reference
	pDropTarget->lpVtbl->Release(pDropTarget);
}

//	Constructor for the CDropTarget class
//

WB_IDropTarget * WB_IDropTarget_new(HWND hwnd)
{
  WB_IDropTarget *result;

  result = g_new0(WB_IDropTarget, 1);

  result->idt.lpVtbl = (IDropTargetVtbl*)&idt_vtbl;

  result->m_lRefCount  = 1;
  result->m_hWnd = hwnd;
  result->m_fAllowDrop = FALSE;
  
  return result;
}

HRESULT CreateDropTarget(HWND hwnd, WB_IDropTarget **ppDropTarget) 
{
	if(ppDropTarget == 0)
		return E_INVALIDARG;

	*ppDropTarget = WB_IDropTarget_new(hwnd);

	return (*ppDropTarget) ? S_OK : E_OUTOFMEMORY;

}

