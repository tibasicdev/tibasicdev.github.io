#include "guidebug.h"

#include "calc.h"

#include "dbmem.h"
#include "dbdisasm.h"
#include "dbreg.h"

extern HINSTANCE g_hInst;

RECT db_rect = {-1, -1, -1, -1};

static unsigned int cyDisasm = 218, cyMem = 116;


BOOL CALLBACK EnumDebugResize(HWND hwndChild, LPARAM lParam) {
	int idChild;
	RECT *rcParent = (RECT*) lParam;
	
	
	idChild = GetWindowLong(hwndChild, GWL_ID);
	switch (idChild) {
		case ID_DISASM:
			MoveWindow(hwndChild, 0, 0, rcParent->right - 200, cyDisasm, TRUE);
			break;
		case ID_REG:
			MoveWindow(hwndChild, rcParent->right - 200, 0, 200, rcParent->bottom, TRUE);
			break;
		case ID_MEM:
			MoveWindow(hwndChild, 0, cyDisasm + 10, rcParent->right - 316, cyMem, TRUE);
			break;
		case ID_STACK:
			MoveWindow(hwndChild, rcParent->right - 300, cyDisasm + 10, 100, cyMem, TRUE);
			break;
	}
	SendMessage(hwndChild, WM_USER, DB_UPDATE, 0);
	return TRUE;
}


BOOL CALLBACK EnumDebugUpdate(HWND hwndChild, LPARAM lParam) {
	SendMessage(hwndChild, WM_USER, DB_UPDATE, lParam);
	return TRUE;
}	





LRESULT CALLBACK DebugProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	static HWND hdisasm, hreg, hmem;
	static double ratioDisasm;
	static mp_settings mps[3];
	static dp_settings dps;
	
	static BOOL bDrag = FALSE;
	static int offset_click;
	switch (Message) {
		case WM_CREATE:
		{
			/* Create diassembly window */
			dps.nSel = calcs[gslot].cpu.pc;
			
			hdisasm = 
			CreateWindow(
				g_szDisasmName,
				"disasm",
				WS_VISIBLE | WS_CHILD,
				0, 0, 1, 1,
				hwnd,
				(HMENU) ID_DISASM,
				g_hInst, &dps);

			hreg = 
			CreateWindow(
				g_szRegName,
				"reg",
				WS_VISIBLE | WS_CHILD | WS_CLIPCHILDREN,
				0, 0, 1, 1,
				hwnd,
				(HMENU) ID_REG,
				g_hInst, NULL);
				
			mps[0].addr = 0x0000;
			mps[0].mode = MEM_BYTE;
			mps[0].sel = 0x000;
			mps[0].track = -1;
			
			CreateWindow(
				g_szMemName,
				"Memory",
				WS_VISIBLE | WS_CHILD,
				0, 0, 1, 1,
				hwnd,
				(HMENU) ID_MEM,
				g_hInst, &mps[0]);

			mps[1].addr = calcs[gslot].cpu.sp;
			mps[1].mode = MEM_WORD;
			mps[1].sel = mps[1].addr;
			mps[1].track = offsetof(struct CPU, sp);

			CreateWindow(
				g_szMemName,
				"Stack",
				WS_VISIBLE | WS_CHILD,
				0, 0, 1, 1,
				hwnd,
				(HMENU) ID_STACK,
				g_hInst, &mps[1]);	
				
			RECT rc;
			GetClientRect(hwnd, &rc);	
			ratioDisasm = (double) cyDisasm/ rc.bottom;
			
			SetFocus(hdisasm);
			return 0;
		}
		case WM_ACTIVATE:
			SetFocus(hdisasm);
			return 0;
		case WM_SIZE:
		{
			RECT rc;
			GetClientRect(hwnd, &rc);
			
			if (!bDrag) {
				cyDisasm = (double)rc.bottom * ratioDisasm;
				cyMem = rc.bottom - cyDisasm - 26;
				ratioDisasm = (double) cyDisasm/ rc.bottom;
			}
			
			EnumChildWindows(hwnd, EnumDebugResize, (LPARAM) &rc);
			InvalidateRect(hwnd, NULL, TRUE);
			UpdateWindow(hwnd);
			return 0;
		}
		case WM_MOUSEMOVE:
		{
			int y = GET_Y_LPARAM(lParam) + 5 + offset_click;
			RECT rc;
			GetClientRect(hwnd, &rc);

			if (bDrag) {
				if (y < 0) y = 0;
				if (y > rc.bottom - 10) y = rc.bottom - 10;
				cyDisasm = y;
				cyMem = rc.bottom - cyDisasm - 26;
				SendMessage(hwnd, WM_SIZE, 0, 0);
			}
			HCURSOR hcursor = LoadCursor(NULL, IDC_SIZENS);
			int dy = abs(y - (cyDisasm + 8));
				
			if (dy < 16) SetCursor(hcursor);
			
			ratioDisasm = (double) cyDisasm/ rc.bottom;
			return 0;
		}
		case WM_LBUTTONDOWN:
		{
			int y = GET_Y_LPARAM(lParam);
			int dy = abs(y - (cyDisasm + 8));
			
			if (dy < 16) {
				bDrag = TRUE;
				offset_click = cyDisasm - y;
				SetCapture(hwnd);
				HCURSOR hcursor = LoadCursor(NULL, IDC_SIZENS);
				SetCursor(hcursor);
			}
			return 0;
		}
		case WM_LBUTTONUP:
		{
			ReleaseCapture();
			bDrag = FALSE;
			return 0;	
		}
		case WM_LBUTTONDBLCLK:
		{
			int y = GET_Y_LPARAM(lParam);
			int dy = abs(y - (cyDisasm + 8));
			
			if (dy < 16) {
				ratioDisasm = 0.5f;
				SendMessage(hwnd, WM_SIZE, 0, 0);
			}
			return 0;
		}
		case WM_COMMAND:
			SendMessage(hdisasm, Message, wParam, lParam);
			SendMessage(hreg, Message, wParam, lParam);
			break;
			
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc;
			
			#define DOT_WIDTH	3
			hdc = BeginPaint(hwnd, &ps);
			HBRUSH hbr = CreateSolidBrush(GetSysColor(COLOR_BTNSHADOW));
			
			RECT rectDot, rc;
			GetClientRect(hwnd, &rc);
			rectDot.left = (rc.right-200)/2 - 12;
			rectDot.right = rectDot.left + DOT_WIDTH;
			
			rectDot.top = cyDisasm + 5 - DOT_WIDTH/2;
			rectDot.bottom = rectDot.top + DOT_WIDTH;
			SelectObject(hdc, hbr);
			
			int i;
			for (i = 0; i < 3; i ++, OffsetRect(&rectDot, 8, 0)) {
				Ellipse(hdc, rectDot.left, rectDot.top, rectDot.right, rectDot.bottom);
			}
			
			RECT r;
			r.left = 0; r.right = rc.right - 200;
			r.top = cyDisasm;
			r.bottom = r.top + 10;
			
			DrawEdge(hdc, &r, EDGE_RAISED, BF_TOP|BF_BOTTOM|BF_SOFT);
			
			DeleteObject(hbr);
			EndPaint(hwnd, &ps);
			return 0;
		}
		case WM_USER:
			switch (wParam) {
				case DB_UPDATE:
					EnumChildWindows(hwnd, EnumDebugUpdate, 0);
					break;
			}
			return 0;
		case WM_CLOSE:
		case WM_DESTROY:
			CPU_step((&calcs[gslot].cpu));
			calcs[gslot].running = TRUE;
			GetWindowRect(hwnd, &db_rect);
			DestroyWindow(hwnd);
			return 0;
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
}




