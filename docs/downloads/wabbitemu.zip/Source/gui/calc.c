#define CALC_C
#include "calc.h"


// calc init will give you a cpu and a window, but the devices are up to you
// Return value:
//		if a calc is available, slot number is returned
//		otherwise, -1

void ClearDevices(CPU_t* cpu) {
	int i;
	for (i = 0; i < 256; i++) {
		cpu->pio.devices[i].active = FALSE;
		cpu->pio.interrupt[i] = -1;
		cpu->pio.skip_factor[i] = 1;
		cpu->pio.skip_count[i] = 0;
	}
}


int calc_new(void) {
	int i;
	for (i = 0; i < MAX_CALCS; i++) {
		if (calcs[i].active == FALSE) return i;
	}
	return -1;
}

void calc_erase_certificate( char* mem, int size) {
	if (mem == NULL || size < 32768) return;

	memset(mem + size - 32768, 0xFF, 16384);
	
	mem[(size-32768)]			= 0x00;
	mem[(size-32768)+0x1FE0]	= 0x00;
	mem[(size-32768)+0x1FE1]	= 0x00;
	return;
}

int rom_load(int slot, char * FileName) {
	TIFILE_t* tifile = importvar(FileName);
	if (slot == -1) return -1;
	if (!tifile) return -1;
	if (tifile->type == SAV_TYPE) {
		puts("Sav load");
		calcs[slot].model	=	tifile->model;
		switch (tifile->model) {
			case TI_82:
			case TI_83:
				puts("83 sav");
				if (calcs[slot].active) {
					calc_free(slot);
				}
				calcs[slot].active = TRUE;
				int size;
				char* rom = GetRomOnly(tifile->save,&size);
				char VerString[64];
				FindRomVersion(	tifile->model,
								VerString,
								rom,
								size);
				
				calc_init_83(slot,VerString);
				LoadSlot(tifile->save,slot);
				FindRomVersion(	tifile->model,
								calcs[slot].rom_version,
								calcs[slot].mem_c.flash,
								calcs[slot].mem_c.flash_size);

				strcpy(calcs[slot].rom_path, FileName);
				break;
			case TI_73:
			case TI_83P:
				puts("83+ sav");
				if (calcs[slot].active) {
					calc_free(slot);
				}
				calcs[slot].active = TRUE;
				calc_init_83p(slot);
				LoadSlot(tifile->save,slot);
				FindRomVersion(	tifile->model,
								calcs[slot].rom_version,
								calcs[slot].mem_c.flash,
								calcs[slot].mem_c.flash_size);

				strcpy(calcs[slot].rom_path, FileName);
				break;
			case TI_84PSE:
			case TI_83PSE:
				puts("83+SE sav");
				if (calcs[slot].active) {
					calc_free(slot);
				}
				calcs[slot].active = TRUE;
				calc_init_83pse(slot);
				LoadSlot(tifile->save,slot);
				FindRomVersion(	tifile->model,
								calcs[slot].rom_version,
								calcs[slot].mem_c.flash,
								calcs[slot].mem_c.flash_size);

				strcpy(calcs[slot].rom_path, FileName);
				break;
			default:
				puts("Unknown model");
				slot = -1;
				break;
		}

	} else if (tifile->type == ROM_TYPE) {
		calcs[slot].model	=	tifile->model;
		switch (tifile->model) {
			case TI_82:
			case TI_83:
				if (calcs[slot].active) {
					calc_free(slot);
				}
				
				calc_init_83(slot,tifile->rom->version);
				calcs[slot].active = TRUE;
				memcpy(	calcs[slot].cpu.mem_c->flash, 
						tifile->rom->data, 
						(calcs[slot].cpu.mem_c->flash_size<=tifile->rom->size)?calcs[slot].cpu.mem_c->flash_size:tifile->rom->size);
		
				memcpy(calcs[slot].rom_version, tifile->rom->version, 32);
				
				strcpy(calcs[slot].rom_path, FileName);
				calc_reset(slot);
				break;
			case TI_73:
			case TI_83P:
				if (calcs[slot].active) {
					calc_free(slot);
				}
				
				calc_init_83p(slot);
				calcs[slot].active = TRUE;
				memcpy(	calcs[slot].cpu.mem_c->flash, 
						tifile->rom->data, 
						(calcs[slot].cpu.mem_c->flash_size<=tifile->rom->size)?calcs[slot].cpu.mem_c->flash_size:tifile->rom->size);
				calc_erase_certificate(calcs[slot].cpu.mem_c->flash,calcs[slot].cpu.mem_c->flash_size);
				memcpy(calcs[slot].rom_version, tifile->rom->version, 32);
				
				strcpy(calcs[slot].rom_path, FileName);
				calc_reset(slot);
				break;
			case TI_84PSE:
			case TI_83PSE:
				if (calcs[slot].active) {
					calc_free(slot);
				}
				
				calc_init_83pse(slot);
				calcs[slot].active = TRUE;
				memcpy(	calcs[slot].cpu.mem_c->flash, 
						tifile->rom->data, 
						(calcs[slot].cpu.mem_c->flash_size<=tifile->rom->size)?calcs[slot].cpu.mem_c->flash_size:tifile->rom->size);
				calc_erase_certificate(calcs[slot].cpu.mem_c->flash,calcs[slot].cpu.mem_c->flash_size);
				memcpy(calcs[slot].rom_version, tifile->rom->version, 32);
				
				strcpy(calcs[slot].rom_path, FileName);
				calc_reset(slot);
				break;
			default:
				slot = -1;
				break;
		}
	} else slot = -1;
	FreeTiFile(tifile);
	return slot;
}



/*  82 83 */
BOOL calc_init_83(int slot,char* os) {
	/* INTIALIZE 83 */ 
	memory_init_83(&calcs[slot].mem_c); 
	tc_init(&calcs[slot].time_c, MHZ_6); 
	CPU_init(&calcs[slot].cpu, &calcs[slot].mem_c, &calcs[slot].time_c);
	ClearDevices(&calcs[slot].cpu);
	if (calcs[slot].model == TI_82) {
		if (memcmp(os,"19.006",6)==0) {
			device_init_83(&calcs[slot].cpu,0);
		} else {
			device_init_83(&calcs[slot].cpu,1);
		}
	} else {
		device_init_83(&calcs[slot].cpu,0);
	}
	/* END INTIALIZE 83 */

	calcs[slot].send			= FALSE;
	calcs[slot].audio			= &calcs[slot].cpu.pio.link->audio;
	calcs[slot].audio->enabled	= FALSE;
	calcs[slot].audio->init		= FALSE;
	return TRUE;
}

/* 73 83+ */
int calc_init_83p(int slot) {
	/* INTIALIZE 83+ */ 
	memory_init_83p(&calcs[slot].mem_c); 
	tc_init(&calcs[slot].time_c, MHZ_6); 
	CPU_init(&calcs[slot].cpu, &calcs[slot].mem_c, &calcs[slot].time_c);
	ClearDevices(&calcs[slot].cpu);
	device_init_83p(&calcs[slot].cpu);
	/* END INTIALIZE 83+ */

	calcs[slot].send			= FALSE;
	calcs[slot].audio			= &calcs[slot].cpu.pio.link->audio;
	calcs[slot].audio->enabled	= FALSE;
	calcs[slot].audio->init		= FALSE;
	return 0;
}

/* 83+se */
int calc_init_83pse(int slot) {
	/* INTIALIZE 83+se */ 
	memory_init_83pse(&calcs[slot].mem_c); 
	tc_init(&calcs[slot].time_c, MHZ_6); 
	CPU_init(&calcs[slot].cpu, &calcs[slot].mem_c, &calcs[slot].time_c);
	ClearDevices(&calcs[slot].cpu);
	device_init_83pse(&calcs[slot].cpu);
	/* END INTIALIZE 83+se */


	calcs[slot].send			= FALSE;
	calcs[slot].audio			= &calcs[slot].cpu.pio.link->audio;
	calcs[slot].audio->enabled	= FALSE;
	calcs[slot].audio->init		= FALSE;
	return 0;
}



void calc_free(int slot) {
	if (calcs[slot].active) {
		int i;
		calcs[slot].active = FALSE;
		KillSound(calcs[slot].audio);
		freenz(calcs[slot].mem_c.flash);
		freenz(calcs[slot].mem_c.ram);
		freenz(calcs[slot].cpu.pio.link);
		freenz(calcs[slot].cpu.pio.keypad);
		freenz(calcs[slot].cpu.pio.stdint);
		freenz(calcs[slot].cpu.pio.se_aux);
		if (calcs[slot].cpu.pio.lcd) {
			for(i=0;i<LCDSTACK_SIZE;i++){
				freenz(calcs[slot].cpu.pio.lcd->lcdstack[i]);
			}
		}
		freenz(calcs[slot].cpu.pio.lcd);
	}
}
	

	

int calc_reset(int slot) {
	memset(calcs[slot].mem_c.ram,0,calcs[slot].mem_c.ram_size);
	calcs[slot].cpu.pc			= 0;
	calcs[slot].cpu.sp			= 0;
	calcs[slot].cpu.interrupt	= FALSE;
	calcs[slot].cpu.imode		= 1;
	calcs[slot].cpu.ei_block	= FALSE;
	calcs[slot].cpu.iff1		= FALSE;
	calcs[slot].cpu.iff2		= FALSE;
	calcs[slot].cpu.halt		= FALSE;
	calcs[slot].cpu.read		= FALSE;
	calcs[slot].cpu.write		= FALSE;
	calcs[slot].cpu.output		= FALSE;
	calcs[slot].cpu.input		= FALSE;
	calcs[slot].cpu.prefix		= 0;
	return 0;
}

int calc_run_frame(int slot) {
	CPU_t *cpu = &calcs[slot].cpu;
	double cpu_sync = cpu->timer_c->elapsed;
	
	while(calcs[gslot].running) {
		if (calcs[slot].breakpoints[cpu->pc]) {
			calcs[slot].running = FALSE;
			SendMessage(calcs[slot].hwndLCD, WM_COMMAND, IDM_DEBUG, 0);
			return 0;
		}
	
		CPU_step(cpu);
	
		/* sync CPU */
		if (cpu->timer_c->elapsed - cpu_sync > (1.0f / FPS)) {
			if (!calcs[slot].warp) return 0;
			if (cpu->timer_c->elapsed - cpu_sync > (8.0f / FPS)) return 0;
		}
	}
}



int calc_run_timed(int slot, time_t time) {
	int frames = time/TPF;
	
	BOOL warp_backup = calcs[slot].warp;

	calcs[slot].warp = TRUE;
	while (frames--) calc_run_frame(slot);
	calcs[slot].warp = warp_backup;
	return 0;
}
