#include <string.h>
#include "guilcd.h"
#include "calc.h"
#include "sendfiles.h"
#include "sound.h"
#include "gif.h"
#include "guioptions.h"
#include "link.h"
#include "rsrc.h"

#include "guicontext.h"

extern POINT drop_pt;
extern BOOL do_drag;
extern RECT db_rect;
extern HINSTANCE g_hInst;
extern HDC hdcSkin;


BITMAPINFO *bi;


HDC DrawSending(HWND hwnd, HDC hdcDest) {
	TCHAR Sendstr1[] = "Sending File(s)";
	TCHAR Filecntstr[64];

	static HBITMAP bmpSend = NULL;
	RECT clientRect;
	GetClientRect(hwnd, &clientRect);
	
	// Create the device context that holds the overlay
	HDC hdc = CreateCompatibleDC(hdcDest);
	
	if (bmpSend != NULL) DeleteObject(bmpSend);
	bmpSend = 
	CreateCompatibleBitmap(hdcDest, clientRect.right, clientRect.bottom);
	
	SelectObject(hdc, bmpSend);
	
	SetBkMode(hdc, TRANSPARENT);
	SetTextColor(hdc, RGB(0x00,0x00,0x00));
	

	HBRUSH hbrSend = CreateSolidBrush(SEND_COLOR);
	FillRect(hdc, &clientRect, hbrSend);


	sprintf(Filecntstr,"%03d of %03d\0",calcs[gslot].CurrentFile,calcs[gslot].FileCnt);

	int x = (((clientRect.right-clientRect.left)-96)/2);
	int y = (((clientRect.bottom-clientRect.top)*15)/100);

	TextOut(hdc, x, y, Sendstr1, strlen(Sendstr1));
	
	x = (((clientRect.right-clientRect.left)-66)/2);
	y = (((clientRect.bottom-clientRect.top)*40)/100);
	
	TextOut(hdc, x, y, Filecntstr, strlen(Filecntstr));
	
	
	RECT ProgLine;
	RECT ProgFill;
	
	ProgLine.left	= clientRect.left+10;
	ProgLine.top	= (((clientRect.bottom-clientRect.top)*60)/100);
	ProgLine.bottom	= ProgLine.top+15;
	ProgLine.right	= clientRect.right-10;
	
	float progress;
	
	if (calcs[gslot].SendSize) {
		progress = ((float)calcs[gslot].BytesSent)/((float)calcs[gslot].SendSize);
	} else {
		progress = 0;
	}
		
	ProgFill.left	= ProgLine.left+1;
	ProgFill.top	= ProgLine.top+1;
	ProgFill.bottom	= ProgLine.bottom;
	ProgFill.right	= ((ProgLine.right-ProgLine.left)*progress)+ProgLine.left;

	SelectObject(hdc, GetStockObject(BLACK_PEN));

	Rectangle(hdc,ProgLine.left,ProgLine.top,ProgLine.right+1,ProgLine.bottom+1);

	FillRect(hdc,&ProgFill,GetStockObject(BLACK_BRUSH));

	DeleteObject(hbrSend);
	
	return hdc;
}


HDC DrawDragPanes(HWND hwnd, HDC hdcDest, int mode) {
	RECT rl, rr, clientRect;
	GetClientRect(hwnd, &clientRect);
	SIZE TxtSize;
	POINT TxtPt;
	
	CopyRect(&rl, &clientRect);
	CopyRect(&rr, &clientRect);
	
	if (calcs[gslot].model >= TI_83P) {
		rl.right = rr.left = rr.right/2;
	}
	
	// Create the device context that holds the overlay
	HDC hdc = CreateCompatibleDC(hdcDest);
	HBITMAP bmpDragPane = 
	CreateCompatibleBitmap(hdcDest, clientRect.right, clientRect.bottom);
	
	SelectObject(hdc, bmpDragPane);
	
	SetBkMode(hdc, TRANSPARENT);
	SetTextColor(hdc, RGB(0xFF,0xFF,0xFF));
	HBRUSH hbrRAM = CreateSolidBrush(RAM_COLOR);
	HBRUSH hbrArchive = CreateSolidBrush(ARCHIVE_COLOR);
	
	if (!hbrRAM || !hbrArchive) {
		printf("Brush creation failed\n");
		return hdc;
	}
	
	POINT pt = drop_pt;
	ScreenToClient(hwnd, &pt);
	
	TRIVERTEX vert[4];
	GRADIENT_RECT gRect[2];

	if (calcs[gslot].model >= TI_83P) {
			
		FillRect(hdc, &rr, hbrArchive); 
		
		if (PtInRect(&rr, pt)) {
			gRect[0].UpperLeft  = 0;
			gRect[0].LowerRight = 1;
			gRect[1].UpperLeft  = 2;
			gRect[1].LowerRight = 3;		
			vert[0].x      = rr.left;
			vert[0].y      = rr.top;
			vert[0].Red    = 0x7000;
			vert[0].Green  = 0x2000;
			vert[0].Blue   = 0x3000;
			vert[1].x      = rr.left + rl.right/3;
			vert[1].y      = rr.bottom;
			vert[1].Red    = 0xC000;
			vert[1].Green  = 0x4000;
			vert[1].Blue   = 0x6000;
			
			GradientFill(hdc,vert,2,gRect,1,GRADIENT_FILL_RECT_H);
			
			//0x60, 0xC0, 0x40
			vert[2].x      = rr.left + 2*rl.right/3;
			vert[2].y      = rr.bottom;
			vert[2].Red    = 0xC000;
			vert[2].Green  = 0x4000;
			vert[2].Blue   = 0x6000;
			vert[3].x      = rr.right;
			vert[3].y      = rr.top;
			vert[3].Red    = 0x7000;
			vert[3].Green  = 0x2000;
			vert[3].Blue   = 0x3000;		
			GradientFill(hdc,&vert[2],2,&gRect[0],1,GRADIENT_FILL_RECT_H);
		}
		
		TCHAR txtArch[]="Archive";
		if ( GetTextExtentPoint32(hdc,txtArch,strlen(txtArch),&TxtSize) ) {
			TxtPt.x = ((rr.right - rr.left)-TxtSize.cx)/2;
			TxtPt.y = ((rr.bottom - rr.top)-TxtSize.cy)/2;
			if ( TxtPt.x < 0 ) TxtPt.x =0;
			if ( TxtPt.y < 0 ) TxtPt.y =0;
		} else {
			TxtPt.x = rr.left+5;
			TxtPt.y = rr.top+52;
		}
		TextOut(hdc, TxtPt.x+rr.left, TxtPt.y, txtArch, strlen(txtArch));
	}
	
	FillRect(hdc, &rl, hbrRAM);
	
	if (PtInRect(&rl, pt)) {
		gRect[0].UpperLeft  = 0;
		gRect[0].LowerRight = 1;
		gRect[1].UpperLeft  = 2;
		gRect[1].LowerRight = 3;		
		vert[0].x      = rl.left;
		vert[0].y      = rl.top;
		vert[0].Red    = 0x3000;
		vert[0].Green  = 0x7000;
		vert[0].Blue   = 0x2000;
		vert[1].x      = rl.right/3;
		vert[1].y      = rl.bottom;
		vert[1].Red    = 0x6000;
		vert[1].Green  = 0xC000;
		vert[1].Blue   = 0x4000;
		
		GradientFill(hdc,vert,2,gRect,1,GRADIENT_FILL_RECT_H);
		//0x60, 0xC0, 0x40
		vert[2].x      = 2*rl.right/3;
		vert[2].y      = rl.bottom;
		vert[2].Red    = 0x6000;
		vert[2].Green  = 0xC000;
		vert[2].Blue   = 0x4000;
		vert[3].x      = rl.right;
		vert[3].y      = rl.top;
		vert[3].Red    = 0x3000;
		vert[3].Green  = 0x7000;
		vert[3].Blue   = 0x2000;		
		
		GradientFill(hdc,&vert[2],2,&gRect[0],1,GRADIENT_FILL_RECT_H);
	}
	
	TCHAR txtRam[] ="RAM";
	if ( GetTextExtentPoint32(hdc,txtRam,strlen(txtRam),&TxtSize) ) {
		TxtPt.x = ((rl.right - rl.left)-TxtSize.cx)/2;
		TxtPt.y = ((rl.bottom - rl.top)-TxtSize.cy)/2;
		if ( TxtPt.x < 0 ) TxtPt.x =0;
		if ( TxtPt.y < 0 ) TxtPt.y =0;
	} else {
		TxtPt.x = rl.left+5;
		TxtPt.y = rl.top+52;
	}
	TextOut(hdc, TxtPt.x, TxtPt.y, txtRam, strlen(txtRam));

	DeleteObject(hbrRAM);
	DeleteObject(hbrArchive);
	
	return hdc;
}

void PaintLCD(HWND hwnd, HDC hdcDest) {
	unsigned char * screen;
	LCD_t *lcd = (&calcs[gslot].cpu)->pio.devices[0x11].aux;
	RECT rc;
	GetClientRect(hwnd, &rc);
	
	HDC hdcOverlay, hdc = CreateCompatibleDC(hdcDest);
	HBITMAP bmpBuf;
	if (hdc == NULL) {
		printf("Creating buffer DC failed\n");
		return;
	} else {
		bmpBuf = CreateCompatibleBitmap(hdcDest, rc.right, rc.bottom);
		if (bmpBuf == NULL) printf("Creating bitmap failed\n");
		SelectObject(hdc, bmpBuf);
	}
	
	if (lcd->active == FALSE) {
		int i;
		BYTE lcd_data[128*64];
		for (i = 0; i < 128*64; i++) lcd_data[i]=0x00; //whitest pixel

		if (StretchDIBits(
			hdc,
			rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top,
			0, 0, 96, 64,
			lcd_data,
			bi,
			DIB_RGB_COLORS,
			SRCCOPY) == 0) {
			
			printf("error in SetDIBitsToDevice\n");
		}
		
		
		if (do_drag == TRUE) {

			hdcOverlay = DrawDragPanes(hwnd, hdcDest, 0);
			BLENDFUNCTION bf;
			bf.BlendOp = AC_SRC_OVER;
			bf.BlendFlags = 0;
			bf.SourceConstantAlpha = 160;
			bf.AlphaFormat = 0;		
			if (AlphaBlend(	hdc, 0, 0, rc.right, rc.bottom,
						hdcOverlay, 0, 0, rc.right, rc.bottom,
						bf ) == FALSE) printf("alpha blend 1 failed\n");
						
			DeleteDC(hdcOverlay);

		}
		

		if (BitBlt(	hdcDest, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top,
			hdc, 0, 0, SRCCOPY ) == FALSE) printf("Bit blt failed\n");
		
	} else {
		screen = LevelLCD( &calcs[gslot].cpu ) ;		
		if (StretchDIBits(
			hdc,
			rc.left, rc.top, rc.right - rc.left,  rc.bottom - rc.top,
			0, 0, 96, 64,
			screen,
			bi,
			DIB_RGB_COLORS,
			SRCCOPY) == 0) {
			
			printf("error in SetDIBitsToDevice\n");
		}

		BLENDFUNCTION bf;
		bf.BlendOp = AC_SRC_OVER;
		bf.BlendFlags = 0;
		bf.SourceConstantAlpha = 160;
		bf.AlphaFormat = 0;		
		
		if (do_drag == TRUE) {

			hdcOverlay = DrawDragPanes(hwnd, hdcDest, 0);
	
			if (AlphaBlend(	hdc, 0, 0, rc.right, rc.bottom,
						hdcOverlay, 0, 0, rc.right, rc.bottom,
						bf ) == FALSE) printf("alpha blend 1 failed\n");
						
			DeleteDC(hdcOverlay);

		}


		if (calcs[gslot].send == TRUE) {
			bf.SourceConstantAlpha = 192;
			hdcOverlay = DrawSending(hwnd, hdcDest);
	
			if (AlphaBlend(	hdc, 0, 0, rc.right, rc.bottom,
						hdcOverlay, 0, 0, rc.right, rc.bottom,
						bf ) == FALSE) printf("alpha blend send failed\n");
						
			DeleteDC(hdcOverlay);
		}

		bf.SourceConstantAlpha = 108;

		POINT pt;
		pt.x = rc.left;
		pt.y = rc.top;
		ClientToScreen(hwnd, &pt);
		ScreenToClient(GetParent(hwnd), &pt);
		if (AlphaBlend(	hdc, rc.left, rc.top, rc.right,  rc.bottom,
					hdcSkin, pt.x, pt.y, rc.right, rc.bottom,
					bf )  == FALSE) printf("alpha blend 2 failed\n");
	
		if (BitBlt(	hdcDest, rc.left, rc.top, rc.right - rc.left,  rc.bottom - rc.top,
			hdc, 0, 0, SRCCOPY ) == FALSE) printf("Bit blt failed\n");	
			
		
	}
	DeleteObject(bmpBuf);
	DeleteDC(hdc);	
}

typedef struct tag_OFNHookOptions {
	BOOL bArchive;
	BOOL bFileSettings;
} OFNHookOptions;


UINT_PTR CALLBACK OFNHookProc(HWND hwndDlg, UINT Message, WPARAM wParam, LPARAM lParam) {
	static OFNHookOptions *HookOptions;
	static HWND rbnRAM, rbnArchive, rbnFileSettings;
	static int nIDDefault = IDC_RBNFILESETTINGS;
	static BITMAPINFO *biIcon;
	static BYTE lpBits[15*4];
	switch (Message) {
		case WM_INITDIALOG:
			HookOptions = (OFNHookOptions*) ((OPENFILENAME*) lParam)->lCustData;
			rbnRAM = GetDlgItem(hwndDlg, IDC_RBNFILERAM);
			rbnArchive = GetDlgItem(hwndDlg, IDC_RBNFILEARCHIVE);
			rbnFileSettings = GetDlgItem(hwndDlg, IDC_RBNFILESETTINGS);
			
			CheckRadioButton(hwndDlg, IDC_RBNFILERAM, IDC_RBNFILESETTINGS, nIDDefault);

			biIcon = malloc(sizeof(BITMAPINFOHEADER) + 2*sizeof(RGBQUAD));
			
			
			biIcon->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
			biIcon->bmiHeader.biWidth = 32;
			biIcon->bmiHeader.biHeight = -15;
			biIcon->bmiHeader.biPlanes = 1;
			biIcon->bmiHeader.biBitCount = 1;
			biIcon->bmiHeader.biCompression = BI_RGB;
			biIcon->bmiHeader.biSizeImage = 0;
			biIcon->bmiHeader.biXPelsPerMeter = 0;
			biIcon->bmiHeader.biYPelsPerMeter = 0;
			biIcon->bmiHeader.biClrUsed = 2;
			biIcon->bmiHeader.biClrImportant = 2;
			
			biIcon->bmiColors[1].rgbRed = 0;
			biIcon->bmiColors[1].rgbGreen = 0;
			biIcon->bmiColors[1].rgbBlue = 0;
			biIcon->bmiColors[0].rgbRed = 0xFF;
			biIcon->bmiColors[0].rgbGreen = 0xFF;
			biIcon->bmiColors[0].rgbBlue = 0xFF;
			
			ZeroMemory(lpBits, 30);
			break;
		case WM_PAINT: {
			HDC hdc;
			PAINTSTRUCT ps;
			
			hdc = BeginPaint(hwndDlg, &ps);
			
			//HWND stcIcon = GetDlgItem(hwndDlg, IDC_STCOFNICON);
			RECT r;
			//GetWindowRect(stcIcon, &r);
			POINT p = {r.left, r.top};
			
			ScreenToClient(GetParent(hwndDlg), &p);

			/*StretchDIBits(hdc, p.x-40, p.y+20, 30, 30,
				0, 0, 15, 15,
				lpBits,
				biIcon,
				DIB_RGB_COLORS,
				SRCCOPY);*/

			EndPaint(hwndDlg, &ps);
			break;
		}
		case WM_NOTIFY: {
			switch (((OFNOTIFY*) lParam)->hdr.code) {
				case CDN_SELCHANGE: {
					TCHAR szPath[MAX_PATH];
					SendMessage(GetParent(hwndDlg), CDM_GETFILEPATH,
									MAX_PATH, (LPARAM) szPath);
					FILE *prgFile = fopen(szPath, "r");
					if (!prgFile) break;
					printf("got the file open\n");
					fseek(prgFile, 0x4A, SEEK_SET);
					if (fgetc(prgFile) == 0xBB &&
						fgetc(prgFile) == 0x6D &&
						fgetc(prgFile) == 0xC9 &&
						fgetc(prgFile) == 0x01) {
						
						int i;
						for (i = 0; i < 15; i++) {
							int j;
							for (j = 0; j < 4; j++) {
								if (j < 2) lpBits[i*4 + j] = fgetc(prgFile);
							}
						}

						char szName[256];
						fgets(szName, 256, prgFile);
						printf("got a mirage program %s\n", szName);
						InvalidateRect(hwndDlg, NULL, FALSE);
						
					}
					fclose(prgFile);
					
					break;
				}
				case CDN_FILEOK:
					/* Set the options once a file is selected */
					if (IsDlgButtonChecked(hwndDlg, IDC_RBNFILERAM) == BST_CHECKED) {
						HookOptions->bArchive = FALSE;
						HookOptions->bFileSettings = FALSE;
						nIDDefault = IDC_RBNFILERAM;
					} else
					if (IsDlgButtonChecked(hwndDlg, IDC_RBNFILEARCHIVE) == BST_CHECKED) {
						HookOptions->bArchive = TRUE;
						HookOptions->bFileSettings = FALSE;
						nIDDefault = IDC_RBNFILEARCHIVE;
					} else {
						HookOptions->bFileSettings = TRUE;
						nIDDefault = IDC_RBNFILESETTINGS;
					}
					break;
			}
			break;
		}
	}
	return 0;	
}


void SendVarDialog(HWND hwnd) {
	OPENFILENAME ofn;
	int result;
	char lpstrFilter[] 	= "\
Known File Types\0*.73p;*.82*;*.83p*;*.8xp*;*.8xk;*.73k;*.sav;*.rom;*.lab\0\
Calculator Program Files  (*.73p;*.82*;*.83p*;*.8xp*)\0*.73p;*.82*;*.83p*;*.8xp*\0\
Calculator Applications  (*.8xk, *.73k)\0*.8xk;*.73k\0\
Save States  (*.sav)\0*.sav\0\
ROMS  (*.rom)\0*.rom\0\
Label Files (*.lab)\0*.lab\0\
All Files (*.*)\0*.*\0\0";
	char filepath[MAX_PATH+256];
	char filestr[MAX_PATH+256];
	char * FileNames = NULL;
	char * filename;
	char * filestroffset;
	
	static OFNHookOptions HookOptions;
	
	ZeroMemory(filepath, sizeof(filepath));
	ZeroMemory(filestr, sizeof(filepath));

	ofn.lStructSize			= sizeof(OPENFILENAME);
	ofn.hwndOwner			= calcs[gslot].hwndLCD;
	ofn.hInstance			= g_hInst;
	ofn.lpstrFilter			= (LPCTSTR) lpstrFilter;
	ofn.lpstrCustomFilter	= NULL;
	ofn.nMaxCustFilter		= 0;
	ofn.nFilterIndex		= 0;
	ofn.lpstrFile			= filepath;
	ofn.nMaxFile			= sizeof(filepath);
	ofn.lpstrFileTitle		= NULL;
	ofn.nMaxFileTitle		= 0;
	ofn.lpstrInitialDir		= NULL;
	ofn.lpstrFileTitle		= NULL;
	ofn.nMaxFileTitle		= 0;
	ofn.lpstrInitialDir		= NULL;
	ofn.lpstrTitle			= "Wabbitemu Open File";
	ofn.Flags				= 
		OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_EXPLORER | 
		OFN_ALLOWMULTISELECT | OFN_ENABLEHOOK | OFN_ENABLETEMPLATE | OFN_HIDEREADONLY;
	ofn.lpstrDefExt			= NULL;
	ofn.lCustData			= (LPARAM) &HookOptions;
	ofn.lpfnHook			= OFNHookProc;
	ofn.lpTemplateName		= MAKEINTRESOURCE(IDD_OFN);
	ofn.FlagsEx				= 0;

	result = GetOpenFileName(&ofn);
	
	if (!result) return;
	
	memcpy(filestr,filepath,ofn.nFileOffset);
	
	for (filestroffset= filestr;filestroffset[0]!=0;filestroffset++);
	filestroffset[0] = '\\';
	filestroffset++;		/* DOUBLE CHECK THIS */
	filename = filepath+ofn.nFileOffset;

	while(filename[0] != 0) {
		int len;
		strcpy(filestroffset,filename);
		len = strlen(filestroffset);
		filestroffset[len] = 0;
		filename +=(len+1);
		FileNames = AppendName( FileNames,filestr);
	}
	
	int send_mode = SEND_CUR;
	if (!HookOptions.bFileSettings) {
		send_mode = SEND_RAM;
		if (HookOptions.bArchive) send_mode = SEND_ARC;
	}
	
	ThreadSend(FileNames, send_mode);
}

void SaveStateDialog(HWND hwnd){
	OPENFILENAME ofn;
	char FileName[MAX_PATH];
	char lpstrFilter[] 	= "\
Known File types ( *.sav; *.rom; *.bin) \0*.sav;*.rom;*.bin\0\
Save States  (*.sav)\0*.sav\0\
ROMS  (*.rom; .bin)\0*.rom;*.bin\0\
All Files (*.*)\0*.*\0\0";

	ZeroMemory(&ofn, sizeof(ofn));
	ZeroMemory(FileName, MAX_PATH);

	ofn.lStructSize		= sizeof(OPENFILENAME);
	ofn.hwndOwner		= calcs[gslot].hwndLCD;
	ofn.lpstrFilter		= (LPCTSTR) lpstrFilter;
	ofn.lpstrFile		= FileName;
	ofn.nMaxFile		= MAX_PATH;
	ofn.lpstrTitle		= "Wabbitemu Save State";
	ofn.Flags			= OFN_PATHMUSTEXIST | OFN_EXPLORER | 
						  OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY;
	ofn.lpstrDefExt			= "sav";
	if (!GetSaveFileName(&ofn)) return;
	
	BOOL Running_Backup = calcs[gslot].running;
	calcs[gslot].running = FALSE;
	SAVESTATE_t* save = SaveSlot(gslot);
	WriteSave(FileName,save,ZLIB_CMP);
	FreeSave(save);
	strcpy(calcs[gslot].rom_path,FileName);
	calcs[gslot].running =  Running_Backup;

}

void LoadStateDialog(HWND hwnd){
	OPENFILENAME ofn;
	char FileName[MAX_PATH];
	char lpstrFilter[] 	= "\
Known File types ( *.sav; *.rom; *.bin) \0*.sav;*.rom;*.bin\0\
Save States  (*.sav)\0*.sav\0\
ROMS  (*.rom; .bin)\0*.rom;*.bin\0\
All Files (*.*)\0*.*\0\0";

	ZeroMemory(&ofn, sizeof(ofn));
	ZeroMemory(FileName, MAX_PATH);

	ofn.lStructSize		= sizeof(OPENFILENAME);
	ofn.hwndOwner		= calcs[gslot].hwndLCD;
	ofn.lpstrFilter		= (LPCTSTR) lpstrFilter;
	ofn.lpstrFile		= FileName;
	ofn.nMaxFile		= MAX_PATH;
	ofn.lpstrTitle		= "Wabbitemu Load State";
	ofn.Flags			= OFN_PATHMUSTEXIST | OFN_EXPLORER |
						  OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;
	ofn.lpstrDefExt			= "sav";
	if (!GetOpenFileName(&ofn)) return;
	printf("%s \n",FileName);
	BOOL Running_Backup = calcs[gslot].running;
	calcs[gslot].running = FALSE;
	rom_load(gslot,FileName);
	calcs[gslot].running =  Running_Backup;

}



LRESULT CALLBACK LCDProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	static HWND hStatusBar;
	static IDropTarget *pDropTarget;

    switch (Message) {
		case WM_CREATE:
		{
			HDC hdc = GetDC(hwnd);
    		
			SetBkMode(hdc, TRANSPARENT);
            RegisterDropWindow(hwnd, &pDropTarget);
			bi = malloc(sizeof(BITMAPINFOHEADER) + (MAX_SHADES+1)*sizeof(RGBQUAD));
			bi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
			bi->bmiHeader.biWidth = 128;
			bi->bmiHeader.biHeight = -64;
			bi->bmiHeader.biPlanes = 1;
			bi->bmiHeader.biBitCount = 8;
			bi->bmiHeader.biCompression = BI_RGB;
			bi->bmiHeader.biSizeImage = 0;
			bi->bmiHeader.biXPelsPerMeter = 0;
			bi->bmiHeader.biYPelsPerMeter = 0;
			bi->bmiHeader.biClrUsed = MAX_SHADES+1;
			bi->bmiHeader.biClrImportant = MAX_SHADES+1;
			
			//#define LCD_LOW (RGB(0x9E, 0xAB, 0x88))			
			int i;
			#define LCD_HIGH	255
			for (i = 0; i <= MAX_SHADES; i++) {
				bi->bmiColors[i].rgbRed = (0x9E*(256-(LCD_HIGH/MAX_SHADES)*i))/255;
				bi->bmiColors[i].rgbGreen = (0xAB*(256-(LCD_HIGH/MAX_SHADES)*i))/255;
				bi->bmiColors[i].rgbBlue = (0x88*(256-(LCD_HIGH/MAX_SHADES)*i))/255;				
			}	
			
			
			UpdateWindow(hwnd);
			return 0;
		}
		case WM_PAINT:
		{
			HDC hdcDest;
			LCD_t *lcd = (&calcs[gslot].cpu)->pio.devices[17].aux;
			PAINTSTRUCT ps;
			
			hdcDest = BeginPaint(hwnd, &ps);
			PaintLCD(hwnd, hdcDest);
			EndPaint(hwnd, &ps);
			
			static time_t sb_refresh;
			if (clock() > sb_refresh + 500) {
				char sz_status[16];
				if (lcd->active)
					sprintf(sz_status,"FPS: %d",lcd->ufps);
				else
					sprintf(sz_status,"FPS: -");
				//SendMessage(hStatusBar, SB_SETTEXT, 0, (LPARAM) sz_status);
				sb_refresh = clock();
			}
			return 0;
		}
		case WM_SIZE:
		{
			//SendMessage(hStatusBar, WM_SIZE, 0, 0);
			InvalidateRect(hwnd, NULL, TRUE);
			return 0;
		}
		case WM_CONTEXTMENU:
		{
			HMENU hmenu = LoadMenu(g_hInst, MAKEINTRESOURCE(IDR_LCD_MENU)); 
		    // TrackPopupMenu cannot display the menu bar so get 
		    // a handle to the first shortcut menu. 
			hmenu = GetSubMenu(hmenu, 0); 

		  	UINT check;
		 	if (calcs[gslot].audio->enabled) {
				check = MF_BYCOMMAND |  MF_CHECKED;
			} else {
				check = MF_BYCOMMAND |  MF_UNCHECKED;
			}
		  	int result = CheckMenuItem(hmenu,TOGGLE_SOUND,check);
		  	
		  	char szCap[64];
		  	if (gif_write_state == GIF_IDLE) {
				strcpy(szCap,"Start GIF Capture");
			} else {
				strcpy(szCap,"Stop GIF Capture");
			}
		  	ModifyMenu(hmenu,TOGGLE_GIF,MF_BYCOMMAND | MF_STRING,TOGGLE_GIF,szCap);
  	
			if (!OnContextMenu(hwnd, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam), hmenu)) {
				DefWindowProc(hwnd, Message, wParam, lParam);
			}
			
			DestroyMenu(hmenu); 
			return 0;
		}
		case WM_COMMAND:
		{
			UpdateWindow(hwnd);
			switch (LOWORD(wParam)) {
				case IDM_DEBUG:
				{	
					pausesound();
					HWND hdebug;
					RECT pos = {CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT+600, CW_USEDEFAULT+400};
					if (db_rect.left != -1) CopyRect(&pos, &db_rect);
						
					pos.right -= pos.left;
					pos.bottom -= pos.top;
					
					if (FindWindow(g_szDebugName, "Debugger")) break;
					calcs[gslot].running = FALSE;
					hdebug = CreateWindowEx(
						WS_EX_APPWINDOW,
						g_szDebugName,
				        "Debugger", 
						WS_VISIBLE | WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
				        pos.left, pos.top, pos.right, pos.bottom,
				        0, 0, g_hInst, NULL);
				       
					break;
				}
				case IDM_COPY:
				{
					HLOCAL ans;
					ans = GetRealAns(gslot);
					OpenClipboard(hwnd);
					EmptyClipboard();
					SetClipboardData(CF_TEXT, ans);
					
					calcs[gslot].lpKeyState[VK_CONTROL] = 0;
					CloseClipboard();
					break;
				}
				case DB_RUN:
					SendMessage(FindWindow(g_szDebugName, "Debugger"), WM_CLOSE, 0, 0);
					break;
				case LOAD_STATE_DIALOG:
					LoadStateDialog(hwnd);
					break;
				case SAVE_STATE_DIALOG:
					SaveStateDialog(hwnd);
					break;
				case SEND_VAR_DIALOG:
					SendVarDialog(hwnd);
					break;
				case TOGGLE_SOUND:
					togglesound();
					break;
				case ECM_CALCRESET:
					calc_reset(gslot);
					calcs[gslot].cpu.pio.keypad->on_pressed |= KEY_FALSEPRESS;
					calc_run_timed(gslot, 300);
					calcs[gslot].cpu.pio.keypad->on_pressed &= ~KEY_FALSEPRESS;
					break;
				case ECM_CALCRELOAD:
					rom_load(gslot,calcs[gslot].rom_path);
					break;
				case TOGGLE_GIF:
					if (gif_write_state == GIF_IDLE) {
						if ( (gif_colors != 7) && (gif_colors != 2) ) {
							gif_colors = 7;
						}
						gif_write_state = GIF_START;
					} else if (gif_write_state == GIF_FRAME) {
						gif_write_state = GIF_END;
					}
					break;
				case IDM_PREFERENCES:
					DoPropertySheet(NULL);
					break;
				case IDM_EXITSAVE:
				{
					calcs[gslot].running = FALSE;
					TIFILE_t* tifile = importvar(calcs[gslot].rom_path);
					if (tifile) {
						SAVESTATE_t* save;
						switch(tifile->type) {
							case SAV_TYPE:
								FreeTiFile(tifile);
								save = SaveSlot(gslot);
								WriteSave(calcs[gslot].rom_path,save,ZLIB_CMP);
								FreeSave(save);
								break;
							case ROM_TYPE:
							{
								int length = strlen(calcs[gslot].rom_path);
								FreeTiFile(tifile);
								strcpy(calcs[gslot].rom_path+length,".sav");
								save = SaveSlot(gslot);
								WriteSave(calcs[gslot].rom_path,save,ZLIB_CMP);
								FreeSave(save);
								break;
							}
						}
					}
					goto window_exit;
				}
				case IDM_EXIT:
					goto window_exit;
				case LCD_ABOUT:
					ShellExecute(NULL, "open", g_szWebPage,
					    NULL, NULL, SW_SHOWNORMAL);
					break;
				default:
					SendMessage(GetParent(hwnd), Message, wParam, lParam);
			}
			return 0;
		}
		case WM_COPYDATA:
		{
			int size = (int)((PCOPYDATASTRUCT)lParam)->cbData;
			char* string = (char*)((PCOPYDATASTRUCT)lParam)->lpData;
			int ram = (int)((PCOPYDATASTRUCT)lParam)->dwData;
			
			printf("Size of = %d == %d \n",size,SizeofFileList(string));
			if (size && string && size==SizeofFileList(string))	{
				char* FileNames = malloc(size);
				memset(FileNames,0,size);
				memcpy(FileNames,string,size);
				ThreadSend(FileNames,ram);
			}
		}
		break;
		case WM_DROPFILES:
		{
			RECT lr, rr;
			POINT p;
			int ram = 0;
			char * FileNames = NULL;
			char fn[256];
			int count;
			
			GetClientRect(hwnd, &lr);
			CopyRect(&rr, &lr);
			lr.right /= 2;			//left half 
			rr.left = lr.right;		//right half
			p = drop_pt;			//DragQueryPoint((HDROP) wParam, &p);
		//	printf("p %d,%d\n",p.x,p.y);
			SwitchToThisWindow(calcs[gslot].hwndFrame, TRUE);
			
			ScreenToClient(hwnd, (LPPOINT) &p); 

			if (PtInRect(&rr, p)) ram = SEND_ARC;
			else if (PtInRect(&lr, p)) ram = SEND_RAM;
			else ram = SEND_CUR;

			count = DragQueryFile((HDROP) wParam, ~0, fn, 256);

			while (count--) {
				DragQueryFile((HDROP) wParam, count, fn, 256);
				FileNames = AppendName( FileNames,fn);
			}
			ThreadSend(FileNames,ram);
			DragFinish((HDROP) wParam);
			return 0;
		}
		case WM_KEYDOWN:
		case WM_KEYUP:
			SendMessage(GetParent(hwnd), Message, wParam, lParam);
			return 0;
		window_exit:
		case WM_DESTROY:
		case WM_CLOSE:
			//UnregisterDropWindow(hwnd, pDropTarget);
			
			DestroyWindow(hwnd);
			PostQuitMessage(0);
			return 0;
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
}

