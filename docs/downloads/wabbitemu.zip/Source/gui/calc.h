#ifndef CALC_H
#define CALC_H

#include "gui.h"
#include "core.h"
#include "lcd.h"
#include "keys.h"
#include "sound.h"
#include "savestate.h"
#include "label.h"
#include "link.h"


#define freenz( mem_pnt )  if ((mem_pnt)) free((mem_pnt));

#ifdef CALC_C
char CalcModelTxt[][32] = {
	"???",
	"TI-82",
	"TI-83",
	"TI-85",
	"TI-86",
	"TI-73",
	"TI-83+",
	"TI-83+ SE",
	"TI-84+",
	"TI-84+ SE",
	"???"
};
#else
extern char CalcModelTxt[][32];
#endif

typedef struct calc {
	
	char rom_path[256];
	char rom_version[32];
	int model;
	
	BOOL active;
	CPU_t cpu;
	memory_context_t mem_c;
	timer_context_t time_c;
	AUDIO_t* audio;
	HWND hwndFrame;
	HWND hwndLCD;
	HDC	hdcSkin;		//backup of the skin
	BOOL bCutout;
	HBITMAP hbmSkin;
	BOOL running;
	BYTE breakpoints[0x10000];
	BOOL warp;

	BYTE lpKeyState[256];
	
	APPLIST_t applist;

	labels_t labels;
	
	char labelfn[256];

	volatile BOOL send;
	volatile int CurrentFile;
	volatile int FileCnt;
	volatile int BytesSent;
	volatile int SendSize;

} calc_t;


#define MAX_CALCS	8

#define TI_82		1
#define TI_83		2
#define TI_85		3
#define TI_86		4
#define TI_73		5
#define TI_83P		6
#define TI_83PSE	7
#define TI_84P		8
#define TI_84PSE	9

/*defines the start of the app page*/
/*this page starts in HIGH mem and grows to LOW */
#define TI_73_APPPAGE		0x15	/*Ummm...*/
#define TI_83P_APPPAGE		0x15
#define TI_83PSE_APPPAGE	0x69
#define TI_84P_APPPAGE		0x29	/*Ummm...*/
#define TI_84PSE_APPPAGE	0x69


/*defines the Number of user archive pages*/
#define TI_73_USERPAGES		0x0A	/*Ummm...*/
#define TI_83P_USERPAGES	0x0A
#define TI_83PSE_USERPAGES	0x60
#define TI_84P_USERPAGES	0x1E	/*Ummm...*/
#define TI_84PSE_USERPAGES	0x60


void ClearDevices(CPU_t* );
int calc_new(void);
int calc_init_83(int,char*);
int calc_init_83p(int);
int calc_reset(int);
int calc_run_frame(int);
int calc_run_timed(int, time_t);
int romfile_load(int , char * );
int rom_load(int , char * );
void calc_free(int );

#endif

#ifdef CALC_C
#define GLOBAL
#else
#define GLOBAL extern
#endif


GLOBAL calc_t calcs[MAX_CALCS];
GLOBAL int gslot;



