#include "gui.h"
#include <commctrl.h>
#include <stddef.h>

#include "core.h"
#include "calc.h"

#include "gifhandle.h"
#include "gif.h"

#include "rsrc.h"
#include "var.h"
#include "link.h"

#include "guidebug.h"
#include "guioptions.h"
#include "guicontext.h"
#include "guibuttons.h"
#include "guilcd.h"

#include "dbmem.h"
#include "dbreg.h"
#include "dbdisasm.h"

#include "sendfiles.h"

char ExeDir[512];




HINSTANCE g_hInst;
HACCEL haccelmain;
HACCEL hacceldebug;
BOOL do_drag;
POINT drop_pt;

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

void RegisterDropWindow(HWND hwnd,   IDropTarget **ppDropTarget);
void UnregisterDropWindow(HWND hwnd, IDropTarget *pDropTarget);


VOID CALLBACK TimerProc(HWND hwnd, UINT Message, UINT_PTR idEvent, DWORD dwTimer) {
	static long difference[MAX_CALCS];
	static DWORD prevTimer[MAX_CALCS];
	static int frameskip = 0;

	
	if (calcs[idEvent].running && calcs[idEvent].send != TRUE) {
		// How different the timer is from where it should be
		// guard from erroneous timer calls with an upper bound
		// that's the limit of time it will take before the
		// calc gives up and claims it lost time
		difference[idEvent] += ((dwTimer - prevTimer[idEvent]) & 0x003F) - TPF;
		
		// Are we greater than Ticks Per Frame that would call for
		// a frame skip?
		if (difference[idEvent] > -TPF) {
			calc_run_frame(idEvent);
			while (difference[idEvent] >= TPF) {
				calc_run_frame(idEvent);
				difference[idEvent] -= TPF;
			}
			// redraw main display (timer's owner)
			InvalidateRect(hwnd, NULL, FALSE);
			UpdateWindow(hwnd);
		// Frame skip if we're too far ahead.
		} else difference[idEvent] += TPF;


	} else if (calcs[idEvent].send == TRUE) {
		if (frameskip == 0) {
			InvalidateRect(hwnd, NULL, FALSE);
			UpdateWindow(hwnd);
		}
		frameskip = (frameskip+1)%3;
	}


	prevTimer[idEvent] = dwTimer;
	
	PostMessage(calcs[idEvent].hwndFrame, WM_COMMAND, UPDATE_TITLE_BAR, 0);
}


int calc_create_frame(int slot) {
 	RECT r = {0, 0, 314, 688};
	AdjustWindowRect(&r, WS_CAPTION, FALSE);
	
	calcs[slot].bCutout = TRUE;
	
	calcs[slot].hwndFrame = CreateWindowEx(
		WS_EX_APPWINDOW,
		g_szAppName,
        "Z80", 
		(WS_TILEDWINDOW | WS_VISIBLE) & ~(WS_MAXIMIZEBOX | WS_SIZEBOX),
        CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left, r.bottom - r.top,
        0, 0, g_hInst, NULL);
  
	calcs[slot].hwndLCD = CreateWindowEx(
		0,
		g_szLCDName,
		"LCD",
		WS_VISIBLE | WS_CHILD,
		LCD_X, LCD_Y, 96*2, 64*2,
		calcs[slot].hwndFrame, NULL, g_hInst, NULL);
  
	if (calcs[slot].hwndFrame == NULL || calcs[slot].hwndLCD == NULL) return -1;
	SetTimer(calcs[slot].hwndLCD, slot, TPF, TimerProc);
	
	calcs[slot].running = TRUE;
}

	
char* LoadRomIntialDialog(void) {
	OPENFILENAME ofn;
	char lpstrFilter[] 	= "\
Known file types ( *.sav; *.rom) \0*.sav;*.rom\0\
Save States  (*.sav)\0*.sav\0\
ROMS  (*.rom)\0*.rom\0\
All Files (*.*)\0*.*\0\0";
	char* FileName = malloc(MAX_PATH);
	ZeroMemory(&ofn, sizeof(ofn));
	ZeroMemory(FileName, MAX_PATH);
	ofn.lStructSize		= sizeof(OPENFILENAME);
	ofn.lpstrFilter		= (LPCTSTR) lpstrFilter;
	ofn.lpstrFile		= FileName;
	ofn.nMaxFile		= MAX_PATH;
	ofn.lpstrTitle		= "Wabbitemu: Please select a rom";
	ofn.Flags			= OFN_PATHMUSTEXIST | OFN_EXPLORER |
						  OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;
	if (!GetOpenFileName(&ofn)) {
		free(FileName);
		return NULL;
	}
	return FileName;
}



int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
   LPSTR lpszCmdParam, int nCmdShow) {
	FILE* cfgfile;
	MSG Msg;
	WNDCLASSEX wc;
	LPWSTR *argv;
	int argc;
	char romstring[512] = "z.rom";
	char tmpstring[512];
	BOOL loadfiles = FALSE;
	int length,i;
	
	length = GetModuleFileName(NULL,ExeDir,512);

	if (length) {
		for(i=length;i>0 && (ExeDir[i]!='\\') ;i--);
		if (i) ExeDir[i+1] = 0;
	}

	strcpy(tmpstring,ExeDir);
	strcat(tmpstring,"Wabbit.conf");

	cfgfile = fopen(tmpstring,"r");
	if (cfgfile) {
		fgets(tmpstring,512,cfgfile);
		if (strcmp(tmpstring,"Wabbitemu config\n") == 0) {
			fgets(romstring,512,cfgfile);
		}	
		fclose(cfgfile);
	}
	

	argv = CommandLineToArgvW(GetCommandLineW(),&argc);

	if (argv && argc>1) {
		wcstombs(tmpstring,argv[1],512);
		if ( (tmpstring[0]=='-') && (tmpstring[1]=='n') ) loadfiles = TRUE;
		else {
			HWND Findhwnd = FindWindow(g_szAppName, NULL);		
			if (Findhwnd == NULL) {
				loadfiles = TRUE;
			} else {
				HWND FindChildhwnd = FindWindowEx(Findhwnd,NULL,g_szLCDName,NULL);		
				if (FindChildhwnd == NULL) {
					loadfiles = TRUE;
				} else {
					COPYDATASTRUCT cds;
					char* FileNames = NULL;
					for(i=1;i<argc;i++) {
						memset(tmpstring,0,512);
						wcstombs(tmpstring,argv[i],512);
						if (tmpstring[0]!='-') {
							printf("%s \n",tmpstring);
							FileNames = AppendName(FileNames,tmpstring);
						} else if (toupper(tmpstring[1])=='F') {
							SwitchToThisWindow(FindChildhwnd, TRUE);
						}
					}
					i = SizeofFileList(FileNames);
					if (i>0) {
						cds.dwData = SEND_CUR;
						cds.cbData = i;
						cds.lpData = FileNames;
						SendMessage(FindChildhwnd, WM_COPYDATA, (WPARAM)NULL, (LPARAM)&cds);
						free(FileNames);
					}
					exit(0);
				}
			}
		}
	}
	
	
    g_hInst = hInstance;

	wc.cbSize = sizeof(wc);
	wc.style = CS_OWNDC;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(g_hInst, "W");
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = g_szAppName;
	wc.hIconSm = LoadIcon(g_hInst, "W");
	
	RegisterClassEx(&wc);
	
	// LCD
	wc.lpszClassName = g_szLCDName;
	wc.lpfnWndProc = LCDProc;
	RegisterClassEx(&wc);

	wc.lpfnWndProc = DebugProc;
	wc.style = CS_DBLCLKS;
	wc.lpszClassName = g_szDebugName;
	wc.lpszMenuName = MAKEINTRESOURCE(IDR_DB_MENU);
	wc.hbrBackground = (HBRUSH) (COLOR_BTNFACE+1);
	RegisterClassEx(&wc);
	
	wc.lpszMenuName = NULL;
	wc.style = CS_OWNDC | CS_HREDRAW;
	wc.lpfnWndProc = DisasmProc;
	wc.lpszClassName = g_szDisasmName;
	wc.hbrBackground = (HBRUSH) NULL;
	RegisterClassEx(&wc);
	
	wc.style = CS_DBLCLKS | CS_OWNDC;
	wc.lpfnWndProc = RegProc;
	wc.lpszClassName = g_szRegName;
	wc.hbrBackground = NULL;
	RegisterClassEx(&wc);

	wc.style = CS_DBLCLKS | CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = MemProc;
	wc.lpszClassName = g_szMemName;
	wc.hbrBackground = NULL;
	RegisterClassEx(&wc);

	
	// initialize com events (in our case for drag and drop)
	OleInitialize(0);

	int slot = calc_new();
	slot = rom_load(slot, romstring);
	if (slot != -1) calc_create_frame(slot);
	else {
		char* string =LoadRomIntialDialog();
		if (string) {
			slot = calc_new();
			slot = rom_load(slot, string);
			if (slot != -1) calc_create_frame(slot);
			else return EXIT_FAILURE;
		} else return EXIT_FAILURE;
	}

	strcpy(calcs[slot].labelfn,"labels.lab");

	if (loadfiles) {
		if (argv && argc>1) {
			char* FileNames = NULL;
			for(i=1;i<argc;i++) {
				memset(tmpstring,0,512);
				wcstombs(tmpstring,argv[i],512);
				if (tmpstring[0]!='-') {
					printf("%s\n",tmpstring);
					FileNames = AppendName(FileNames,tmpstring);
				}
			}
			ThreadSend(FileNames, SEND_CUR);
		}
	}
	loadfiles = FALSE;
	
	AppList(slot);
	VoidLabels(slot);

	hacceldebug = LoadAccelerators(g_hInst, "DisasmAccel");
	haccelmain = LoadAccelerators(g_hInst, "Z80Accel");	
	
    while (GetMessage(&Msg, NULL, 0, 0)) {
		HACCEL haccel = hacceldebug;
		HWND hwndtop = GetForegroundWindow();
		if (hwndtop) {
			if (hwndtop == FindWindow(g_szDebugName, NULL) ) {
				haccel = hacceldebug;
			} else if (hwndtop == FindWindow(g_szAppName, NULL) ) {
				haccel = haccelmain;
				hwndtop = FindWindowEx(hwndtop,NULL,g_szLCDName,NULL);
			}
		}
		if (!TranslateAccelerator(hwndtop, haccel, &Msg)) {
			TranslateMessage(&Msg);
			for (i = 0; i < MAX_CALCS; i++) {
				if (calcs[i].active) {
					if (	calcs[i].hwndFrame == Msg.hwnd ||
							calcs[i].hwndLCD == Msg.hwnd		) {
						gslot = i;
						break;
					}
				}
			}
        	DispatchMessage(&Msg);
		}
    }


	// Shutdown COM
	OleUninitialize();
	
	strcpy(tmpstring,ExeDir);
	strcat(tmpstring,"Wabbit.conf");
	cfgfile = fopen(tmpstring,"w");
	if (cfgfile) {
		fputs("Wabbitemu config\n",cfgfile);
		for (i=0; i<MAX_CALCS; i++) {
			if ( calcs[i].active ) {
				fputs(calcs[i].rom_path,cfgfile);
			}
		}
		fclose(cfgfile);
	}
    return Msg.wParam;
}


HDC hdcSkin;


LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	static HDC hdcKeymap;
	static HBITMAP hbmSkin, hbmKeymap;
	static RECT rectSkin = {0, 0, 314, 688};
	static POINT ctxtPt;
	

	switch (Message) {
		case WM_CREATE:
		{
			memset(calcs[gslot].breakpoints, 0, 0x10000);

			SkinCutout(hwnd);
			
			FILE *brkFile = fopen("breakpoints.brk","r");
			if (brkFile) {
				char buffer[32];
				while (fgets(buffer, 32, brkFile)) {
					int breakpoint = 0;
					if (buffer[0] == '$') {
						if (sscanf(buffer+1, "%X", &breakpoint) == 1)
							calcs[gslot].breakpoints[breakpoint & 0xFFFF] = TRUE;
						} else {
							if (sscanf(buffer, "%d", &breakpoint) == 1)
								calcs[gslot].breakpoints[breakpoint & 0xFFFF] = TRUE;
						}
				}
			}
				
			
			int width[] = {60, -1};
			
           /* hStatusBar = CreateWindowEx(0, STATUSCLASSNAME, NULL,
                WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP, 0, 0, 0, 0,
                hwnd, (HMENU)ID_STATUSBAR, g_hInst, NULL);*/
               
            //SendMessage(hStatusBar, SB_SETPARTS, NumElm(width), (LPARAM) width);
			char sz_names[64] = "TIOS - ";
			unsigned int i;
            for (i = 0; i < sizeof(sz_names); i++) {
				sz_names[i+7] = mem_read((&calcs[gslot].cpu)->mem_c, 0x64 + i);
			}
			sz_names[i] = 0;
			//SendMessage(hStatusBar, SB_SETTEXT, 1, (LPARAM) sz_names);
			SetWindowText(hwnd, "Wabbitemu");
			
			HDC hdc = GetDC(hwnd);
			hbmSkin = LoadBitmap(g_hInst, "Skin");
			hdcSkin = CreateCompatibleDC(hdc);
			SelectObject(hdcSkin, hbmSkin);
			
			calcs[gslot].hbmSkin = LoadBitmap(g_hInst, "Skin");
			calcs[gslot].hdcSkin = CreateCompatibleDC(hdc);
			SelectObject(calcs[gslot].hdcSkin, calcs[gslot].hbmSkin);
			
			hbmKeymap = LoadBitmap(g_hInst, "Keymap");
			hdcKeymap = CreateCompatibleDC(hdc);
			SelectObject(hdcKeymap, hbmKeymap);
			
			return 0;
		}
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc;
			hdc = BeginPaint(hwnd, &ps);
			RECT rc;
			GetClientRect(hwnd, &rc);		
						
			StretchBlt(hdc, 0, 0, rc.right, rc.bottom, hdcSkin, 
				rectSkin.left, rectSkin.top, rectSkin.right, rectSkin.bottom, SRCCOPY);
			
			EndPaint(hwnd, &ps);
			return 0;
		}
		case WM_COMMAND:
		{
			switch (LOWORD(wParam)) {
				case ECM_RESIZE1_5:
				{
					RECT sbr, r = {0, 0, 236, 516};
					CopyRect(&rectSkin, &r);
					DeleteObject(hbmSkin);
					DeleteObject(hbmKeymap);
					DeleteObject(calcs[gslot].hbmSkin);
					hbmSkin = LoadBitmap(g_hInst, "Skin15");
					SelectObject(hdcSkin, hbmSkin);
					calcs[gslot].hbmSkin = LoadBitmap(g_hInst, "Skin15");
					hbmKeymap = LoadBitmap(g_hInst, "Keymap15");
					SelectObject(hdcKeymap, hbmKeymap);
					SelectObject(calcs[gslot].hdcSkin, calcs[gslot].hbmSkin);
					goto finish_resize;
				case ECM_RESIZE2:
					DeleteObject(hbmSkin);
					DeleteObject(hbmKeymap);
					DeleteObject(calcs[gslot].hbmSkin);
					hbmSkin = LoadBitmap(g_hInst, "Skin");
					SelectObject(hdcSkin, hbmSkin);
					calcs[gslot].hbmSkin = LoadBitmap(g_hInst, "Skin");
					SelectObject(calcs[gslot].hdcSkin, calcs[gslot].hbmSkin);
					hbmKeymap = LoadBitmap(g_hInst, "Keymap");
					SelectObject(hdcKeymap, hbmKeymap);
					SetRect(&r, 0, 0, 314, 688);
					CopyRect(&rectSkin, &r);
/*
					goto finish_resize;
				case ECM_RESIZE3:
					break;
					DeleteObject(hbmSkin);
					hbmSkin = LoadBitmap(g_hInst, "Skin");
					SelectObject(hdcSkin, hbmSkin);
					SetRect(&r, 0, 0, (314*3)/2, (688*3)/2);
					SetRect(&rectSkin, 0, 0, 314, 688);
					*/
				finish_resize:
					AdjustWindowRect(&r, WS_CAPTION, FALSE);
					SetWindowPos(hwnd, HWND_TOP, -1, -1,
						r.right - r.left,
						r.bottom - r.top,
						SWP_NOMOVE);
					DrawButtonLockAll(hwnd, hdcSkin, hdcKeymap);
					break;
				}
				case IDM_FRAME_BTOGGLE:
					SendMessage(hwnd, WM_MBUTTONDOWN, MK_MBUTTON, MAKELPARAM(ctxtPt.x, ctxtPt.y));
					break;
				case UPDATE_TITLE_BAR:
				{
					static int FpsDisplay = 1;
					static int skip = 0;
					skip = (skip+1)%20;
					if (skip == 0 ) {
						LCD_t *lcd = (&calcs[gslot].cpu)->pio.devices[0x11].aux;
						char sz_status[128];
						if (lcd->active && (lcd->ufps>8 && lcd->ufps<110)) {
							sprintf(sz_status,"WeTI-FPS: %0.2Lf\0",(float)lcd->ufps);
							SetWindowText(hwnd,sz_status);
							FpsDisplay = 1;
						} else {
							if (FpsDisplay != 0) {
								SetWindowText(hwnd,"Wabbitemu");
								FpsDisplay = 0;
							}
						}
					}
					break;
				}
				case IDM_FRAME_BUNLOCK:
				{
					RECT rc;
					keypad_t *kp = (&calcs[gslot].cpu)->pio.devices[1].aux;
					int group,bit;
					GetClientRect(hwnd, &rc);		
					for(group=0;group<7;group++) {
						for(bit=0;bit<8;bit++) {
							kp->keys[group][bit] &=(~KEY_LOCKPRESS);
						}
					}
					calcs[gslot].cpu.pio.keypad->on_pressed &=(~KEY_LOCKPRESS);
					BitBlt(hdcSkin,0,0,rc.right-rc.left,rc.bottom-rc.top,calcs[gslot].hdcSkin,0,0,SRCCOPY);
					SendMessage(hwnd, WM_SIZE, 0, 0);
					break;
				}
				
				
			}
			return 0;
		}
		case WM_MOUSEMOVE:
		case WM_LBUTTONUP:
		case WM_LBUTTONDOWN:
		{
			int group,bit,width,height;
			POINT pt;
			keypad_t *kp = (&calcs[gslot].cpu)->pio.devices[1].aux;

			pt.x	= GET_X_LPARAM(lParam);
			pt.y	= GET_Y_LPARAM(lParam);		
			for(group=0;group<7;group++) {
				for(bit=0;bit<8;bit++) {
					kp->keys[group][bit] &=(~KEY_MOUSEPRESS);
				}
			}

			calcs[gslot].cpu.pio.keypad->on_pressed &= ~KEY_MOUSEPRESS;

			if (wParam != MK_LBUTTON) return 0;

			COLORREF c = GetPixel(hdcKeymap, pt.x, pt.y);
			if (GetRValue(c) == 0xFF) return 0;
			if (GetGValue(c) == 0x50 && GetBValue(c) == 0x00){
				calcs[gslot].cpu.pio.keypad->on_pressed |= KEY_MOUSEPRESS;
			} else {
				kp->keys[GetGValue(c) >> 4][GetBValue(c) >> 4] |= KEY_MOUSEPRESS;
			}
			return 0;
		}
		case WM_MBUTTONDOWN:
		{
			int group,bit,width,height;
			POINT pt;
			keypad_t *kp = (&calcs[gslot].cpu)->pio.devices[1].aux;
 
			pt.x	= GET_X_LPARAM(lParam);
			pt.y	= GET_Y_LPARAM(lParam);	
 
			COLORREF c = GetPixel(hdcKeymap,pt.x, pt.y);
			if (GetRValue(c) == 0xFF) return 0;
			group	= GetGValue(c)>>4;
			bit		= GetBValue(c)>>4;
 
			if (group== 0x05 && bit == 0x00) {
				calcs[gslot].cpu.pio.keypad->on_pressed ^= KEY_LOCKPRESS;
				if ( calcs[gslot].cpu.pio.keypad->on_pressed &  KEY_LOCKPRESS ) {
					DrawButtonLock(hwnd, hdcSkin, hdcKeymap,pt,TRUE);
				} else {
					DrawButtonLock(hwnd, hdcSkin, hdcKeymap,pt,FALSE);
				}
			} else {
				kp->keys[group][bit] ^= KEY_LOCKPRESS;
				if (kp->keys[group][bit] &  KEY_LOCKPRESS ) {
					DrawButtonLock(hwnd, hdcSkin, hdcKeymap,pt,TRUE);
				} else {
					DrawButtonLock(hwnd, hdcSkin, hdcKeymap,pt,FALSE);
				}
 
			}
			SendMessage(hwnd, WM_SIZE, 0, 0);
			return 0;
		}
		
		case WM_KEYDOWN:
		case WM_KEYUP:
		{
			if (wParam == VK_F8 && Message == WM_KEYDOWN) {
				calcs[gslot].warp = !calcs[gslot].warp;
			}

			if (wParam == VK_F12) {
				if (Message == WM_KEYDOWN) {
					calcs[gslot].cpu.pio.keypad->on_pressed |= KEY_KEYBOARDPRESS;
				} else {
					calcs[gslot].cpu.pio.keypad->on_pressed &= ~KEY_KEYBOARDPRESS;
				}
			}
			GetKeyboardState(calcs[gslot].lpKeyState);
			return 0;
		}
		case WM_SIZE:
		{
			RECT rc, screen;
			GetClientRect(hwnd, &rc);

			double xc = ((double)rc.right)/314.0f, yc = ((double)rc.bottom)/688.0f;
			SetRect(&screen, 
				0, 0,
				96*2*xc,
				64*2*yc);
			OffsetRect(&screen, LCD_X*xc, LCD_Y*yc);
			if ((rc.right - rc.left) & 1) rc.right++;
			if ((rc.bottom - rc.top) & 1) rc.bottom++;

			MoveWindow(calcs[gslot].hwndLCD, screen.left, screen.top, 
				screen.right-screen.left, screen.bottom-screen.top, TRUE);

			UpdateWindow(calcs[gslot].hwndLCD);
			InvalidateRect(hwnd, NULL, FALSE);
			screen.left++; screen.top++;
			ValidateRect(hwnd, &screen);
			return 0;	
		}
		case WM_CONTEXTMENU:
		{
			ctxtPt.x = GET_X_LPARAM(lParam);
			ctxtPt.y = GET_Y_LPARAM(lParam);
			
			HMENU hmenu = LoadMenu(g_hInst, MAKEINTRESOURCE(IDR_FRAME_MENU)); 
		    // TrackPopupMenu cannot display the menu bar so get 
		    // a handle to the first shortcut menu. 
			hmenu = GetSubMenu(hmenu, 0); 
			
			if (!OnContextMenu(hwnd, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam), hmenu)) {
				DefWindowProc(hwnd, Message, wParam, lParam);
			}
			ScreenToClient(hwnd, &ctxtPt);
			DestroyMenu(hmenu); 
			return 0;
		}
		case WM_DESTROY:
		case WM_CLOSE:
			
			if (gif_write_state == GIF_FRAME) {
				gif_write_state = GIF_END;
				handle_screenshot();
			}


			//UnregisterDropWindow(hwnd, pDropTarget);
			DeleteObject(hbmSkin);
			DeleteDC(hdcSkin);
			DeleteObject(hbmKeymap);
			DeleteDC(hdcKeymap);
			DestroyWindow(hwnd);
			PostQuitMessage(0);
			return 0;
		case WM_NCHITTEST:
		{
			int htRet = DefWindowProc(hwnd, Message, wParam, lParam);
			if (htRet != HTCLIENT) return htRet;
			
			POINT pt;
			pt.x = GET_X_LPARAM(lParam);
			pt.y = GET_Y_LPARAM(lParam);
			ScreenToClient(hwnd, &pt);
			if (GetRValue(GetPixel(hdcKeymap, pt.x, pt.y)) != 0xFF) return htRet;
			return HTCAPTION;
		}
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}	
}
