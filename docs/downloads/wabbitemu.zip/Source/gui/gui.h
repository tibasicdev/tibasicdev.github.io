#ifndef GUI_H
#define GUI_H

#include <windows.h>

#include <windowsx.h>
#include <strings.h>
#include <stdio.h>
#include <commctrl.h>
#include <winuser.h>
#include <shlobj.h>

#define NumElm(array) (sizeof (array) / sizeof ((array)[0]))

#define SKIN_WIDTH	314
#define SKIN_HEIGHT	688

#define g_szWebPage		"http://www.revsoft.org/emu"

#define g_szAppName 	"z80"
#define g_szDebugName 	"debug"
#define g_szDisasmName 	"disasm"
#define g_szRegName 	"reg"
#define g_szMemName		"mem"
#define g_szLinkName	"link"
#define g_szLCDName 	"wabbitlcd"
#define g_szWabbitName 	"wabbit"


#define ECM_RESIZE1_5	300
#define ECM_RESIZE2		301
#define ECM_RESIZE3		302


#define SEND_VAR_DIALOG 350
#define TOGGLE_SOUND		352
#define TOGGLE_GIF			353
#define SET_09FPS			355
#define SET_25FPS			356
#define SET_BW				357
#define SET_GREY			358
#define SET_GIF_NAME		359
#define LCD_ABOUT			360
#define SAVE_STATE_DIALOG	361
#define LOAD_STATE_DIALOG	362

#define UPDATE_TITLE_BAR	448

#define	ECM_BUTTONLOCK		304
#define ECM_BUTTONRESETALL	305

#define IDM_PREFERENCES		306

#define IDM_DEBUG		3346
#define IDM_COPY		3347
#define DB_DISASM		40
#define DB_RUN			444
#define DB_BREAKPOINT	445
#define DB_STEP			446
#define DB_GOTO			447
#define DB_STEPOVER		448




#define ID_DISASM 	0
#define ID_REG 		1
#define ID_MEM		3
#define ID_STACK	4
#define ID_WABBIT	5
#define ID_DISASMSIZE 6
#define ID_SIZE 6

#define ID_STATUSBAR	50


#define REG_SWAPID		80
#define REG_CHK_Z		88
#define REG_CHK_C		89
#define REG_CHK_S		90
#define REG_CHK_PV		91
#define REG_CHK_HC		92
#define REG_CHK_N		93
#define REG_CHK_HALT	94
#define REG_CHK_IFF1	95
#define REG_CHK_IFF2	96

#define DB_UPDATE		1

#define REG_UPDATE		1


#define MEM_BYTE		1
#define MEM_WORD		2
#define MEM_DWORD		4

#define ErrorDialog		13


#endif
