#ifndef GUIDEBUG_H
#define GUIDEBUG_H

#include "gui.h"

LRESULT CALLBACK DebugProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

#endif
