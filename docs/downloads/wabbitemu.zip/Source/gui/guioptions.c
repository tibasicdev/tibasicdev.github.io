#include "gui.h"
#include "guioptions.h"
#include <commctrl.h>
#include <string.h>
#include "gif.h"
#include "rsrc.h"
#include "calc.h"

extern HINSTANCE g_hInst;


void DoPropertySheet(HWND hwndOwner) {
	PROPSHEETPAGE psp[3];
	PROPSHEETHEADER psh;
	
	psp[0].dwSize = sizeof(PROPSHEETPAGE);
	psp[0].dwFlags = PSP_USEICONID | PSP_USETITLE;
	psp[0].hInstance = g_hInst;
	psp[0].pszTemplate = MAKEINTRESOURCE(IDD_GIFOPTIONS);
	psp[0].pszIcon = NULL;
	psp[0].pfnDlgProc = GIFOptionsProc;
	psp[0].pszTitle = "Screen Capture";
	psp[0].lParam = 0;
	psp[0].pfnCallback = NULL;

	psp[1].dwSize = sizeof(PROPSHEETPAGE);
	psp[1].dwFlags = PSP_USEICONID | PSP_USETITLE;
	psp[1].hInstance = g_hInst;
	psp[1].pszTemplate = MAKEINTRESOURCE(IDD_ROMOPTIONS);
	psp[1].pszIcon = NULL;
	psp[1].pfnDlgProc = ROMOptionsProc;
	psp[1].pszTitle = "ROM";
	psp[1].lParam = 0;
	psp[1].pfnCallback = NULL;
	
	psp[2].dwSize = sizeof(PROPSHEETPAGE);
	psp[2].dwFlags = PSP_USEICONID | PSP_USETITLE;
	psp[2].hInstance = g_hInst;
	psp[2].pszTemplate = MAKEINTRESOURCE(IDD_SKINOPTIONS);
	psp[2].pszIcon = NULL;
	psp[2].pfnDlgProc = SkinOptionsProc;
	psp[2].pszTitle = "Skin";
	psp[2].lParam = 0;
	psp[2].pfnCallback = NULL;
	
	psh.dwSize = sizeof(PROPSHEETHEADER);
	psh.dwFlags = PSH_PROPSHEETPAGE | PSH_NOCONTEXTHELP;
	psh.hwndParent = hwndOwner;
	psh.hInstance = g_hInst;
	psh.pszIcon = NULL;
	psh.pszCaption = (LPSTR) "Wabbitemu Options";
	psh.nPages = sizeof(psp) / sizeof(PROPSHEETPAGE);
	psh.nStartPage = 0;
	psh.ppsp = (LPCPROPSHEETPAGE) &psp;
	psh.pfnCallback = NULL;
	PropertySheet(&psh);
	return;
}

void GIFOptionsToggleAutosave(HWND hwndDlg, BOOL bEnable) {
	HWND 
	hwndEdt 	= GetDlgItem(hwndDlg, IDC_EDTGIFFILENAME),
	hwndChk 	= GetDlgItem(hwndDlg, IDC_CHKUSEINCREASING),
	hwndStc 	= GetDlgItem(hwndDlg, IDC_STCAUTOSAVE),
	hwndBtn		= GetDlgItem(hwndDlg, IDC_BTNGIFBROWSE);
	
	EnableWindow(hwndEdt, bEnable);
	EnableWindow(hwndChk, bEnable);
	EnableWindow(hwndStc, bEnable);
	EnableWindow(hwndBtn, bEnable);
}



/* 	Set bSave = TRUE if you are prompting for a file name to save to
/*	If you're fetching a filename otherwise, bSave = FALSE */	
int SetGifName(BOOL bSave) {
	OPENFILENAME ofn;

	char lpstrFilter[] 	= "\
Graphics Interchange Format  (*.gif)\0*.gif\0\
All Files (*.*)\0*.*\0\0";
	char lpstrFile[MAX_PATH];
	unsigned int Flags = 0;
	
	if (bSave) Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;

	int i;
	for (i = strlen(gif_file_name)-1; i && gif_file_name[i] != '\\'; i--);
	
	if (i) {
		strcpy(lpstrFile, gif_file_name + i + 1);
	} else {
		lpstrFile[0] = '\0';
	}

	ofn.lStructSize			= sizeof(OPENFILENAME);
	ofn.hwndOwner			= GetForegroundWindow();
	ofn.hInstance			= NULL;
	ofn.lpstrFilter			= (LPCTSTR) lpstrFilter;
	ofn.lpstrCustomFilter	= NULL;
	ofn.nMaxCustFilter		= 0;
	ofn.nFilterIndex		= 0;
	ofn.lpstrFile			= lpstrFile;
	ofn.nMaxFile			= sizeof(lpstrFile);
	ofn.lpstrFileTitle		= NULL;
	ofn.nMaxFileTitle		= 0;
	ofn.lpstrInitialDir		= NULL;
	ofn.lpstrTitle			= "Wabbitemu GIF File Target";
	ofn.Flags				= Flags | OFN_HIDEREADONLY | OFN_EXPLORER | OFN_LONGNAMES;
	ofn.lpstrDefExt			= "gif";
	ofn.lCustData			= 0;
	ofn.lpfnHook			= NULL;
	ofn.lpTemplateName		= NULL;
	ofn.pvReserved			= NULL;
	ofn.dwReserved			= 0;
	ofn.FlagsEx				= 0;

	if (!GetSaveFileName(&ofn)) {
		return 1;
	}
	strcpy(gif_file_name, lpstrFile);
	return 0;
}




void SkinCutout(HWND hwnd) {
	POINT ptRgn1[] = {	{127,7},
						{64,9},
						{42,10},
						{22,12},
						{17,14},	
						{16,15},	
						{11,23},
						{9, 177},
						{8, 225},
						{8, 302},
						{9, 398},	
						{15,615},
						{17,628},
						{23,641},
						{37,655},
						{44,659},
						{67,668},
						{124,677},
						{148,678}};
						
	POINT ptRgn[NumElm(ptRgn1) * 2];					
	unsigned int i;
	for (i = 0; i < NumElm(ptRgn1); i++) {
		ptRgn[i].y = ptRgn1[i].y + GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CYFIXEDFRAME);
		ptRgn[i].x = ptRgn1[i].x + GetSystemMetrics(SM_CXFIXEDFRAME);
	}
	
	for (;i < NumElm(ptRgn); i++) {
		ptRgn[i].y = ptRgn1[NumElm(ptRgn) - i - 1].y + GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CYFIXEDFRAME);
		ptRgn[i].x = 310 - ptRgn1[NumElm(ptRgn) - i - 1].x + GetSystemMetrics(SM_CXFIXEDFRAME);
	}
	
	HRGN hrgn;
	hrgn = CreatePolygonRgn(ptRgn, NumElm(ptRgn), WINDING);
	SetWindowRgn(hwnd, hrgn, TRUE);	
}





INT_PTR CALLBACK SkinOptionsProc(HWND hwndDlg, UINT Message, WPARAM wParam, LPARAM lParam) {
	static HWND chkCutout;
	switch (Message) {
		case WM_INITDIALOG:
			chkCutout = GetDlgItem(hwndDlg, IDC_CHKCUTOUT);
			SendMessage(chkCutout, BM_SETCHECK, calcs[gslot].bCutout, 0);
			return 0;
		case WM_NOTIFY:
			
    		switch (((NMHDR FAR *) lParam)->code) {
				case PSN_APPLY: {
					calcs[gslot].bCutout = 
					SendMessage(chkCutout, BM_GETSTATE, 0, 0) & 0x0003 ?
						TRUE : FALSE;
						
					if (calcs[gslot].bCutout) {
						SkinCutout(calcs[gslot].hwndFrame);
					} else {
						SetWindowRgn(calcs[gslot].hwndFrame, NULL, TRUE);	
					}
				}
			}
			return TRUE;
		case WM_COMMAND:
			PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
			return TRUE;
	}
	return FALSE;
}



INT_PTR CALLBACK GIFOptionsProc(HWND hwndDlg, UINT Message, WPARAM wParam, LPARAM lParam) {
	static HWND cbColor, hwndSpeed, chkAutosave, edtGIFFilename, chkUseIncreasing;
	switch (Message) {
		case WM_INITDIALOG: {
			cbColor = GetDlgItem(hwndDlg, IDC_CBOGIFCOLOR);
			SendMessage(cbColor, CB_ADDSTRING,  0, (LPARAM) "Black & White");
			SendMessage(cbColor, CB_ADDSTRING,  0, (LPARAM) "7 Level Gray");
			SendMessage(cbColor, CB_SETCURSEL, gif_colors/7, 0);
			
			hwndSpeed = GetDlgItem(hwndDlg, IDC_TRBGIFFPS);
			SendMessage(hwndSpeed, TBM_SETRANGE,
			    (WPARAM) TRUE,
			    (LPARAM) MAKELONG(0, TBRTICS));
			SendMessage(hwndSpeed, TBM_SETTICFREQ, 1, 0);
			
			int speedPos = 0;
			if (gif_base_delay_start != 0) {
			 	speedPos = ((100/gif_base_delay_start)-9)/TBRSTEP;
			}

			SendMessage(hwndSpeed, TBM_SETPOS, TRUE, speedPos);

			int delayMin = (100/(9+(TBRTICS * TBRSTEP)));
			int fpsMax = 100/delayMin;
			HWND hwndMaxSpeed = GetDlgItem(hwndDlg, IDC_STCGIFMAX);
			TCHAR lpszMax[10];
			sprintf(lpszMax, "%d", fpsMax);
			SendMessage(hwndMaxSpeed, WM_SETTEXT, 0, (LPARAM) lpszMax);
			
			
			chkAutosave = GetDlgItem(hwndDlg, IDC_CHKENABLEAUTOSAVE);
			SendMessage(chkAutosave, BM_SETCHECK, gif_autosave, 0);
			GIFOptionsToggleAutosave(hwndDlg, gif_autosave);
			
			edtGIFFilename = GetDlgItem(hwndDlg, IDC_EDTGIFFILENAME);
			SendMessage(edtGIFFilename, WM_SETTEXT, 0, (LPARAM) gif_file_name);
			
			chkUseIncreasing = GetDlgItem(hwndDlg, IDC_CHKUSEINCREASING);
			SendMessage(chkUseIncreasing, BM_SETCHECK, gif_use_increasing, 0);
			return TRUE;
		}
		case WM_NOTIFY:
    		switch (((NMHDR FAR *) lParam)->code) {
				case PSN_APPLY: {
					int colorSel = SendMessage(cbColor, CB_GETCURSEL, 0, 0);
					switch (colorSel) {
						case 0: gif_colors = 2; break;
						case 1: gif_colors = 7; break;
					}
					int speedPos = SendMessage(hwndSpeed, TBM_GETPOS, 0, 0);
					//printf("spedpos: %d\n",speedPos);
					
					if (gif_write_state == GIF_IDLE) {
						gif_base_delay_start = 	//GIF_MINIMUM + (GIF_MAXIMUM=GIF_MINIMUM)/6
												(100/(9+(speedPos * TBRSTEP)));
					}
					//printf("gifbasedelay: %d\n",gif_base_delay_start);
					
					gif_autosave =
					SendMessage(chkAutosave, BM_GETSTATE, 0, 0) & 0x0003 ?
						TRUE : FALSE;
											
					gif_use_increasing =
					SendMessage(chkUseIncreasing, BM_GETSTATE, 0, 0) & 0x0003 ?
						TRUE : FALSE;

					return TRUE;
				}
			}
			break;
		case WM_COMMAND:
			switch (HIWORD(wParam)) {
				case CBN_SELCHANGE:
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					return TRUE;
				case BN_CLICKED:
					switch (LOWORD(wParam)) {
						case IDC_BTNGIFPRESET1:
							SendMessage(hwndSpeed, TBM_SETPOS, TRUE, 0);
							SendMessage(cbColor, CB_SETCURSEL, 0, 0);
							break;
						case IDC_BTNGIFPRESET2:
							SendMessage(hwndSpeed, TBM_SETPOS, TRUE, TBRTICS - 1);
							SendMessage(cbColor, CB_SETCURSEL, 1, 0);
							break;
						case IDC_CHKENABLEAUTOSAVE: {
							BOOL bEnable = FALSE;
							if (SendMessage(chkAutosave, BM_GETSTATE, 0, 0) & 0x0003) {
								bEnable = TRUE;
							}
							GIFOptionsToggleAutosave(hwndDlg, bEnable);
							break;
						}
						case IDC_BTNGIFBROWSE:
							SetGifName(FALSE);
							SendMessage(edtGIFFilename, WM_SETTEXT, 0, (LPARAM) gif_file_name);
							break;
						case IDC_CHKUSEINCREASING:
							break;
						default:
							return FALSE;
					}
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					break;
			}
			break;
		case WM_HSCROLL:
		case WM_VSCROLL:
			PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
			return TRUE;
	}
				
	return FALSE;
}



int GetROMName(char *lpstrFile) {
	OPENFILENAME ofn;

	char lpstrFilter[] 	= "\
Calculator ROM  (*.rom, *.bin)\0*.rom;*.bin\0\
All Files (*.*)\0*.*\0\0";

	ZeroMemory(&ofn, sizeof(ofn));

	ofn.lStructSize			= sizeof(OPENFILENAME);
	ofn.hwndOwner			= GetForegroundWindow();
	ofn.lpstrFilter			= (LPCTSTR) lpstrFilter;
	ofn.lpstrFile			= lpstrFile;
	ofn.nMaxFile			= MAX_PATH;
	ofn.lpstrTitle			= "Wabbitemu Load ROM";
	ofn.Flags				= OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_EXPLORER | OFN_LONGNAMES;

	if (!GetOpenFileName(&ofn)) {
		return 1;
	}
	return 0;
}

int GetExportROMName(char *lpstrFile) {
	OPENFILENAME ofn;
	char lpstrFilter[] 	= "\
ROMS  (*.rom)\0*.rom\0\
BINS  (*.bin)\0*.bin\0\
All Files (*.*)\0*.*\0\0";

	ZeroMemory(&ofn, sizeof(ofn));
	ZeroMemory(lpstrFile, MAX_PATH);

	ofn.lStructSize		= sizeof(OPENFILENAME);
	ofn.hwndOwner		= GetForegroundWindow();
	ofn.lpstrFilter		= (LPCTSTR) lpstrFilter;
	ofn.lpstrFile		= lpstrFile;
	ofn.nMaxFile		= MAX_PATH;
	ofn.lpstrTitle		= "Wabbitemu Export Rom";
	ofn.Flags			= OFN_PATHMUSTEXIST | OFN_EXPLORER | 
						  OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY;
	ofn.lpstrDefExt		= "rom";
	if (!GetSaveFileName(&ofn)) return 1;
	return 0;
}


INT_PTR CALLBACK ROMOptionsProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	static HWND edtRom_path, edtRom_version, edtRom_model, edtRom_size, stcRom_image;
	static HBITMAP hbmTI83P = NULL;
	switch (Message) {
		case WM_INITDIALOG: {
			edtRom_path = GetDlgItem(hwnd, IDC_EDTROMPATH);
			edtRom_version = GetDlgItem(hwnd, IDC_EDTROMVERSION);
			edtRom_model = GetDlgItem(hwnd, IDC_EDTROMMODEL);
			edtRom_size = GetDlgItem(hwnd, IDC_EDTROMSIZE);
			stcRom_image = GetDlgItem(hwnd, IDC_STCROMIMAGE);
			
			return SendMessage(hwnd, WM_USER, 0, 0);
		}
		case WM_COMMAND:
			switch (HIWORD(wParam)) {
				case BN_CLICKED:
					switch (LOWORD(wParam)) {
						case IDC_BTNROMBROWSE: {
							char lpszFile[MAX_PATH] = "\0";
							if (!GetROMName(lpszFile)) {
								strcpy(calcs[gslot].rom_path, lpszFile);
								SendMessage(calcs[gslot].hwndLCD, WM_COMMAND, ECM_CALCRELOAD, 0);
								SendMessage(hwnd, WM_USER, 0, 0);
							}
							break;
						}
						case IDC_BTN1: {
							char lpszFile[MAX_PATH] = "\0";
							if (!GetExportROMName(lpszFile)) {
								FILE* outfile = fopen(lpszFile,"wb");
								char* rom = calcs[gslot].mem_c.flash;
								int size = calcs[gslot].mem_c.flash_size;
								if (size!=0 && rom!=NULL && outfile!=NULL) {
									int i;
									for(i=0;i<size;i++) {
										fputc(rom[i],outfile);
									}
									fclose(outfile);
								}
							}
							break;
						}
					}
			}
			return TRUE;
		// Update all of the ROM attributes
		case WM_USER:
			SendMessage(edtRom_path, WM_SETTEXT, 0, (LPARAM) calcs[gslot].rom_path);
			SendMessage(edtRom_version, WM_SETTEXT, 0, (LPARAM) calcs[gslot].rom_version);
			SendMessage(edtRom_model, WM_SETTEXT, 0, (LPARAM) CalcModelTxt[calcs[gslot].model]);
			char szRomSize[16];
			sprintf(szRomSize, "%0.1f KB", (float) calcs[gslot].cpu.mem_c->flash_size/1024.0f);
			SendMessage(edtRom_size, WM_SETTEXT, 0, (LPARAM) szRomSize);
			if (hbmTI83P) DeleteObject(hbmTI83P);
			switch (calcs[gslot].model) {
				case TI_83PSE:
					hbmTI83P = LoadBitmap(g_hInst, "CalcTI83PSE");
					break;
				default:
					hbmTI83P = LoadBitmap(g_hInst, "CalcTI83P");
					break;
			}
			SendMessage(stcRom_image, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM) hbmTI83P);	
			return TRUE;
	}
	return FALSE;
}
