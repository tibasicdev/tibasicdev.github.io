#ifndef GUICONTEXT_H
#define GUICONTEXT_H

#include "gui.h"

BOOL WINAPI OnContextMenu(HWND, int, int, HMENU);

#endif /* GUICONTEXT_H */
