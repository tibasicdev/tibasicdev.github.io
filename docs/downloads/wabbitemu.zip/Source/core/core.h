#ifndef CORE_H
#define CORE_H

#include <stdio.h>
#include <time.h>
#include <string.h>

#ifndef TRUE
#define TRUE 	1
#define FALSE 	0
typedef int BOOL;
#endif

#ifndef PAGE_SIZE
#define PAGE_SIZE 16384
#endif

#define FPS 50
// ticks per frame
#define TPF (1000 / FPS)
// typical 83+ speed,  Mode 0 on SE 6300000
#define MHZ_6 6000000
// Mode 1 on the SE
#define MHZ_15 15000000
// Planned Mode 2 on the SE
#define MHZ_20 20000000
// Planned Mode 3 on the SE
#define MHZ_25 25000000

#define MHZ_9 9437184

#define IX_PREFIX 0xDD
#define IY_PREFIX 0xFD

/* 	Macro to form a register pair
/*		Can refer to pair by
/*		either contituent given
/*	Example:
/*		regpair(h, l, hl);
/*		---
/*		struct.h
/*		struct.l
/*		struct.hl					*/
#define regpair(name1,name2,fullname) \
union { \
	struct { \
		unsigned char name2; \
		unsigned char name1; \
	}; \
	unsigned short fullname; \
}

/* 	Determines frequency provided
/*	to the CPU */
typedef struct timer_context {
	long long tstates;
	long freq;
	double elapsed;
	double lasttime;
} timer_context_t, timerc;

/* Bank unit for a partition */
typedef struct bank_state {
	unsigned char * addr;		//Pointer to offset of memory.(already paged)
	int page;					//Current 16kb page
	BOOL read_only;				//You can not write to this page(not even if the flash is unlocked)
	BOOL ram;					//This is on the ram chip(also effect write method for flash)
	BOOL no_exec;				//You can not execute on this page	
} bank_state_t;

/* Memory address translation */
#define MC_BANK_MASK	0xC000
#define MC_BASE_MASK	(~MC_BANK_MASK)

#define mc_bank(addr_z) (addr_z >> 14)
#define mc_base(addr_z) (addr_z & MC_BASE_MASK)

typedef struct memory_context {
	/* to be defined */
	unsigned char * flash;		//Pointer to flash memory
	unsigned char * ram;		//Pointer to raem
	int flash_size;
	int flash_pages;
	int ram_size;
	int ram_pages;
	int step;					// These 3 are for flash programming
	unsigned char cmd;			// step tells what cycle of the command you are on,
								
	bank_state_t banks[5];		//Current state of each bank
								// structure 5 is used to preserve the 4th in boot map
	BOOL boot_mapped;			//Special mapping used in boot that rotates location of pages
	BOOL flash_locked;			//Whether flash is writeable or not.
	
	int flash_version;
	
	int read_OP_flash_tstates;	//These are for delays on SEs, typically they should be 0.
	int read_NOP_flash_tstates;
	int write_flash_tstates;
	int read_OP_ram_tstates;
	int read_NOP_ram_tstates;
	int write_ram_tstates;
	
	unsigned char upper;
	unsigned char lower;
} memory_context_t, memc;






/* Input/Output device mapping */
typedef void (*devp)(void*, void*);
typedef struct device {
	BOOL active;
	memc *mem_c;
	void *aux;
	devp code;
} device_t;

typedef struct pio_context {
	struct LCD *lcd;
	struct keypad *keypad;
	struct LINK *link;
	struct STDINT *stdint;
	struct SE_AUX *se_aux;
	/* list other cross model devices here */
	
	device_t devices[256];
	int interrupt[256];
	unsigned int skip_factor[256];
	unsigned int skip_count[256];
} pio_context_t, pioc;

typedef struct CPU {
	/* Register bank 0 */
	regpair(a, f, af);
	regpair(b, c, bc);
	regpair(d, e, de);
	regpair(h, l, hl);
	/* Register bank 1 */
	regpair(ap, fp, afp);
	regpair(bp, cp, bcp);
	regpair(dp, ep, dep);
	regpair(hp, lp, hlp);
	/* Remaining CPU registers */
	regpair(ixh, ixl, ix);
	regpair(iyh, iyl, iy);
	unsigned short pc, sp;
	unsigned char i, r, bus;
	int imode;
	BOOL interrupt;
	BOOL ei_block;
	BOOL iff1,iff2;
	BOOL halt;
	BOOL read, write, output, input;
	int prefix;
	pioc pio;
	memc *mem_c;
	timerc *timer_c;
} CPU_t;

typedef void (*opcodep)(CPU_t*);
typedef void (*index_opcodep)(CPU_t*, char);

/* Inlines might have to be static? */
unsigned char mem_read(memc*, unsigned short);
unsigned char mem_write(memc*, unsigned short, char);

int tc_init(timerc*, int);
int CPU_init(CPU_t*, memc*, timerc*);

#ifdef DEBUG
void displayreg(CPU_t *);
#endif

//int tc_add(timerc*, int);

#define tc_add( timer_z , num ) \
	timer_z->tstates += num; \
	timer_z->elapsed += ((double)(num))/((double)timer_z->freq);


#ifdef UseSEtiming
#define SEtc_add( timer_z , num ) \
	timer_z->tstates += num; \
	timer_z->elapsed += ((double)(num))/((double)timer_z->freq);
#else
#define SEtc_add( timer_z , num )  
#endif

	
#define endflash(cpu_v) cpu_v->mem_c->step=0;

#define addschar(address_m, offset_m) ( ( (unsigned short) address_m ) + ( (char) offset_m ) )


#define index_ext(hlcase,ixcase,iycase) \
if (!cpu->prefix) { \
	hlcase \
} else if (cpu->prefix == 0xDD) { \
	ixcase \
} else { \
	iycase \
}

#endif
