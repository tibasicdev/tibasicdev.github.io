#ifndef LCD_H
#define LCD_H

#include "core.h"

#define X_DEC	4
#define X_INC	5
#define Y_DEC	6
#define Y_INC	7
#define X_screen_offset 62
#define Y_screen_offset 77

#define LCD_busy 	0x80
#define LCD_counter 0x02
#define LCD_mode	0x01
#define LCD_display	0x20
#define LCD_word	0x40
#define LCD_reset	0x10

#define LCD_MEM_WIDTH	16
#define LCD_PIX_WIDTH	(LCD_MEM_WIDTH*8)
#define LCD_HEIGHT		64
#define LCD_HIEGHT		LCD_HEIGHT


#define MAX_LCD_SHADES	7

#define BASE_LEVEL_83PSE	50
#define BASE_LEVEL_83P		56
#define BASE_LEVEL_83		40
#define AVG_SIZE			16


#define STEADY_FREQ		0
#define PERFECT_GRAY	1

#define DISPLAY_SIZE	1024
#define LCDSTACK_SIZE	(MAX_LCD_SHADES+1)

#define LcdOffSet( NumX, NumY, NumZ)  (((((NumY)+(NumZ))%(LCD_HEIGHT))*(LCD_MEM_WIDTH))+((NumX)%(LCD_MEM_WIDTH)))

typedef struct LCD {
	BOOL active;					/* TRUE = on, FALSE = off */
	BOOL dummy;
	unsigned int word_len;	
	unsigned int x, y, z;
	unsigned int mode;				/* LCD increment or decrement */
	unsigned int contrast;			/* 0 to 63 */
	unsigned int base_level;		/* used in lcd level to handle contrast */
	unsigned char display[1024];
	unsigned char * lcdstack[LCDSTACK_SIZE];/* holds previous buffers for grey */
	unsigned char screen[128*64];	/*actual screen for final drawing*/
	unsigned char gif[128*64];		/*for rendering limited color gifs*/
	unsigned int shades;			/* number of shades of grey*/
	unsigned int type;				/* type of lcd emulation */
	double lcdtimewait;				/* longest time between lcd updates */
	double lcdtime;					/* Last lcd update */
	double ufps_last;				/* Last time the upper left cornner was updated */
	double ufps;						/* User frames per second*/
//	double ufps_float;
	double ufps_length;	
//	double ufps_avg[AVG_SIZE+12];
	double lastgifframe;
} LCD_t;

void LCD_command(CPU_t*, device_t*);
void LCD_data(CPU_t *, device_t *);
LCD_t* LCD_init(CPU_t*,int);
unsigned char * LevelLCD( CPU_t * );
int pushbuffer(LCD_t *);
unsigned char* GIFGREYLCD();
unsigned char* GIFBWLCD();
#endif /* #ifndef LCD_H */
