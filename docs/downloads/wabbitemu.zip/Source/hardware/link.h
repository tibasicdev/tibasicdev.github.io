#ifndef LINK_H
#define LINK_H
#include "core.h"
#include "var.h"
#include "sound.h"

typedef struct LINK {
	unsigned char host;				// what we wrote to the link port
	unsigned char * client;			//what they wrote to the link port
	AUDIO_t audio;
} LINK_t;

typedef struct {
	int apps;
	char names[96][9];
	int pagestart[96];
	int pages[96];
} APPLIST_t;


typedef struct {
	unsigned char ObjType;
	unsigned char Resevered[2];
	unsigned short Address;
	unsigned char Page;
	unsigned char NameLength;
	unsigned char Name[9];
} SYMBOLS83P_t;


typedef struct {
	int Total;
	int ProgStart;
	SYMBOLS83P_t SymTab[512];
} SYMLIST_t;



//Because typing this out all the time is annoying
#define PortRead (((out&0x03)|(in[0]&0x03))^3)

// atleast 2 seconds per bit.
#define TIMEOUT 10000000

// Wait between sent commands
#define TWAIT (0.00003f)

// Wait between sent flash commands
#define FWAIT (0.00003f)

//Just a general link error
#define ERR_LINK	-1

//Time out error
#define ERR_TIMEOUT	 -2

//Force load could not complete;
#define ERR_FLOAD	 -3

//If there the calc is out of ram
#define ERR_MEM	 3

//sends based on current flag settings
#define SEND_CUR 0

//sends to ram, regardless of flag settings
#define SEND_RAM 1

//senfs to archive, regardless of flag settings
#define SEND_ARC 2


int init_link(CPU_t * );
int sendbyte(CPU_t * , unsigned char , unsigned short * );
int recbyte(CPU_t * );
int waiting(CPU_t * );
int linkwait(int, double );
/*
int RTS(CPU_t * cpu, TIFILE_t * tifile, int, int );
int RecAck(CPU_t *);
int RecData(CPU_t *);
int RecDataReady(CPU_t *);
int SendAck(CPU_t *);
int ChkReady(CPU_t *);
int ReqVer(CPU_t * );
int senddata(CPU_t *, TIFILE_t *, int);
int EndTrans(CPU_t *);
int SendCTS(CPU_t *);
int DirReq(CPU_t *);
int SendFlashHeader(CPU_t * , int , int);
int SendFlashData(CPU_t * , unsigned char *  , int , int );
*/

int end82send(int );
int sendvar(int, TIFILE_t *, int);
int sendapp(int, TIFILE_t *);
int ForceLoad(int , TIFILE_t * );
int dorequest(CPU_t *);


void AppList(int);
SYMLIST_t* GetSymbols(int);
char* GetRealAns(int slot);

#endif

