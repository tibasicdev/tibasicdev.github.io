#ifndef TI83PHW_H
#define TI83PHW_H
#include "core.h"
#include "stdint.h"


#define NumElm(array) (sizeof (array) / sizeof ((array)[0]))



STDINT_t *INT83P_init(CPU_t*);
int device_init_83p(CPU_t*);
int memory_init_83p(memc *);

void port0(CPU_t *, device_t *);
void port2(CPU_t *, device_t *);
void port3(CPU_t *, device_t *);
void port4(CPU_t *, device_t *);
void port6(CPU_t *, device_t *);
void port7(CPU_t *, device_t *);
void port14(CPU_t *, device_t *);
void flashwrite83p(CPU_t *, unsigned short , unsigned char );

#endif 
