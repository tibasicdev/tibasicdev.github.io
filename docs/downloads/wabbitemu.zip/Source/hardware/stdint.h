#ifndef STDINT_H
#define STDINT_H



typedef struct STDINT {
	unsigned char intactive;
	double lastchk1;
	double timermax1;
	double lastchk2;
	double timermax2;
	double freq[4];
	int mem;
	int xy;	
} STDINT_t;




#endif
