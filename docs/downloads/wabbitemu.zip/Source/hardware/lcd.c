#include "lcd.h"
#include "gifhandle.h"
#include "windows.h"
#include "calc.h"
//#include "gui.h"
static BITMAP *bm_display;
static int white;
static int black;


LCD_t* LCD_init(CPU_t* cpu, int model) {
	int i;
	LCD_t* lcd = malloc(sizeof(LCD_t));
	if (!lcd) {
		printf("Couldn't allocate memory for LCD\n");
		exit(1);
	}
	
	lcd->active = FALSE;
	lcd->dummy = FALSE;
	lcd->word_len = 8;
	lcd->x = 0;
	lcd->y = 0;
	lcd->z = 0;
	lcd->mode = 5;
	lcd->contrast = 32;	

	switch(model) {
		case TI_82:
		case TI_83:
			lcd->base_level = BASE_LEVEL_83;
			break;
		case TI_73:
		case TI_83P:
			lcd->base_level = BASE_LEVEL_83P;
			break;
		case TI_83PSE:
			lcd->base_level = BASE_LEVEL_83PSE;
			break;
		default:
			lcd->base_level = BASE_LEVEL_83P;
			break;
	}
	for(i=0;i<1024;i++) lcd->display[i] = 0;
	for(i=0;i<LCDSTACK_SIZE;i++) lcd->lcdstack[i] = NULL;
	for(i=0;i<128*64;i++) lcd->screen[i] = 0x20;
	lcd->shades = MAX_LCD_SHADES;
	lcd->type = 1;
	lcd->lcdtime = cpu->timer_c->elapsed;
	lcd->lcdtimewait = 1.0f/50.0f;
	lcd->ufps_last = cpu->timer_c->elapsed;
	lcd->ufps = 0;
//	lcd->ufps_float = 0;
	lcd->ufps_length =0;
	lcd->lastgifframe = cpu->timer_c->elapsed;
	return lcd;
}

void LCD_command(CPU_t *cpu, device_t *dev) {
	LCD_t *lcd = dev->aux;
	if (cpu->output) {
		switch (cpu->bus) {
			case 0:
				lcd->word_len = 6;
				break;
			case 1:
				lcd->word_len = 8;
				break;
			case 2:
				lcd->active = FALSE;
				break;
			case 3:
				lcd->active = TRUE;
				break;
			default:
				if (cpu->bus < 0x08) {
					lcd->mode = cpu->bus;
				} else
				if (cpu->bus < 0x18) {
					// Op amp
				} else
				if (cpu->bus < 0x20) {
					// Test mode
				} else
				if (cpu->bus < 0x34) {
					lcd->dummy = TRUE;
					if (lcd->word_len == 8) {
						if (cpu->bus < 0x2F) lcd->y = (cpu->bus - 0x20)%32;
					} else {
						lcd->y = (cpu->bus - 0x20)%32;
					}
				} else
				if (cpu->bus < 0x40) {
					// Out of Bounds Y
				} else
				if (cpu->bus < 0x80) {
					lcd->z = cpu->bus - 0x40;
				} else
				if (cpu->bus < 0xC0) {
					lcd->dummy = TRUE;
					lcd->x = cpu->bus - 0x80;
				} else {
					lcd->contrast = cpu->bus - 0xC0;
				}
		}
		cpu->output = FALSE;
	} else if (cpu->input) {
		cpu->bus =  (lcd->mode & 0x03 ) + ((lcd->active==TRUE)?32:0) + ((lcd->word_len==8)?64:0);
		cpu->input = FALSE;
	}

}

void LCD_data(CPU_t *cpu, device_t *dev) {
	LCD_t *lcd = dev->aux;

	if (cpu->output) {
		if (lcd->word_len == 8) {
			if (lcd->x < 64 && lcd->y < LCD_MEM_WIDTH) lcd->display[LcdOffSet(lcd->y,lcd->x,lcd->z)] = cpu->bus;
			 
		} else if (lcd->word_len == 6) {
			int new_y = (lcd->y*6);
			int shift = new_y % 8;
			unsigned short 	data = cpu->bus,
							mask = 0x003F;
			new_y/=8;
			data <<= 10 - shift;
			mask <<= 10 - shift;
			mask = ~mask;
			lcd->display[LcdOffSet(new_y,lcd->x,lcd->z)] &= mask >> 8;
			lcd->display[LcdOffSet(new_y,lcd->x,lcd->z)] |= data >> 8;
			lcd->display[LcdOffSet(new_y+1,lcd->x,lcd->z)] &= mask & 0xFF;
			lcd->display[LcdOffSet(new_y+1,lcd->x,lcd->z)] |= data & 0xFF;			
		}
		
		
		
		if (lcd->x==0 && lcd->y==0) {
			int i;
			lcd->ufps_length = ( cpu->timer_c->elapsed - lcd->ufps_last );
			if (lcd->ufps_length>=(2.0f)) {
				lcd->ufps = 0;
			} else {
				lcd->ufps = (1.0f / lcd->ufps_length);
			}
			lcd->ufps_last = cpu->timer_c->elapsed;
			if (( lcd->type == PERFECT_GRAY ) && ( lcd->ufps>20 )) {
				pushbuffer(lcd);
				if (lcd->ufps<45) {
					pushbuffer(lcd);
					pushbuffer(lcd);
				}

				lcd->lcdtime =cpu->timer_c->elapsed;
			}
		}
		
		switch (lcd->mode) {
			case X_INC:
				lcd->x = (lcd->x + 1) % 64;
				break;
			case X_DEC:
				lcd->x = (lcd->x - 1) % 64;
				break;
			case Y_INC:
				lcd->y = (lcd->y+1)%32;		//not sure what this should be
				break;
			case Y_DEC:
				lcd->y = (lcd->y-1)%32;
				break;
		}	
		cpu->output = FALSE;
	} else if (cpu->input) {
		if (!lcd->dummy) {	
			if (lcd->word_len == 8) {
				 if (lcd->x < 64 && lcd->y < LCD_MEM_WIDTH)  cpu->bus = lcd->display[LcdOffSet(lcd->y,lcd->x,lcd->z)];
				 else cpu->bus = 0;
			} else if (lcd->word_len == 6) {
				int new_y = (lcd->y*6);
				int shift = new_y % 8;
				unsigned short data = 0;
				
				new_y/=8;
				data = lcd->display[LcdOffSet(new_y,lcd->x,lcd->z)]<<8;
				data |= lcd->display[LcdOffSet(new_y+1,lcd->x,lcd->z)] & 0xFF;
				data >>= (10-shift);
				data &= 0x3F;
				cpu->bus=data;
			}
			
			switch (lcd->mode) {
				case X_INC:
					lcd->x = (lcd->x + 1) % 64;
					break;
				case X_DEC:
					lcd->x = (lcd->x - 1) % 64;
					break;
				case Y_INC:
					lcd->y = (lcd->y+1)%32;		//not sure what this should be
					break;
				case Y_DEC:
					lcd->y = (lcd->y-1)%32;
					break;
			}
		}
		lcd->dummy = FALSE;
		cpu->input = FALSE;
	}
	


		
	if ((cpu->timer_c->elapsed-lcd->lcdtime) >= lcd->lcdtimewait){
		pushbuffer(lcd);
		lcd->lcdtime +=lcd->lcdtimewait;
		if ( (cpu->timer_c->elapsed-lcd->ufps_last) > lcd->ufps_length*2 ) {
			lcd->ufps_length = ( cpu->timer_c->elapsed - lcd->ufps_last );

			if (lcd->ufps_length>=(2.0f)) {
				lcd->ufps = 0;
			} else {
				lcd->ufps = (1.0f / lcd->ufps_length);
			}
		}

	}
	
	if ( (cpu->timer_c->elapsed - lcd->lastgifframe) >= 0.01f ){
		handle_screenshot();
		lcd->lastgifframe += 0.01f;
	}
	
}


int pushbuffer(LCD_t *lcd) {
	int i;
	if (lcd->lcdstack[LCDSTACK_SIZE-1] != NULL) free(lcd->lcdstack[LCDSTACK_SIZE-1]);
	for(i=(LCDSTACK_SIZE-1);i>=1;i--) {
		lcd->lcdstack[i] = lcd->lcdstack[i-1];
	}
	lcd->lcdstack[0] = (unsigned char *) malloc(1024);
	for(i=0;i<1024;i++) {
		lcd->lcdstack[0][i] = lcd->display[i];
	}
	return 0;
}
	


unsigned char * LevelLCD( CPU_t * cpu ) {
	LCD_t * lcd = cpu->pio.devices[0x11].aux;
	unsigned int tmp;
	int x,y,i,bit,col;
	for(y=0;y<64;y++) {
		for(x=0;x<128;x++) {
			bit = 7-(x&0x7);
			col = x>>3;
			tmp=0;
			for(i=0;i<(lcd->shades-1);i++) {
				if (lcd->lcdstack[i]) tmp +=((lcd->lcdstack[i][(y*16)+col]>>bit)&0x01);
			}
			if (lcd->contrast < lcd->base_level ) {
				int level = (lcd->base_level - lcd->contrast)*14;
				if (level > 255) lcd->screen[(y*128)+x] =0;
				else lcd->screen[(y*128)+x] = ((tmp*(255-level))/(lcd->shades-1));
			} else {
				int level = (lcd->contrast - lcd->base_level)*22;
				if (level > 255) lcd->screen[(y*128)+x] =0xFF;
				else lcd->screen[(y*128)+x] = ((tmp*(255-level))/(lcd->shades-1))+level;
			}
		}
	}
	return lcd->screen;
}
	
	
unsigned char* GIFGREYLCD() {
	LCD_t* lcd = calcs[gslot].cpu.pio.lcd;
	unsigned int tmp;
	int x,y,i,bit,col;
	for(y=0;y<64;y++) {
		for(x=0;x<LCD_PIX_WIDTH;x++) {
			bit = 7-(x&0x7);
			col = x>>3;
			tmp=0;
			for(i=0;i<(lcd->shades-1);i++) {
				if (lcd->lcdstack[i]) tmp +=((lcd->lcdstack[i][(y*LCD_MEM_WIDTH)+col]>>bit)&0x01);
			}
			lcd->gif[(y*LCD_PIX_WIDTH)+x] = tmp;
		}
	}
	return lcd->gif;
}
unsigned char* GIFBWLCD() {
	LCD_t* lcd = calcs[gslot].cpu.pio.lcd;
	unsigned int tmp;
	int x,y,i,bit,col;
	for(y=0;y<64;y++) {
		for(x=0;x<LCD_PIX_WIDTH;x++) {
			bit = 7-(x&0x7);
			col = x>>3;
			if (lcd->lcdstack[i]) tmp =((lcd->lcdstack[0][(y*LCD_MEM_WIDTH)+col]>>bit)&0x01);
			lcd->gif[(y*LCD_PIX_WIDTH)+x] = tmp*6;
		}
	}
	return lcd->gif;
}













