#include "link.h"
#include "core.h"
#include "calc.h"
#include "var.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>

static int linkinit = 0;
static unsigned char out;
static unsigned char * in;
static unsigned char * old;

//*******************************************************
//Start of low level

//------------------------------------
//Link the calc to to virtual PC.
int init_link(CPU_t * cpu) {
	LINK_t * link = cpu->pio.devices[0].aux;
	out = 0;
	link->client = &out;
	in = &link->host;
	return 0;
}


int isinit(CPU_t * cpu) {
	LINK_t * link = cpu->pio.link;
	if (link->client != &out) {
		puts("NOt init");
		return 0;
	}
	if ( in != &link->host) {
		puts("NOt init");
		return 0;
	}
	return 1;
}
	
	

//------------------------
//Check if calc is wait to send something
int waiting(CPU_t * cpu ) {
	if (!isinit(cpu)) return FALSE;
	if (PortRead == 3) return FALSE;
	else return TRUE;
}

//------------------------------
//Waits for a few seconds or untill 
//the calc wants to send something
int linkwait(int slot, double timewait ) {
	CPU_t* cpu = &calcs[slot].cpu;
	if (!isinit(cpu)) return;
	int i;
	double timestart = cpu->timer_c->elapsed;
	while(((cpu->timer_c->elapsed - timestart)<timewait) && (PortRead==3) ) {
		CPU_step(cpu);
	}
//	printf("\n");
}

//--------------------------------
//send a byte
int sendbyte(CPU_t * cpu, unsigned char byte , unsigned short * chksum) {
	int b,i;
	if (!isinit(cpu)) return ERR_LINK;
	if (chksum) chksum[0] += byte;	
//	printf("PC out %02x\n",byte);
	for(b=0;b<8;b++) {
		if (byte & 1) out = 2;
		else out =1;
		for(i=0;i<TIMEOUT && (PortRead!=0); i++) {
			CPU_step(cpu);
		}
		if (PortRead!=0) {
			return ERR_TIMEOUT;
		}
		out =0;
		for(i=0;i<TIMEOUT && (PortRead!=3); i++) {
			CPU_step(cpu);
		}
		if (PortRead!=3) {
			return ERR_TIMEOUT;
		}
		byte>>=1;
	}
	return 0;
}

//---------------------
//Receive a byte
int recbyte(CPU_t * cpu ) {
	int b,i;
	unsigned char byte=0;
	if (!isinit(cpu)) return ERR_LINK;
	for(b=0;b<8;b++) {
//		printf("%1d : Step 1: %d  ",b,PortRead);
		for(i=0; (i<TIMEOUT) && (PortRead==3); i++) {
			CPU_step(cpu);
		}
		byte>>=1;
		if (PortRead == 0) {
			puts("error link");
			 return ERR_LINK;
		} else if (PortRead == 1) {
			byte +=0x080; 
			out = 1;
		} else if (PortRead == 2) {
			out = 2;
		} else if (PortRead == 3) {
			puts("error time out");
			 return ERR_TIMEOUT;
		}
//		printf("Step 2: %d  \n",PortRead);
		for(i=0; (i<TIMEOUT) && (PortRead==0); i++) {
			CPU_step(cpu);
		}
		if (PortRead == 0) {
			 return ERR_TIMEOUT;
		} else if (PortRead > 0) {
			 out = 0;
		}
	}
//	printf("PC in %02x\n",byte);
	return byte;
}


//End of low level
//*******************************************************




//*******************************************************
//Start of commands

//------------------------
//Send machine ID
int SendMachineID(int slot) {
	CPU_t* cpu = &calcs[slot].cpu;
	int err;
	switch(calcs[slot].model) {
		case TI_73:
			err = sendbyte(cpu,0x07,NULL);
			break;
		case TI_82:
			err = sendbyte(cpu,0x02,NULL);
			break;
		case TI_83:
			err = sendbyte(cpu,0x03,NULL);
			break;
		case TI_83P:
		case TI_83PSE:
		case TI_84P:
		case TI_84PSE:
			err = sendbyte(cpu,0x23,NULL);
			break;
		default:
			err = ERR_LINK;
			break;
	}
	return err;
}
	


//------------------------
// Request to Send 
int RTS(int slot, TIFILE_t * tifile, int ram) {
	CPU_t* cpu = &calcs[slot].cpu;
	unsigned short chksum = 0;
	int err,i;
	unsigned char * ptr;
	err = SendMachineID(slot);
	if (err != 0) return err;
	if (calcs[slot].model == TI_82) {
		err = sendbyte(cpu,0x06,NULL);
		if (err != 0) return err;
	} else {
		err = sendbyte(cpu,0xC9,NULL);
		if (err != 0) return err;
	}
	err = sendbyte(cpu,((calcs[slot].model>=TI_83P)?0x0D:0x0B),NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,tifile->var->length&0xFF,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,(tifile->var->length>>8)&0xFF,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,tifile->var->vartype,&chksum);
	if (err != 0) return err;
	for(i=0;i<8;i++) {
		err = sendbyte(cpu,tifile->var->name[i],&chksum);
		if (err != 0) return err;
	}
	if (calcs[slot].model >= TI_83P) {
		err = sendbyte(cpu,tifile->var->version,&chksum);
		if (err != 0) return err;
		if (ram == 1) {
			err = sendbyte(cpu,0,&chksum);
			if (err != 0) return err;
		} else 	if (ram == 2) {
			err = sendbyte(cpu,0x80,&chksum);
			if (err != 0) return err;
		} else {
			err = sendbyte(cpu,tifile->var->flag,&chksum);
			if (err != 0) return err;
		}
	}
	err = sendbyte(cpu,chksum&0xFF,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,(chksum>>8)&0xFF,NULL);
	if (err != 0) return err;
	return 0;
}

int RTSbackup(int slot, TIFILE_t * tifile) {
	CPU_t* cpu = &calcs[slot].cpu;
	unsigned short chksum = 0;
	int err,i;
	unsigned char * ptr;
	err = SendMachineID(slot);
	if (err != 0) return err;
	if (calcs[slot].model == TI_82) {
		err = sendbyte(cpu,0x06,NULL);
		if (err != 0) return err;
	} else {
		err = sendbyte(cpu,0xC9,NULL);
		if (err != 0) return err;
	}
	err = sendbyte(cpu,0x09,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;

	err = sendbyte(cpu,tifile->backup->length1&0xFF,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,(tifile->backup->length1>>8)&0xFF,&chksum);
	
	if (err != 0) return err;
	err = sendbyte(cpu,tifile->backup->vartype,&chksum);
	
	err = sendbyte(cpu,tifile->backup->length2&0xFF,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,(tifile->backup->length2>>8)&0xFF,&chksum);
	
	err = sendbyte(cpu,tifile->backup->length3&0xFF,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,(tifile->backup->length3>>8)&0xFF,&chksum);
	
	err = sendbyte(cpu,tifile->backup->address&0xFF,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,(tifile->backup->address>>8)&0xFF,&chksum);
	

	err = sendbyte(cpu,chksum&0xFF,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,(chksum>>8)&0xFF,NULL);
	if (err != 0) return err;
	return 0;
}

//------------------------
// send flash header crap....
int SendFlashHeader(int slot, int offset , int page) {
	CPU_t* cpu = &calcs[slot].cpu;
	unsigned short chksum = 0;
	int err;
	err = SendMachineID(slot);
	if (err != 0) return err;
	err = sendbyte(cpu,0x06,NULL);		//0xC9
	if (err != 0) return err;
	err = sendbyte(cpu,0x0A,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,0x80,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,0x24,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,0xFF,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,offset&0xFF,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,(offset>>8)&0xFF,&chksum);
	if (err != 0) return err;	
	err = sendbyte(cpu,page&0xFF,&chksum);
	if (err != 0) return err;
	err = sendbyte(cpu,(page>>8)&0xFF,&chksum);
	if (err != 0) return err;	
	err = sendbyte(cpu,chksum&0xFF,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,(chksum>>8)&0xFF,NULL);
	if (err != 0) return err;
	return 0;
}


//------------------------
// send data
int SendData(int slot, unsigned char * buffer , int size) {
	CPU_t* cpu = &calcs[slot].cpu;
	unsigned short chksum = 0;
	int err,i;
	err = SendMachineID(slot);
	if (err != 0) return err;
	err = sendbyte(cpu,0x15,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,size&0x0FF,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,(size>>8)&0x0FF,NULL);
	if (err != 0) return err;
	for(i=0; i<size ; i++ ) {
		err = sendbyte(cpu,buffer[i],&chksum);
		if (err != 0) return err;
		calcs[slot].BytesSent++;
	}
	err = sendbyte(cpu,chksum&0xFF,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,(chksum>>8)&0xFF,NULL);
	if (err != 0) return err;
	return 0;
}

//--------------------------------
//receive acknowledgement
int RecAck(int slot) {
	CPU_t* cpu = &calcs[slot].cpu;
	int read;
	read = recbyte(cpu);
	if (read < 0) return read;
	read = recbyte(cpu);
	if (read  != 0x56) return ERR_LINK;
	read = recbyte(cpu);
	if (read < 0) return read;
	read = recbyte(cpu);
	if (read  < 0) return read;
	return 0;
}

//-----------------------------------
// Receive data not exactly perfect.
int RecData(int slot) {
	CPU_t* cpu = &calcs[slot].cpu;
	int read,i;
	unsigned short length;
	read = recbyte(cpu);
	if (read < 0) return read;
	read = recbyte(cpu);
	if ((read  != 0x92) &&
	 	(!(read < 0)) ) {
		read = recbyte(cpu);
		if (read < 0) return read;
		length = read&0xFF;
		read = recbyte(cpu);
		if (read < 0) return read;
		length += ((read&0xFF)<<8);
		if (length==0) return 0;
		for(i=0;i<length;i++) {
			read = recbyte(cpu);
			if (read < 0) return read;
		}
		read = recbyte(cpu);
		if (read < 0) return read;
		read = recbyte(cpu);
		if (read < 0) return read;
		return 0;
	} else if (read  == 0x92) {
		read = recbyte(cpu);
		if (read < 0) return read;
		read = recbyte(cpu);
		if (read < 0) return read;
		return 1;
	} else if (read < 0) return read;
	return ERR_LINK;
}


//----------------------------------
// Ready to recieve data or is there an error?
int RecDataReady(int slot) {
	CPU_t* cpu = &calcs[slot].cpu;
	int read,err;
	read = recbyte(cpu);
	if (read < 0) return read;
	read = recbyte(cpu);
	if (read  == 0x09) {
		int size,i;
		read = recbyte(cpu);
		if (read < 0) return read;
		size = read;
		read = recbyte(cpu);
		if (read  < 0) return read;
		size += (read&0xFF)<<8;
/*		for(i=0;i<size;i++) {
			read = recbyte(cpu);
			if (read  < 0) return read;
		}*/
		return 0;
	} else if (read == 0x36) {
		read = recbyte(cpu);
		if (read != 1) return ERR_LINK;
		read = recbyte(cpu);
		if (read  != 0) return ERR_LINK;
		read = recbyte(cpu);
		if (read < 0) return ERR_LINK;
		if (read > 3) return ERR_LINK;
		err = read;
		read = recbyte(cpu);
		if (read < 0) return ERR_LINK;
		read = recbyte(cpu);
		if (read  != 0) return ERR_LINK;
		return err;
	} else if (read < 0) return read;
	return ERR_LINK;
}
	
//------------------------
// Send acknowledge
int SendAck(int slot) {
	CPU_t* cpu = &calcs[slot].cpu;
	int err;
	err = SendMachineID(slot);
	if (err != 0) return err;
	err = sendbyte(cpu,0x56,NULL);
	if (err != 0) return err;	
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	return 0;
}

//------------------------
// Checks if the calc is ready.
int ChkReady(int slot) {
	CPU_t* cpu = &calcs[slot].cpu;
	int err;
	err = SendMachineID(slot);
	if (err != 0) return err;
	err = sendbyte(cpu,0x68,NULL);
	if (err != 0) return err;	
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	return 0;
}

//------------------------
// Request version...does nothing.
int ReqVer(int slot) {
	CPU_t* cpu = &calcs[slot].cpu;
	int err;
	err = SendMachineID(slot);
	if (err != 0) return err;
	err = sendbyte(cpu,0x2D,NULL);
	if (err != 0) return err;	
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	return 0;
}


//--------------------------
//Send End of transmission
int EndTrans(int slot) {
	CPU_t* cpu = &calcs[slot].cpu;
	int err;
	err = SendMachineID(slot);
	if (err != 0) return err;
	err = sendbyte(cpu,0x92,NULL);
	if (err != 0) return err;	
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	return 0;
}

//------------------------
// Send Clear to Send...
int SendCTS(int slot) {
	CPU_t* cpu = &calcs[slot].cpu;
	int err;
	err = SendMachineID(slot);
	if (err != 0) return err;
	err = sendbyte(cpu,0x09,NULL);
	if (err != 0) return err;	
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	return 0;
}

//---------------------------
// Directory request command
int DirReq(int slot) {
	CPU_t* cpu = &calcs[slot].cpu;
	int err,i;
	err = SendMachineID(slot);
	if (err != 0) return err;
	err = sendbyte(cpu,0xA2,NULL);
	if (err != 0) return err;	
	err = sendbyte(cpu,0x0b,NULL);
	if (err != 0) return err;
	for(i=0;i<3;i++) {
		err = sendbyte(cpu,0x00,NULL);
		if (err != 0) return err;
	}
	err = sendbyte(cpu,0x19,NULL);
	if (err != 0) return err;
	for(i=0;i<8;i++) {
		err = sendbyte(cpu,0x00,NULL);
		if (err != 0) return err;
	}
	err = sendbyte(cpu,0x19,NULL);
	if (err != 0) return err;
	err = sendbyte(cpu,0x00,NULL);
	if (err != 0) return err;
	return 0;
}

// Commands END
//**************************************************************************




//**************************************************************************
// Functions begin



int end82send(int slot){
	if (!isinit(&calcs[slot].cpu)) return 0;
	int err = EndTrans(slot);
	if (err!=0) return err;
	err = RecAck(slot);
	return err;
}


//---------------------------------
// Sends a var to calc
//83+ only
int sendvar(int slot, TIFILE_t * tifile, int ram) {
	CPU_t* cpu = &calcs[slot].cpu;
	int err;
	init_link(cpu);
	calcs[slot].BytesSent = 0;
	//Turn calc on if off
	if (calcs[slot].cpu.pio.lcd->active == FALSE) {
		puts("calc is off");
		linkwait(slot,0.50f);
		cpu->pio.keypad->on_pressed |= KEY_FALSEPRESS;
		linkwait(slot,0.5f);
		cpu->pio.keypad->on_pressed &= ~KEY_FALSEPRESS;
		linkwait(slot,1.0f);
		if (calcs[slot].cpu.pio.lcd->active == FALSE) {
			puts("calc is still off");
		}
	}
	//if flash use that protocol
	if (tifile->type == FLASH_TYPE) {
		err = ForceLoad(slot, tifile);
		linkwait(slot, 1.75f );
		return err;
	}

	if (tifile->type == BACKUP_TYPE) {
		return SendBackup(slot, tifile);
	}
	
	// Only other type is rom and its not supported
	if (tifile->type != VAR_TYPE) return ERR_LINK;
	calcs[slot].SendSize = tifile->length;
	err =RTS(slot, tifile,ram);
	if (err!=0) return err;

	linkwait(slot, TWAIT );
	err = RecAck(slot);
	if (err!=0) return err;
	linkwait(slot, TWAIT );
	err = RecDataReady(slot);
	if ( err > 0 ) {
		int saveerr = err;
		linkwait(slot, TWAIT );
		err = SendAck(slot);
		if (err!=0) return err;
		return saveerr;
	} else if (err<0) return err;
	linkwait(slot, TWAIT );
	err = SendAck(slot);
	if (err!=0) return err;
	linkwait(slot, TWAIT );
	err = SendData(slot,tifile->var->data,tifile->var->length);
	if (err!=0) return err;
	linkwait(slot, TWAIT );
	err = RecAck(slot);
	if (err!=0) return err;
	linkwait(slot, TWAIT );
	if ( calcs[slot].model != TI_82) {
		err = EndTrans(slot);
		if (err!=0) return err;
	}
	return 0;
}

//---------------------------------
// Sends a app to calc
//83+ only
int sendapp(int slot, TIFILE_t * tifile) {
	CPU_t* cpu = &calcs[slot].cpu;
	int err,i,page,offset;
	TIFLASH_t * flash = tifile->flash;		//so I don't type as much
	FILE * fp;
	err = ReqVer(slot);
	if (err!=0) return err;
	err = RecAck(slot);
	if (err!=0) return err;
	linkwait(slot,FWAIT);
	err = SendCTS(slot);
	if (err!=0) return err;
	err = RecAck(slot);
	if (err!=0) return err;
	for (i = 0; i < 17; i++) {
		if (err=recbyte(cpu) < 0) return err;
	}
	linkwait(slot,FWAIT);
	err = SendAck(slot);
	if (err!=0) return err;
	err = ChkReady(slot);
	if (err!=0) return err;
	err = RecAck(slot);
	if (err!=0) return err;	

	calcs[slot].SendSize=0;
	for(i=0;i<flash->pages;i++){
		calcs[slot].SendSize +=flash->pagesize[i];
	}
	for (page = 0; page < flash->pages ; page++) {
		for( offset = 0x4000;
			 ( offset < 0x8000 ) && ((offset-0x4000)<flash->pagesize[page]);
			 offset += 0x80) {
			linkwait(slot,FWAIT);
			err = SendFlashHeader(slot,offset,page);
			if (err!=0) return err;
			err = RecAck(slot);
			if (err!=0) return err;
			err = RecDataReady(slot);
			if ( err > 0 ) {
				int saveerr = err;
				linkwait(slot, FWAIT );
				err = SendAck(slot);
				if (err!=0) return err;
				return saveerr;
			} else if (err<0) return err;
			linkwait(slot,FWAIT);
			err = SendAck(slot);
			if (err!=0) return err;
			err = SendData(slot,flash->data[page]+(offset-0x4000),0x80);
			if (err!=0) return err;
			if ( offset==0x4000 && !page ) linkwait(slot,14.0f);	//garabage collect shouldn't really matter
			err = RecAck(slot);
			if (err!=0) return err;
		}
	}
	puts("Page sending done");
	linkwait(slot, TWAIT );
	err = EndTrans(slot);
	if (err!=0) return err;
	puts("EOT done");	
	linkwait(slot, TWAIT );
	err = RecAck(slot);
	if (err!=0) return err;	
	puts("Ack rec");
	return 0;
}

//---------------------------------
// Force load app
//83+ only
int ForceLoad(int slot, TIFILE_t * tifile) {
	int b,i,err=0;
	int pagestart,pageend;
	unsigned char * mem = calcs[slot].mem_c.flash;
	TIFLASH_t * app = tifile->flash;
	if (calcs[slot].model < TI_73 ) return ERR_LINK;
		// Forceload works without reset.
//	return sendapp(slot,tifile);
	
	switch(calcs[slot].model) {
		case TI_73:
			pagestart	= TI_73_APPPAGE * 0x4000;
			pageend		= pagestart - (TI_73_USERPAGES * 0x4000);
			break;
		case TI_83P:
			pagestart	= TI_83P_APPPAGE * 0x4000;
			pageend		= pagestart - (TI_83P_USERPAGES * 0x4000);
			break;
		case TI_83PSE:
			pagestart	= TI_83PSE_APPPAGE * 0x4000;
			pageend		= pagestart - (TI_83PSE_USERPAGES * 0x4000);
			break;
		case TI_84P:
			pagestart	= TI_84P_APPPAGE * 0x4000;
			pageend		= pagestart - (TI_84P_USERPAGES * 0x4000);
			break;
		case TI_84PSE:
			pagestart	= TI_84PSE_APPPAGE * 0x4000;
			pageend		= pagestart - (TI_84PSE_USERPAGES * 0x4000);
			break;
		default:
			return 0;
	}
	
	calcs[slot].SendSize=tifile->flash->pages;
	calcs[slot].BytesSent =0;
	for( i=pagestart; mem[i]==0x80 && mem[i+1]==0x0F && i>=((app->pages*0x4000)+pageend);) {
		if ( memcmp( mem+i+0x12 , app->data[0]+0x12 , 8) == 0 ) {
			if ( mem[i+0x1C]==app->pages ) {
				for(b=0; b<app->pages; b++ ) {
					memcpy(mem+i,app->data[b],16384);
					i-=0x4000;
					calcs[slot].BytesSent++;
				}
				return 0;
			}else {
				return ERR_FLOAD;
			}
		} else {
			i -=(mem[i+0x1C]*0x4000);	
		}
	}
	if (  i < ((app->pages*0x4000)+pageend) ) {
		return ERR_MEM;
	}
	for( b=i; b> i-(app->pages*0x4000); b-- ) {
		if (mem[b+0x3fff] != 0xFF) {
			return ERR_MEM;
		}
	}
	for(b=0; b<app->pages; b++ ) {
		memcpy(mem+i,app->data[b],16384);
		i-=0x4000;
		calcs[slot].BytesSent++;
	}
	sendapp(slot,tifile);	// Forceload works without reset.
	return 0;
}






//----------------------------------
// Sends backup
int SendBackup(int slot,TIFILE_t * tifile) {
	int err;
	calcs[slot].SendSize = tifile->length;
	err =RTSbackup(slot, tifile);
	if (err!=0) return err;
	linkwait(slot, TWAIT );
	err = RecAck(slot);
	if (err!=0) return err;
	linkwait(slot, TWAIT );
	err = RecDataReady(slot);
	if ( err > 0 ) {
		int saveerr = err;
		linkwait(slot, TWAIT );
		err = SendAck(slot);
		if (err!=0) return err;
		return saveerr;
	} else if (err<0) return err;
	linkwait(slot, TWAIT );
	err = SendAck(slot);
	if (err!=0) return err;
	linkwait(slot, TWAIT );
	err = SendData(slot,tifile->backup->data1,tifile->backup->length1);
	if (err!=0) return err;
	linkwait(slot, TWAIT );
	err = RecAck(slot);
	if (err!=0) return err;

	linkwait(slot, TWAIT );
	err = SendData(slot,tifile->backup->data2,tifile->backup->length2);
	if (err!=0) return err;
	linkwait(slot, TWAIT );
	err = RecAck(slot);
	if (err!=0) return err;
	
	linkwait(slot, TWAIT );
	err = SendData(slot,tifile->backup->data3,tifile->backup->length3);
	if (err!=0) return err;
	linkwait(slot, TWAIT );
	err = RecAck(slot);
	if (err!=0) return err;

	linkwait(slot, TWAIT );
	if ( calcs[slot].model != TI_82) {
		err = EndTrans(slot);
		if (err!=0) return err;
	}
	return 0;
}

	
/*
//----------------------
// NOT COMPLETE 
// Dir request
int dorequest(CPU_t * cpu) {
	int err;
	err = DirReq(cpu);
	if (err != 0 ) return err;
	linkwait(cpu, TWAIT );
	err = RecAck(cpu);
	if (err != 0 ) return err;
	linkwait(cpu, TWAIT );
	err = RecData(cpu);
	if (err == 1 ) {
		err = SendAck(cpu);
		if (err!=0) return err;	
		return 0;
	}
	if (err < 0 )  return err;
	linkwait(cpu, TWAIT );
	err = SendAck(cpu);
	if (err!=0) return err;
	linkwait(cpu, TWAIT );
	for(;;) {
		linkwait(cpu, TWAIT );
		err = RecData(cpu);
		if (err == 1 ) {
			linkwait(cpu, TWAIT );
			err = SendAck(cpu);
			if (err!=0) return err;	
			return 0;
		}
		if (err < 0 )  return err;
		linkwait(cpu, TWAIT);
		err = SendAck(cpu);
		if (err!=0) return err;	
	}
}
*/

//---------------------------------
// Generates a list of apps.
void AppList( int slot ) {
	int b,i,err=0;
	unsigned char * mem = calcs[slot].mem_c.flash;
	APPLIST_t* applist = &calcs[slot].applist;
	int pagestart,pageend;
	
	for(b=0;b<97;b++) {
		memset(applist->names[b],0,9);
		applist->pagestart[b]	= -1;
		applist->pages[b]		= -1;
	}
	applist->apps = 0;
	
	switch(calcs[slot].model) {
		case TI_73:
			pagestart	= TI_73_APPPAGE * 0x4000;
			pageend		= pagestart - (TI_73_USERPAGES * 0x4000);
			break;
		case TI_83P:
			pagestart	= TI_83P_APPPAGE * 0x4000;
			pageend		= pagestart - (TI_83P_USERPAGES * 0x4000);
			break;
		case TI_83PSE:
			pagestart	= TI_83PSE_APPPAGE * 0x4000;
			pageend		= pagestart - (TI_83PSE_USERPAGES * 0x4000);
			break;
		case TI_84P:
			pagestart	= TI_84P_APPPAGE * 0x4000;
			pageend		= pagestart - (TI_84P_USERPAGES * 0x4000);
			break;
		case TI_84PSE:
			pagestart	= TI_84PSE_APPPAGE * 0x4000;
			pageend		= pagestart - (TI_84PSE_USERPAGES * 0x4000);
			break;
		default:
			return;
	}
			
	for( i=pagestart; mem[i]==0x80 && mem[i+1]==0x0F && i>=(pageend);) {
		applist->pagestart[applist->apps] = i/0x4000;
		if ( (mem[i+0x10] == 0x80) && (mem[i+0x11] == 0x48) ) {
			memcpy(applist->names[applist->apps],mem+i+0x12,8);
		} else break;
		if ( (mem[i+0x1A] == 0x80) && (mem[i+0x1B] == 0x81) ) {
			applist->pages[applist->apps] = mem[i+0x1C];
		} else break;
		i -=(applist->pages[applist->apps]*0x4000);	
		applist->apps++;
	}
	
	
	
	for(i=0;i<calcs[slot].applist.apps;i++) {
		puts(calcs[slot].applist.names[i]);
	}
	
	
	
	return;
}





#define pTemp		(0x982E)
#define progPtr		(0x9830)
#define symTable	(0xFE66)
SYMLIST_t* GetSymbols(int slot) {
	int i,b;
	SYMLIST_t* sym = malloc(sizeof(SYMLIST_t));
	memc* mem = calcs[slot].cpu.mem_c;
	unsigned short end = (mem_read(mem,pTemp)+(mem_read(mem,pTemp+1)<<8));
	unsigned short prog = (mem_read(mem,progPtr)+(mem_read(mem,progPtr+1)<<8));
	unsigned short ptr = symTable;
	if (ptr<end) {
		free(sym);
		return NULL;
	}
	if (ptr<prog) {
		free(sym);
		return NULL;
	}
	if (prog<end) {
		free(sym);
		return NULL;
	}
	if (end<0x9D95) {
		free(sym);
		return NULL;
	}
	if (prog<0x9D95) {
		free(sym);
		return NULL;
	}
	sym->Total		= 0;
	sym->ProgStart	= 0;
	for(i=0;i<512;i++) {
		sym->SymTab[i].ObjType		= 0;
		sym->SymTab[i].Resevered[0]	= 0;
		sym->SymTab[i].Resevered[1]	= 0;
		sym->SymTab[i].Address		= 0;
		sym->SymTab[i].Page			= 0;
		sym->SymTab[i].NameLength	= 0;
		for(b=0;b<9;b++)
			sym->SymTab[i].Name[b]	= 0;
	}
	i = 0;
	while(ptr > prog) {
		sym->SymTab[i].ObjType		= mem_read(mem,ptr--);
		if ( (sym->SymTab[i].ObjType & 0xE0) != 0 ) {
			free(sym);
			return NULL;
		}
		sym->SymTab[i].Resevered[0]	= mem_read(mem,ptr--);
		sym->SymTab[i].Resevered[1]	= mem_read(mem,ptr--);
		sym->SymTab[i].Address		= (mem_read(mem,ptr)+(mem_read(mem,ptr-1)<<8));
		ptr -=2;
		sym->SymTab[i].Page			= mem_read(mem,ptr--);
		for(b=0;b<3;b++)
			sym->SymTab[i].Name[b]	= mem_read(mem,ptr--);
		i++;
	}
	sym->ProgStart		= i;
	while(ptr > end) {
		sym->SymTab[i].ObjType		= mem_read(mem,ptr--);
		if ( (sym->SymTab[i].ObjType & 0xE0) != 0 ) {
			free(sym);
			return NULL;
		}
		sym->SymTab[i].Resevered[0]	= mem_read(mem,ptr--);
		sym->SymTab[i].Resevered[1]	= mem_read(mem,ptr--);
		sym->SymTab[i].Address		= (mem_read(mem,ptr)+(mem_read(mem,ptr-1)<<8));
		ptr -=2;
		sym->SymTab[i].Page			= mem_read(mem,ptr--);
		sym->SymTab[i].NameLength	= mem_read(mem,ptr--);
		for(b=0;b<sym->SymTab[i].NameLength;b++)
			sym->SymTab[i].Name[b]	= mem_read(mem,ptr--);
		i++;
	}	
	sym->Total		= i;
/*
	printf("Total symbols: %d \n",sym->Total);
	printf("Program Symbol Start: %d \n",sym->ProgStart);
	for(i=0;i<sym->Total;i++) {
		printf("Symbol Number: %d \n",i);
		printf("  ObjType: %02X \n",sym->SymTab[i].ObjType);
		printf("  Reserved: %02X %02X \n",sym->SymTab[i].Resevered[0],sym->SymTab[i].Resevered[1]);
		printf("  Address: %04X \n",sym->SymTab[i].Address);
		printf("  Page: %02X \n",sym->SymTab[i].Page);
		if (i<sym->ProgStart) {
			printf("  Name: ");
			for(b=0;b<3;b++)
				printf("%02X ",sym->SymTab[i].Name[b]);
			printf("\n");
		} else {
			printf("  Name Length: %d \n",sym->SymTab[i].NameLength);
			printf("  Name: ");
			for(b=0;b<sym->SymTab[i].NameLength;b++)
				printf("%c",sym->SymTab[i].Name[b]);
			printf("\n");
		}
	}
	*/
	return sym;
}
			
		
		
	
char* GetRealAns(int slot) {
	memc* mem = calcs[slot].cpu.mem_c;
	SYMLIST_t* sym = GetSymbols(slot);
	char* string = NULL;
	int i,b;
	unsigned short ptr;
	unsigned short size;
	unsigned char Type;
	unsigned char Exp;
	unsigned char FP[8];
	if (sym == NULL) return NULL;
	
	for(i=0;i<sym->ProgStart;i++) {
		if (sym->SymTab[i].Page	 != 0) continue;
		if (sym->SymTab[i].Name[0] != 0x72) continue;
		if (sym->SymTab[i].Name[1] != 0x00) continue;
		if (sym->SymTab[i].Name[2] == 0x00) {
			int pnt = 0;
			if (sym->SymTab[i].ObjType == 4) {
				ptr = sym->SymTab[i].Address;
				size = (mem_read(mem,ptr)+(mem_read(mem,ptr+1)<<8));
				string = LocalAlloc(LMEM_FIXED, size+1);
				ptr+=2;
				for(b=0;b<size;b++) {
					string[b] = mem_read(mem,ptr++);
				}
				string[size] =0;	
				free(sym);
				return string;
			}
			if (sym->SymTab[i].ObjType == 0) {
				string = LocalAlloc(LMEM_FIXED, 128);
				int sigdig;			
				ptr = sym->SymTab[i].Address;
				Type = mem_read(mem,ptr++);
				Exp = mem_read(mem,ptr++);
				for(b=0;b<8;b++) {
					FP[b] = mem_read(mem,ptr++);
				}
				if ( (Type&0x7f) != 0 ) return NULL;			
	
				b=13;
				while(b>=0) {
					if ( (FP[b/2]&0x0F) != 0) break;
					b--;
					if ( (FP[b/2]&0xF0) != 0) break;
					b--;
				}
				if (b<0) {
					string[0]='0';
					string[1]=0;
					free(sym);
					return string;
				}
				sigdig = b+1;
				
				if ((Type&0x80) != 0) {
					string[pnt]='-';
					pnt++;
				}
				
				if ((Exp&0x80) == 0x80) {
					Exp -= 0x80;
					if (Exp<=16) {
						for(b=0;b<(Exp+1) || (b<sigdig);b++) {
							if ( (b%2) == 0 ) {
								string[pnt] = ( ((FP[b/2]&0xF0)>>4) + '0');
							} else {
								string[pnt] = ( (FP[b/2]&0x0F) + '0');
							}
							pnt++;
							if ( (b==Exp) && ((b+1)<sigdig) ) {
								string[pnt++] = '.';
							}
						}
						string[pnt++] = 0;
					} else {
						for(b=0;b<sigdig;b++) {
							if ( (b%2) == 0 ) {
								string[pnt] = ( ((FP[b/2]&0xF0)>>4) + '0');
							} else {
								string[pnt] = ( (FP[b/2]&0x0F) + '0');
							}
							pnt++;
							if ( (b==0) && ((b+1)<sigdig) ) {
								string[pnt++] = '.';
							}
						}
						string[pnt++] = '*';
						string[pnt++] = '1';
						string[pnt++] = '0';
						string[pnt++] = '^';
						if (Exp >=100) {
							string[pnt++] = '1';
							Exp -=100;
						}
						if (Exp >=10) {
							string[pnt++] = ((Exp/10)+'0');
							Exp %=10;
						}
						string[pnt++] = (Exp+'0');
						string[pnt++] = 0;
					}
				} else {
					Exp = (0x7F - Exp);
					if ( (Exp+sigdig)<=16 ) {
						string[pnt++] = '0';
						string[pnt++] = '.';
						for(b=0;b<Exp;b++) {
							string[pnt++] = '0';
						}
						for(b=0;b<sigdig;b++) {
							if ( (b%2) == 0 ) {
								string[pnt] = ( ((FP[b/2]&0xF0)>>4) + '0');
							} else {
								string[pnt] = ( (FP[b/2]&0x0F) + '0');
							}
							pnt++;
						}
						string[pnt++] = 0;
					} else {
						for(b=0;b<sigdig;b++) {
							if ( (b%2) == 0 ) {
								string[pnt] = ( ((FP[b/2]&0xF0)>>4) + '0');
							} else {
								string[pnt] = ( (FP[b/2]&0x0F) + '0');
							}
							pnt++;
							if ( (b==0) && ((b+1)<sigdig) ) {
								string[pnt++] = '.';
							}
						}
						string[pnt++] = '*';
						string[pnt++] = '1';
						string[pnt++] = '0';
						string[pnt++] = '^';
						string[pnt++] = '-';
						Exp++;
						if (Exp >=100) {
							string[pnt++] = '1';
							Exp -=100;
						}
						if (Exp >=10) {
							string[pnt++] = ((Exp/10)+'0');
							Exp %=10;
						}
						string[pnt++] = (Exp+'0');
						string[pnt++] = 0;
					}
				}
			}
			free(sym);
			return string;
		}
	}
	free(sym);
	return NULL;
}

						
						
					

				
				
				
				








