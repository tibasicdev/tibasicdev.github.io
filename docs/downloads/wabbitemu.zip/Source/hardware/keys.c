#include "keys.h"
#include "windows.h"
#include "calc.h"
#include "device.h"

typedef struct KEYPROG {
	int vk;
	int group;
	int bit;
} KEYPROG_t;

static KEYPROG_t keygrps[] = {
	{ 'A' , 5 , 6 },
	{ 'B' , 4 , 6 },
	{ 'C' , 3 , 6 },
	{ 'D' , 5 , 5 },
	{ 'E' , 4 , 5 },
	{ 'F' , 3 , 5 },
	{ 'G' , 2 , 5 },
	{ 'H' , 1 , 5 },
	{ 'I' , 5 , 4 },
	{ 'J' , 4 , 4 },
	{ 'K' , 3 , 4 },
	{ 'L' , 2 , 4 },
	{ 'M' , 1 , 4 },
	{ 'N' , 5 , 3 },
	{ 'O' , 4 , 3 },
	{ 'P' , 3 , 3 },
	{ 'Q' , 2 , 3 },
	{ 'R' , 1 , 3 },
	{ 'S' , 5 , 2 },
	{ 'T' , 4 , 2 },
	{ 'U' , 3 , 2 },
	{ 'V' , 2 , 2 },
	{ 'W' , 1 , 2 },
	{ 'X' , 5 , 1 },
	{ 'Y' , 4 , 1 },
	{ 'Z' , 3 , 1 },
	{ ' ' , 4 , 0 },
	{ VK_DOWN , 0 , 0 },
	{ VK_LEFT , 0 , 1 },
	{ VK_RIGHT , 0 , 2 },
	{ VK_UP , 0 , 3 },
	{ '0' , 4 , 0 },
	{ '1' , 4 , 1 },
	{ '2' , 3 , 1 },
	{ '3' , 2 , 1 },
	{ '4' , 4 , 2 },
	{ '5' , 3 , 2 },
	{ '6' , 2 , 2 },
	{ '7' , 4 , 3 },
	{ '8' , 3 , 3 },
	{ '9' , 2 , 3 },
	{ VK_RETURN , 1 , 0 },
	{ VKF_PERIOD , 3 , 0 },
	{ VKF_COMMA , 4 , 4 },
	{ VK_ADD , 1 , 1 },
	{ VK_SUBTRACT , 1 , 2 },
	{ VK_MULTIPLY , 1 , 3 },
	{ VK_DIVIDE , 1 , 4 },
	{ VKF_LBRACKET , 3 , 4 },
	{ VKF_RBRACKET , 2 , 4 },
	{ VK_F1 , 6 , 4 },
	{ VK_F2 , 6 , 3 },
	{ VK_F3 , 6 , 2 },
	{ VK_F4 , 6 , 1 },
	{ VK_F5 , 6 , 0 },
	{ VK_ESCAPE , 6 , 6 },
	{ VK_LSHIFT , 6 , 5 },
	{ VK_LCONTROL , 5 , 7 },
	{ VK_RSHIFT , 1 , 6 },
	{ VKF_MINUS , 2 , 0 },
	{ VKF_EQUAL , 4 , 7 },
	{ VK_PRIOR , 4 , 6 },
	{ VK_NEXT , 3 , 6 },
	{ VK_INSERT , 2 , 6 },
	{ VK_DELETE , 6 , 7 },
	{ VK_HOME , 5 , 6 },
	{ VK_END , 3 , 7 },
	{ VK_NUMPAD0 , 4 , 0 },
	{ VK_NUMPAD1 , 4 , 1 },
	{ VK_NUMPAD2 , 3 , 1 },
	{ VK_NUMPAD3 , 2 , 1 },
	{ VK_NUMPAD4 , 4 , 2 },
	{ VK_NUMPAD5 , 3 , 2 },
	{ VK_NUMPAD6 , 2 , 2 },
	{ VK_NUMPAD7 , 4 , 3 },
	{ VK_NUMPAD8 , 3 , 3 },
	{ VK_NUMPAD9 , 2 , 3 },
	{ VK_DECIMAL , 3 , 0 },
	{ VK_OEM_2, 2, 0 }
};
	
	
keypad_t *keypad_init(CPU_t *cpu) {
	keypad_t *keypad;
	int b,i;
	
	keypad = malloc(sizeof(keypad_t));
	if (!keypad) {
		printf("Couldn't allocate mem for keypad\n");
		exit(1);
	}

	for(b=0;b<8;b++) {
		for(i=0;i<8;i++) {
			keypad->keys[b][i]=0;
		}
	}
	keypad->on_pressed=0;
	keypad->group = 0;
	return keypad;
}

void keypad(CPU_t *cpu, device_t *dev) {
	keypad_t *keypad = dev->aux;
	
	if (cpu->input) {
		int i,group,keybit,result=0;
		
		for (group = 0; group < 7; group++) {
			for (keybit = 0; keybit < 8; keybit++) {
				keypad->keys[group][keybit] &= 0xFE;
			}
		}
		
		for(i=0; i < NumElm(keygrps); i++) {
			if (calcs[gslot].lpKeyState[keygrps[i].vk] & 128) {
				keypad->keys[keygrps[i].group][keygrps[i].bit] |= 0x01;
			}
		}

		for (group = 0; group < 7; group++) {
			if (keypad->group & (1<<group)) {

				for (keybit = 0; keybit < 8; keybit++) {
					if (keypad->keys[group][keybit]) {
						result |= (1<<keybit);
					}
				}
			}
		}
		

		cpu->bus = ~result;
		cpu->input = FALSE;
	} else if (cpu->output) {
		unsigned char group = ~cpu->bus;
		if (group != 0) keypad->group = group;
		else keypad->group = 0;
		cpu->output = FALSE;
	}	
}
