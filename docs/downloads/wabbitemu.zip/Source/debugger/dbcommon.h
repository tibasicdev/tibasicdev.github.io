#ifndef DBCOMMON_H
#define DBCOMMON_H

#include "gui.h"
#include <windows.h>
#include "calc.h"

#include "dbreg.h"

int get_value(HWND hwndParent);
INT_PTR CALLBACK GotoDialogProc(HWND hwndDlg, UINT Message, WPARAM wParam, LPARAM lParam);
int ValueSubmit(HWND hwndDlg, char *loc, int size);
LRESULT CALLBACK ValueProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

#endif /* DBCOMMON_H */
