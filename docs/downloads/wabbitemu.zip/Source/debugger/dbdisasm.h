#ifndef DBDISASM_H
#define DBDISASM_H

#include "gui.h"
#include "core.h"

LRESULT CALLBACK DisasmProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

typedef struct disasmpane_settings {
	unsigned short nSel, nPane;
	int iSel, iPC;
	unsigned int cyRow, nRows, nPage;
	unsigned int cxAddr, cxData, cxDisasm;
	int iAddr, iData, iDisasm;
	HFONT hfontAddr, hfontData, hfontDisasm;
	memory_context_t mem_c;
	HWND hwndHeader;
} disasmpane_settings_t, dp_settings;
	



#endif
