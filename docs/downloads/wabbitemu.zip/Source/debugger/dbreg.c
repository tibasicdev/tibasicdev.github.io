#include "dbreg.h"

#include "alu.h"

extern HINSTANCE g_hInst;

struct db_reg {
	unsigned int offset;
	char name[8];
};
	
static const struct db_reg reg_offset[] = {
	coff(af,"af"), coff(afp,"af'"),
	coff(bc,"bc"), coff(bcp,"bc'"),
	coff(de,"de"), coff(dep,"de'"),
	coff(hl,"hl"), coff(hlp,"hl'"),
	coff(ix,"ix"), coff(iy,"iy"),
	coff(pc,"pc"), coff(sp,"sp"),
	coff(i,"i"), coff(imode,"im"), coff(r,"r")};
	//coff(halt,"hlt"), coff(iff1,"iff1"),coff(iff2,"iff2")};
	
static RECT val_locs[NumElm(reg_offset)];
static int kRegRow, kRegAddr, val_right;

void ValueDraw(HDC hdc, RECT *dr, int i) {
	char szRegVal[16];

	dr->right = dr->left + kRegAddr;
	sprintf(szRegVal, "%-3s", reg_offset[i].name);
	SelectObject(hdc, GetStockObject(SYSTEM_FONT));
	DrawText(hdc, szRegVal, -1, dr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	dr->left = dr->right;
	dr->right += kRegAddr;
	SelectObject(hdc, GetStockObject(ANSI_FIXED_FONT));
	
	if (i < REG16_ROWS * REG16_COLS) {	
		sprintf(szRegVal, "%0.4X", reg16(reg_offset[i].offset));
		DrawText(hdc, szRegVal, -1, dr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	} else {
		sprintf(szRegVal, "%0.2X", reg8(reg_offset[i].offset));
		DrawText(hdc, szRegVal, -1, dr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
	}
	val_locs[i] = *dr;
	
}
						
#define DBREG_ORGX	12
#define DBREG_ORGY	0
						
LRESULT CALLBACK RegProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	static HWND hwndVal = NULL;
	static int vi;
	static TEXTMETRIC tm;
	static reg_prev[NumElm(reg_offset)];
	static HWND btn_swap[4], chk_z, chk_c, chk_s, chk_pv, chk_hc, chk_n,
								chk_iff1, chk_iff2, chk_halt;

	switch (Message) {
		case WM_CREATE:
		{
			HDC hdc = GetDC(hwnd);
			SetBkMode(hdc, TRANSPARENT);
			
			SelectObject(hdc, GetStockObject(ANSI_FIXED_FONT));
			GetTextMetrics(hdc, &tm);
			kRegRow = tm.tmHeight + tm.tmHeight/3;
			kRegAddr = tm.tmAveCharWidth*4;
			
			RECT r;
			GetClientRect(hwnd, &r);
			unsigned int i;
			for (i = 0; i < NumElm(btn_swap); i++) {
				btn_swap[i] = 
				CreateWindow(
					"BUTTON",
					"<>",
					WS_VISIBLE | WS_CHILD | BS_FLAT,
					DBREG_ORGX+9*kRegAddr/4, DBREG_ORGY+kRegRow*i + REG_TOP, kRegAddr, kRegRow,
					hwnd, (HMENU) (REG_SWAPID+i), g_hInst, NULL);
			}
			
			chk_z =
			CreateWindow(
				"BUTTON",
				"z",
				WS_VISIBLE | WS_CHILD | BS_CHECKBOX | BS_LEFTTEXT,
				DBREG_ORGX, REG_TOP + kRegRow/2 + REG16_ROWS*kRegRow, 3*kRegAddr/2, kRegRow,
				hwnd, (HMENU) REG_CHK_Z, g_hInst, NULL);

			chk_c =
			CreateWindow(
				"BUTTON",
				"c",
				WS_VISIBLE | WS_CHILD | BS_CHECKBOX | BS_LEFTTEXT,
				DBREG_ORGX+2*kRegAddr, REG_TOP + kRegRow/2 + REG16_ROWS*kRegRow, 3*kRegAddr/2, kRegRow,
				hwnd, (HMENU) REG_CHK_C, g_hInst, NULL);
				
			chk_s =
			CreateWindow(
				"BUTTON",
				"s",
				WS_VISIBLE | WS_CHILD | BS_CHECKBOX | BS_LEFTTEXT,
				DBREG_ORGX+4*kRegAddr, REG_TOP + kRegRow/2 + REG16_ROWS*kRegRow, 3*kRegAddr/2, kRegRow,
				hwnd, (HMENU) REG_CHK_S, g_hInst, NULL);
			chk_pv =
			CreateWindow(
				"BUTTON",
				"p/v",
				WS_VISIBLE | WS_CHILD | BS_CHECKBOX | BS_LEFTTEXT,
				DBREG_ORGX, REG_TOP + kRegRow/2 + REG16_ROWS*kRegRow + kRegRow, 3*kRegAddr/2, kRegRow,
				hwnd, (HMENU) REG_CHK_PV, g_hInst, NULL);	

			chk_hc =
			CreateWindow(
				"BUTTON",
				"hc",
				WS_VISIBLE | WS_CHILD | BS_CHECKBOX | BS_LEFTTEXT,
				DBREG_ORGX+2*kRegAddr, REG_TOP + kRegRow/2 + REG16_ROWS*kRegRow + kRegRow, 3*kRegAddr/2, kRegRow,
				hwnd, (HMENU) REG_CHK_HC, g_hInst, NULL);	
				
			chk_n =
			CreateWindow(
				"BUTTON",
				"n",
				WS_VISIBLE | WS_CHILD | BS_CHECKBOX | BS_LEFTTEXT,
				DBREG_ORGX+4*kRegAddr, REG_TOP + kRegRow/2 + REG16_ROWS*kRegRow + kRegRow, 3*kRegAddr/2, kRegRow,
				hwnd, (HMENU) REG_CHK_N, g_hInst, NULL);
			
			chk_halt =
			CreateWindow(
				"BUTTON",
				"halt",
				WS_VISIBLE | WS_CHILD | BS_CHECKBOX | BS_LEFTTEXT,
				DBREG_ORGX, REG_TOP + 10*kRegRow, 3*kRegAddr/2, kRegRow,
				hwnd, (HMENU) REG_CHK_HALT, g_hInst, NULL);			
	
			chk_iff1 =
			CreateWindow(
				"BUTTON",
				"iff1",
				WS_VISIBLE | WS_CHILD | BS_CHECKBOX | BS_LEFTTEXT,
				DBREG_ORGX+2*kRegAddr, REG_TOP + 10*kRegRow, 3*kRegAddr/2, kRegRow,
				hwnd, (HMENU) REG_CHK_IFF1, g_hInst, NULL);	
				
			chk_iff2 =
			CreateWindow(
				"BUTTON",
				"iff2",
				WS_VISIBLE | WS_CHILD | BS_CHECKBOX | BS_LEFTTEXT,
				DBREG_ORGX+4*kRegAddr, REG_TOP + 10*kRegRow, 3*kRegAddr/2, kRegRow,
				hwnd, (HMENU) REG_CHK_IFF2, g_hInst, NULL);	
			
			ReleaseDC(hwnd, hdc);

			SendMessage(hwnd, WM_USER, REG_UPDATE, 0);
			break;
		}
		case WM_SIZE:
			InvalidateRect(hwnd, NULL, FALSE);
			UpdateWindow(hwnd);
			return 0;
		
		case WM_CTLCOLORBTN:
		case WM_CTLCOLORSTATIC:
		{
			return (LRESULT) GetSysColorBrush(COLOR_BTNFACE);
			
		}
		case WM_COMMAND:
			switch (HIWORD(wParam)) {
				case EN_CHANGE:
				case 256:
				case EN_UPDATE:
				case EN_MAXTEXT:
					break;
				
				case EN_KILLFOCUS:
					if (GetFocus() == hwnd) break;
				case EN_SUBMIT:
					
				default:
				if (vi != -1) {
					if (vi < REG16_ROWS*REG16_COLS) {
						ValueSubmit(hwndVal,
							((unsigned char*) (&calcs[gslot].cpu)) + reg_offset[vi].offset,
							2);
					} else {
						ValueSubmit(hwndVal,
							((unsigned char*) (&calcs[gslot].cpu)) + reg_offset[vi].offset,
							1);
						
					}
					SendMessage(GetParent(hwnd), WM_USER, DB_UPDATE, 0);
				}					
				hwndVal = NULL;
				switch (HIWORD(wParam)) {
				case BN_CLICKED:
				{
					switch (LOWORD(wParam)) {
						case REG_CHK_Z:
							calcs[gslot].cpu.f ^= ZERO_MASK;
							break;
						case REG_CHK_C:
							calcs[gslot].cpu.f ^= CARRY_MASK;
							break;
						case REG_CHK_S:
							calcs[gslot].cpu.f ^= SIGN_MASK;
							break;
						case REG_CHK_PV:
							calcs[gslot].cpu.f ^= PV_MASK;
							break;
						case REG_CHK_HC:
							calcs[gslot].cpu.f ^= HC_MASK;
							break;	
						case REG_CHK_N:
							calcs[gslot].cpu.f ^= N_MASK;
							break;
						case REG_CHK_HALT:
							calcs[gslot].cpu.halt ^= 1;
							break;
						case REG_CHK_IFF1:
							calcs[gslot].cpu.iff1 ^= 1;
							break;
						case REG_CHK_IFF2:
							calcs[gslot].cpu.iff2 ^= 1;
							break;										
						default:
						{
							unsigned short swap;
							int ri = LOWORD(wParam) - REG_SWAPID;
							if (ri < 4) {
								swap = reg16(reg_offset[ri*2].offset);
								reg16(reg_offset[ri*2].offset) = reg16(reg_offset[ri*2+1].offset);
								reg16(reg_offset[ri*2+1].offset) = swap;
							}
						}
					}
					
					SendMessage(GetParent(hwnd), WM_USER, DB_UPDATE, 0);
					break;
				}
				}
			}
			return 0;
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc, hdcDest;

			hdcDest = BeginPaint(hwnd, &ps);
			
			RECT r, dr;
			char szRegVal[16];
			
			GetClientRect(hwnd, &r);

			hdc = CreateCompatibleDC(hdcDest);
			HBITMAP hbm = CreateCompatibleBitmap(hdcDest, r.right, r.bottom);
			SelectObject(hdc, hbm);
			SetBkMode(hdc, TRANSPARENT);
			TRIVERTEX vert[2];
			GRADIENT_RECT gRect;
			gRect.UpperLeft  = 0;
			gRect.LowerRight = 1;
			int color = GetSysColor(COLOR_BTNFACE);
			vert[0].x      = r.left;
			vert[0].y      = r.top;
			vert[0].Red    = 0xff00;
			vert[0].Green  = 0xff00;
			vert[0].Blue   = 0xff00;
			vert[1].x      = r.right;
			vert[1].y      = kRegRow*6;
			vert[1].Red    = GetRValue(color) << 8;
			vert[1].Green  = GetGValue(color) << 8;
			vert[1].Blue   = GetBValue(color) << 8;
			
			GradientFill(hdc,vert,2,&gRect,1,GRADIENT_FILL_RECT_V);
			vert[1].x	= DBREG_ORGX;
			vert[0].x	= 2;
			GradientFill(hdcDest,vert,2,&gRect,1,GRADIENT_FILL_RECT_V);
			r.top = kRegRow*6;
			FillRect(hdc, &r, GetSysColorBrush(COLOR_BTNFACE));
			
			
			int i, j, ind = 0;
			
			for (	i = 0, r.top = REG_TOP, r.bottom = r.top + kRegRow;
					i < REG16_ROWS;
					i++, OffsetRect(&r, 0, kRegRow)) {
						
				CopyRect(&dr, &r);
				ValueDraw(hdc, &dr, ind++);

				OffsetRect(&dr, (5*kRegAddr)/2, 0);
				ValueDraw(hdc, &dr, ind++);
			}
			
			OffsetRect(&r, 0, 3*kRegRow);
			
			/* Draw checkboxes here */
			
			for (i = 0; i < REG8_ROWS; i++, OffsetRect(&r, 0, kRegRow)) {
				
				CopyRect(&dr, &r);
				for (	j = 0; 
						j < REG8_COLS; 
						j++, 
						dr.left += 2*kRegAddr) {
					RECT cpyr = dr;
					ValueDraw(hdc, &cpyr, ind++);
				}
			}
			
			OffsetRect(&r, 0, 3*kRegRow/2);
			
			CopyRect(&dr, &r);
			dr.right = 2*kRegAddr;
			SelectObject(hdc, GetStockObject(SYSTEM_FONT));
			DrawText(hdc, "(hl) ", -1, &dr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			dr.left += kRegAddr;
			int val = mem_read((&calcs[gslot].cpu)->mem_c, (&calcs[gslot].cpu)->hl);
			sprintf(szRegVal, "%0.2X", val);
			SelectObject(hdc, GetStockObject(ANSI_FIXED_FONT));
			DrawText(hdc, szRegVal, -1, &dr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			
			OffsetRect(&dr,2*kRegAddr,0);
			dr.left -= kRegAddr;
			SelectObject(hdc, GetStockObject(SYSTEM_FONT));
			DrawText(hdc, "(ix) ", -1, &dr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			val = mem_read((&calcs[gslot].cpu)->mem_c, (&calcs[gslot].cpu)->ix);
			sprintf(szRegVal, "%0.2X", val);
			dr.left += kRegAddr;
			SelectObject(hdc, GetStockObject(ANSI_FIXED_FONT));
			DrawText(hdc, szRegVal, -1, &dr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			
			OffsetRect(&dr,2*kRegAddr,0);	
			dr.left -= kRegAddr;
			SelectObject(hdc, GetStockObject(SYSTEM_FONT));
			DrawText(hdc, "(iy) ", -1, &dr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			val = mem_read((&calcs[gslot].cpu)->mem_c, (&calcs[gslot].cpu)->iy);
			sprintf(szRegVal, "%0.2X", val);
			dr.left += kRegAddr;
			SelectObject(hdc, GetStockObject(ANSI_FIXED_FONT));
			DrawText(hdc, szRegVal, -1, &dr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
			
			GetClientRect(hwnd, &r);
			BitBlt(hdcDest, DBREG_ORGX, DBREG_ORGY, r.right, r.bottom, hdc, 0, 0, SRCCOPY);
			
			r.right = DBREG_ORGX; r.top = 6*kRegRow;
			FillRect(hdcDest, &r, GetSysColorBrush(COLOR_BTNFACE));
			r.top = 0;
			DrawEdge(hdcDest, &r,EDGE_ETCHED, BF_LEFT);
			EndPaint(hwnd, &ps);
			
			DeleteDC(hdc);
			DeleteObject(hbm);
			return 0;
		}
		case WM_USER:
			switch (wParam) {
				//case PANE_UPDATE:
				case DB_UPDATE:
				{
					SendMessage(chk_z, BM_SETCHECK, 
					(calcs[gslot].cpu.f & ZERO_MASK) ? BST_CHECKED : BST_UNCHECKED, 0);
					SendMessage(chk_c, BM_SETCHECK, 
					(calcs[gslot].cpu.f & CARRY_MASK) ? BST_CHECKED : BST_UNCHECKED, 0);
					SendMessage(chk_s, BM_SETCHECK, 
					(calcs[gslot].cpu.f & SIGN_MASK) ? BST_CHECKED : BST_UNCHECKED, 0);
					SendMessage(chk_pv, BM_SETCHECK, 
					(calcs[gslot].cpu.f & PV_MASK) ? BST_CHECKED : BST_UNCHECKED, 0);
					SendMessage(chk_hc, BM_SETCHECK, 
					(calcs[gslot].cpu.f & HC_MASK) ? BST_CHECKED : BST_UNCHECKED, 0);					
					SendMessage(chk_n, BM_SETCHECK, 
					(calcs[gslot].cpu.f & N_MASK) ? BST_CHECKED : BST_UNCHECKED, 0);
					
					SendMessage(chk_halt, BM_SETCHECK, 
					(calcs[gslot].cpu.halt) ? BST_CHECKED : BST_UNCHECKED, 0);		
					SendMessage(chk_iff1, BM_SETCHECK, 
					(calcs[gslot].cpu.iff1) ? BST_CHECKED : BST_UNCHECKED, 0);
					SendMessage(chk_iff2, BM_SETCHECK, 
					(calcs[gslot].cpu.iff2) ? BST_CHECKED : BST_UNCHECKED, 0);										

					InvalidateRect(hwnd, NULL, TRUE);
					UpdateWindow(hwnd);
						 
					break;
				}
			}
			return 0;
		case WM_LBUTTONDBLCLK:
		case WM_LBUTTONDOWN:
		{
			POINT p;
			p.x = GET_X_LPARAM(lParam) - DBREG_ORGX;
			p.y = GET_Y_LPARAM(lParam) - DBREG_ORGY;

			HWND oldVal = FindWindowEx(hwnd, NULL, "EDIT", NULL);
			if (oldVal) {
				SendMessage(hwnd, WM_COMMAND, EN_SUBMIT<<16, (LPARAM) oldVal);
			}

			if (Message != WM_LBUTTONDBLCLK) return 0;

			unsigned int i;
			for (i = 0; i < NumElm(reg_offset); i++) {
				if (PtInRect(&val_locs[i], p)) {
					vi = i;
					break;
				}
			}
			
			if (i == NumElm(reg_offset)) {
				vi = -1;
				return 0;
			}
			RECT r;
			GetClientRect(hwnd, &r);

			hwndVal = NULL;
			char rval[8];
			int edit_width;
			if (vi < REG16_ROWS*REG16_COLS) {
				sprintf(rval, "%.4X", reg16(reg_offset[vi].offset));
				edit_width = 4;
			} else {
				sprintf(rval, "%.2X", reg8(reg_offset[vi].offset));
				edit_width = 2;
			}
				
			
			hwndVal = 
			CreateWindow("EDIT", rval,
				WS_CHILD | WS_VISIBLE | WS_BORDER | ES_LEFT | ES_MULTILINE,
				val_locs[vi].left-2 + DBREG_ORGX,
				val_locs[vi].top + DBREG_ORGY,
				(edit_width*kRegAddr/4)+4,
				kRegRow,
				hwnd, 0, g_hInst, NULL);
				
			SubclassEdit(hwndVal, edit_width);
			return 0;
		}
		default:
			DefWindowProc(hwnd, Message, wParam, lParam);
	}
	
}
