#include "dbcommon.h"
#include "gui.h"
#include "rsrc.h"
#include <commctrl.h>
#include "label.h"

extern HINSTANCE g_hInst;

static int value;
unsigned short goto_addr;

INT_PTR CALLBACK GotoDialogProc(HWND hwndDlg, UINT Message, WPARAM wParam, LPARAM lParam) {
	static HWND edtAddr;
	switch (Message) {
		case WM_INITDIALOG:
			edtAddr = GetDlgItem(hwndDlg, IDC_EDTGOTOADDR);
			SetFocus(GetDlgItem(hwndDlg, IDC_EDTGOTOADDR));
			return FALSE;
		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				case IDOK: {
					char result[32];
					GetDlgItemText(hwndDlg, IDC_EDTGOTOADDR, result, 32);
					int label_addr;
					label_addr = lookup_label(result);
					if (label_addr == -1) sscanf(result, "%x", &goto_addr);
					else goto_addr = label_addr;
					EndDialog(hwndDlg, IDOK);
					return TRUE;
				}
				case IDCANCEL:
					EndDialog(hwndDlg, IDCANCEL);
					break;
			}
			break;
	}
	return FALSE;
}


int ValueSubmit(HWND hwndDlg, char *loc, int size) {
	char result[32];
	int got_line;
	if (hwndDlg == NULL) return 0;
	((WORD*)result)[0] = 32;	//string size
	got_line = SendMessage(hwndDlg, EM_GETLINE, (WPARAM) 0, (LPARAM) result);
	char value[4];
	int i;
	/* Parse input here */

	if (got_line > 0) {
		sscanf(result, "%x", (int*) value);
	} else {
		*((int*)value) = 0;
	}
	for (i = 0; i < size; i++) loc[i] = value[i];
	DestroyWindow(hwndDlg);
	return 0;
}

static WNDPROC wndProcEdit;

LRESULT CALLBACK ValueProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {

	switch (Message) {
		case WM_PAINT:
		{	
			SendMessage(hwnd, WM_SETFONT, 
				(WPARAM) GetStockObject(ANSI_FIXED_FONT), (LPARAM) FALSE);
			break;
		}
		case WM_KEYDOWN:
			switch (wParam) {
				case VK_RETURN:
					SendMessage(GetParent(hwnd), WM_COMMAND, 
						MAKEWPARAM(0, EN_SUBMIT), (LPARAM) hwnd);
					return 0;
				case VK_ESCAPE:
					DestroyWindow(hwnd);
					return 0;
			}
	}
	return CallWindowProc(wndProcEdit, hwnd, Message, wParam, lParam);
}

void SubclassEdit(HWND hwndEdt, int edit_width) {
	if (hwndEdt) {
		wndProcEdit = (WNDPROC) SetWindowLong(hwndEdt, GWL_WNDPROC, (DWORD) ValueProc);	
		SendMessage(hwndEdt, EM_SETLIMITTEXT, edit_width, 0);
		SendMessage(hwndEdt, EM_SETSEL, 0, edit_width);
		SetFocus(hwndEdt);
	}
}
