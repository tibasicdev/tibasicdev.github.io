#ifndef DBREG_H
#define DBREG_H

#include <stddef.h>

#include "gui.h"
#include "core.h"
#include "calc.h"

#define coff(rreg,rname) {(unsigned int) (offsetof(struct CPU, rreg)), rname}
#define reg16(offs) (*((unsigned short*) (&calcs[gslot].cpu) + (offs/sizeof(short))))
#define reg8(offs) (*((unsigned char*) (&calcs[gslot].cpu) + (offs/sizeof(char))))
#define REG16_COLS 	2
#define REG8_COLS	3
#define REG16_ROWS	6
#define REG8_ROWS	1
#define REG_TOP		4
#define BTN_SWP_WIDTH

#define EN_SUBMIT	99

LRESULT CALLBACK RegProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

#endif
