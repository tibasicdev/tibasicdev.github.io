#ifndef DBMEM_H
#define DBMEM_H

#include "gui.h"
#include "calc.h"


typedef struct mempane_settings {
	unsigned short addr;			// Top left address
	int mode;						// current display mode
	int sel;						// current selection
	int track;						// register to track
	int iAddr, iData;
	HWND hwndHeader;
	HFONT hfontAddr, hfontData;
	int nRows, nCols;
	int cxMem;
} mempane_settings_t;

typedef mempane_settings_t mp_settings;


LRESULT CALLBACK MemProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

#endif
