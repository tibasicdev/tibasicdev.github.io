#include "dbmem.h"
#include "dbcommon.h"
#include "rsrc.h"
#include <commctrl.h>

extern HINSTANCE g_hInst;
extern unsigned short goto_addr;

LRESULT CALLBACK MemProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	int mem_mode;
	static TEXTMETRIC txtm;
	static HWND hwndVal;
	int kMemWidth;
	switch (Message) {
		case WM_CREATE:
		{
			mp_settings *mps;
			HDC hdc = GetDC(hwnd);
			SelectObject(hdc, GetStockObject(ANSI_FIXED_FONT));
			GetTextMetrics(hdc, &txtm);
			
			mps = ((CREATESTRUCT*)lParam)->lpCreateParams;
			SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG_PTR) mps);
			
			
			mps->hwndHeader = CreateWindowEx(0, WC_HEADER, (LPCTSTR) NULL, 
                WS_CHILD |  HDS_HORZ | WS_VISIBLE | HDS_FULLDRAG,
                0, 0, 0, 0, hwnd, (HMENU) ID_SIZE, g_hInst, 
                (LPVOID) NULL);

		    HDITEM hdi; 
		    
		    hdi.mask = HDI_TEXT | HDI_FORMAT | HDI_WIDTH;
			TCHAR pszText[32];
			GetWindowText(hwnd, pszText, sizeof(pszText));
		    hdi.pszText = pszText;
		    hdi.cxy = 1;
		    hdi.cchTextMax = sizeof(hdi.pszText)/sizeof(hdi.pszText[0]); 
		    hdi.fmt = HDF_LEFT | HDF_STRING;

		    SendMessage(mps->hwndHeader, HDM_INSERTITEM, 
		    	(WPARAM) 0, (LPARAM) &hdi);  
				
			mps->iData = 1;

		    hdi.pszText = "Addr";
		    hdi.cxy = txtm.tmAveCharWidth*6;
		    hdi.cchTextMax = sizeof(hdi.pszText)/sizeof(hdi.pszText[0]); 
		    mps->iAddr = 0;
		    
		    SendMessage(mps->hwndHeader, HDM_INSERTITEM, 
		    	(WPARAM) 0, (LPARAM) &hdi);  
		    	
		    	
		    LOGFONT lf;
		    mps->hfontData = GetStockObject(ANSI_FIXED_FONT);
			GetObject(mps->hfontData, sizeof(LOGFONT), &lf);
			lf.lfWeight = FW_BOLD;
			
			mps->hfontAddr = CreateFontIndirect(&lf);
			
			return 0;
		}
		case WM_MOUSEACTIVATE:
			SetFocus(hwnd);
			return 0;
		case WM_PAINT:
		{
			HDC hdc, hdcDest;
			PAINTSTRUCT ps;
			RECT r, dr;
			GetClientRect(hwnd, &r);
						
			hdcDest = BeginPaint(hwnd, &ps);
			
			mp_settings *mps = (mp_settings *) GetWindowLongPtr(hwnd, GWLP_USERDATA);
			
			hdc = CreateCompatibleDC(hdcDest);
			HBITMAP hbm = CreateCompatibleBitmap(hdcDest, r.right, r.bottom);
			SelectObject(hdc, hbm);
			SetBkMode(hdc, TRANSPARENT);
			r.top = 20;
			FillRect(hdc, &r, GetStockObject(WHITE_BRUSH));
			
			GetClientRect(hwnd, &r);
			r.left = r.right - txtm.tmAveCharWidth*1;
			TRIVERTEX vert[2];
			GRADIENT_RECT gRect;
			gRect.UpperLeft  = 0;
			gRect.LowerRight = 1;
			int color = GetSysColor(COLOR_BTNSHADOW);
			vert[0].x      = r.left;
			vert[0].y      = r.top;
			vert[0].Red    = 0xff00;
			vert[0].Green  = 0xff00;
			vert[0].Blue   = 0xff00;
			vert[1].x      = r.right;
			vert[1].y      = r.bottom;
			vert[1].Red    = GetRValue(color) << 8;
			vert[1].Green  = GetGValue(color) << 8;
			vert[1].Blue   = GetBValue(color) << 8;
			
			
			GradientFill(hdc,vert,2,&gRect,1,GRADIENT_FILL_RECT_H);
			
			r.left = 0; r.top = 20;
			kMemWidth = txtm.tmAveCharWidth*mps->mode*2;
			
			int i, j, 	rows = (r.bottom - r.top)/txtm.tmHeight,
						cols = 
						(r.right - r.left - txtm.tmAveCharWidth*4) /
						(kMemWidth + 2*txtm.tmAveCharWidth);
					
			mps->nRows = rows;
			mps->nCols = cols;
			mps->cxMem = kMemWidth + 2*txtm.tmAveCharWidth;
			
			int addr = mps->addr;
			char memfmt[8];
			sprintf(memfmt, "%%0.%dx", mps->mode*2);
			unsigned int value;
			
			r.left = 3;
			for (	i = 0, r.bottom = r.top + txtm.tmHeight;
					i < rows;
					i++, OffsetRect(&r, 0, txtm.tmHeight)) {
				char szVal[16];
				sprintf(szVal, "%0.4X", addr);
				if (addr < 0x10000) {
					SelectObject(hdc, mps->hfontAddr);
					DrawText(hdc, szVal, -1, &r, DT_LEFT | DT_VCENTER);
				}
				for (	j = 0, CopyRect(&dr, &r), dr.left += txtm.tmAveCharWidth*6, dr.right = dr.left + kMemWidth;
						j < cols;
						j++, OffsetRect(&dr, kMemWidth + 2*txtm.tmAveCharWidth, 0)) {
					int b;
					BOOL isSel = FALSE;
					if (addr == mps->sel) isSel = TRUE;
					value = 0;
					
					if (addr >= 0x10000) break;
					
					for (b = 0; b < mps->mode; b++) {
						value <<= 8;
						value += mem_read((&calcs[gslot].cpu)->mem_c, addr++);
					}
					sprintf(szVal, memfmt, value);
					
					SelectObject(hdc, mps->hfontData);
					DrawText(hdc, szVal, -1, &dr, DT_LEFT | DT_VCENTER);
					
					if (isSel == TRUE) {
						DrawFocusRect(hdc, &dr);	
					}
				}
					
				
			}
		
			
			GetClientRect(hwnd, &r);
			BitBlt(hdcDest, 0, 20, r.right, r.bottom, hdc, 0, 20, SRCCOPY);
			
			EndPaint(hwnd, &ps);
			
			DeleteDC(hdc);
			DeleteObject(hbm);
			return 0;
		}
		case WM_NOTIFY:
			switch (((NMHDR*) lParam)->code) {
				case HDN_BEGINTRACK:
				case HDN_ENDTRACK:
				{
					return TRUE;
				}
			}
			return FALSE;
		case WM_KEYDOWN:
		{
			RECT r;
			GetClientRect(hwnd, &r);
			mp_settings *mps = (mp_settings*) GetWindowLong(hwnd, GWL_USERDATA);
	
			int data_length = mps->nCols * mps->nRows * mps->mode;
			switch (wParam) {
				case VK_DOWN:
					if (mps->addr + data_length < 0x10000) {
						mps->addr += mps->nCols * mps->mode;
					}
					break;
				case VK_UP:
					if (mps->addr - mps->nCols * mps->mode < 0) mps->addr = 0;
					else mps->addr -= mps->nCols * mps->mode;
					break;
				case VK_NEXT:
					mps->addr += mps->nCols * mps->mode * 4;
					break;
				case VK_PRIOR:
					mps->addr -= mps->nCols * mps->mode * 4;
					break;
				case 'G': {
					int result;
					result = DialogBox(g_hInst, MAKEINTRESOURCE(IDD_DLGGOTO), hwnd, (DLGPROC)GotoDialogProc);
					if (result == IDOK) mps->addr = goto_addr;
					break;
				}
				default:
					return 0;
			}
			SendMessage(hwnd, WM_USER, DB_UPDATE, 1);
			return 0;
		}
		case WM_SIZE:
		{
			RECT rc;
			mp_settings *mps = (mp_settings*) GetWindowLong(hwnd, GWL_USERDATA);
			GetClientRect(hwnd, &rc);
			MoveWindow(mps->hwndHeader, 0, 0, rc.right, 20, TRUE);
			
			HDITEM hdi;
			hdi.mask = HDI_WIDTH;
			hdi.cxy = rc.right - txtm.tmAveCharWidth*6;
			Header_SetItem(mps->hwndHeader, mps->iData, &hdi);
			return 0;
		}
		case WM_COMMAND:
		{
			mp_settings *mps = (mp_settings*) GetWindowLong(hwnd, GWL_USERDATA);
			switch (HIWORD(wParam)) {
				case EN_KILLFOCUS:
					if (GetFocus() == hwnd) break;
				case EN_SUBMIT:
				{
					unsigned char data[mps->mode];
					ValueSubmit(hwndVal, data, mps->mode);
					int i;
					for (i = 0; i < mps->mode; i++) {
						mem_write(&calcs[gslot].mem_c, mps->sel + (mps->mode - i - 1), data[i]);
					}
					SendMessage(GetParent(hwnd), WM_USER, DB_UPDATE, 0);					
					hwndVal = NULL;
				}
			}
			return 0;
		}
		case WM_LBUTTONDBLCLK:
		case WM_LBUTTONDOWN:
		{
			int data_left = txtm.tmAveCharWidth*6 + 3;
			mp_settings *mps = (mp_settings*) GetWindowLong(hwnd, GWL_USERDATA);
			RECT rc;
			GetClientRect(hwnd, &rc);
			
			int x = GET_X_LPARAM(lParam);
			int y = GET_Y_LPARAM(lParam);
			
			HWND oldVal = FindWindowEx(hwnd, NULL, "EDIT", NULL);
			if (oldVal) {
				SendMessage(hwnd, WM_COMMAND, MAKEWPARAM(0, EN_SUBMIT), (LPARAM) oldVal);
			}
			
			if (x > data_left && y > 20) {
				int col = (x - data_left)/mps->cxMem;
				int row = (y - 20)/txtm.tmHeight;
				
				int sel_old = mps->sel;
				mps->sel = mps->addr + ((col + (row * mps->nCols)) * mps->mode);
				if (mps->sel > 0x10000) {
					mps->sel = sel_old;
					return 0;
				}
				if (Message == WM_LBUTTONDBLCLK) {
					RECT r;
					r.left = data_left + (col*mps->cxMem);
					r.right = r.left + mps->cxMem - 2*txtm.tmAveCharWidth;
					r.top = 20 + (row*txtm.tmHeight);
					r.bottom = r.top + txtm.tmHeight;
					
					char szInitial[8];
					
					int value = 0;
					int i;
					for (i = 0; i < mps->mode; i++) {
						value <<= 8;
						value += mem_read(&calcs[gslot].mem_c, mps->sel+i);
					}
					
					char szFmt[8];
					sprintf(szFmt, "%%0.%dx", mps->mode*2);
					sprintf(szInitial, szFmt, value);
					
					hwndVal = 
					CreateWindow("EDIT", szInitial,
						WS_CHILD | WS_VISIBLE | WS_BORDER | ES_LEFT | ES_MULTILINE,
						r.left-2,
						r.top-2,
						r.right-r.left+4,
						r.bottom - r.top +4,
						hwnd, 0, g_hInst, NULL);
						
					SubclassEdit(hwndVal, mps->mode*2);
				}
			}
			SendMessage(hwnd, WM_USER, DB_UPDATE, 1);
			return 0;	
		}
		
		case WM_USER:
			switch (wParam) {
				case DB_UPDATE:
				{
					mp_settings *mps = (mp_settings*) GetWindowLong(hwnd, GWL_USERDATA);
					if (mps->track != -1 && lParam == 0) {
						mps->addr = ((unsigned short*) &calcs[gslot].cpu)[mps->track/2];
					}
					InvalidateRect(hwnd, NULL, FALSE);
					UpdateWindow(hwnd);
					break;
				}
			}
			return 0;
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
}
