#include "dbdisasm.h"
 
#include "calc.h"
#include "rsrc.h"
#include "disassemble.h"
#include <commctrl.h>
#include "dbcommon.h"
 
extern Z80_com_t da_opcode[256];

extern HINSTANCE g_hInst;
extern unsigned short goto_addr;
 
void sprint_command(char *s, Z80_info_t *zinf) {
	mysprintf(zinf, s, da_opcode[zinf->index].format, 
		zinf->a1, zinf->a2, zinf->a3, zinf->a4); 	
}
 
 
void InvalidateSel(HWND hwnd, int sel) {
	dp_settings *dps = (dp_settings*) GetWindowLong(hwnd, GWL_USERDATA);
	HDC hdc = GetDC(hwnd);
 
	RECT r;
	GetClientRect(hwnd, &r);
	r.top = sel*dps->cyRow + 20; r.bottom = r.top + dps->cyRow;
	InvalidateRect(hwnd, &r, TRUE);	
 
	ReleaseDC(hwnd, hdc);
}
 
void disasm_step(dp_settings *dps) {
 
 
 
 
}
 
 
LRESULT CALLBACK DisasmProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	static Z80_info_t zinf[256];
	static disasmpane_settings_t *dps;
	static TEXTMETRIC tm;
	static bFirstDraw = TRUE;
 
	switch (Message) {
		case WM_CREATE:
		{
			HDC hdc = GetDC(hwnd);
 
			dps = ((CREATESTRUCT*)lParam)->lpCreateParams;
			SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG_PTR) dps);
 
			GetTextMetrics(hdc, &tm);
			dps->cyRow = 9*tm.tmHeight/8;
			dps->nPane = dps->nSel;
 
			// Set column widths
			dps->cxAddr 	= 8*tm.tmAveCharWidth;
			dps->cxData 	= 16*tm.tmAveCharWidth;
			RECT rc;
			GetClientRect(hwnd, &rc);
			dps->cxDisasm	= rc.right - dps->cxAddr - dps->cxData;
 
			// Create the three fonts used
			SelectObject(hdc, GetStockObject(ANSI_FIXED_FONT));
			dps->hfontDisasm = GetCurrentObject(hdc, OBJ_FONT);
 
			LOGFONT lf;
			GetObject(dps->hfontDisasm, sizeof(LOGFONT), &lf);
			lf.lfWeight = FW_BOLD;
 
			dps->hfontAddr = CreateFontIndirect(&lf);
			dps->hfontData = dps->hfontDisasm;
 
			InitCommonControls();
 
			dps->hwndHeader = CreateWindowEx(0, WC_HEADER, (LPCTSTR) NULL, 
                WS_CHILD |  HDS_HORZ | WS_VISIBLE | HDS_FULLDRAG,
                0, 0, 10, 20, hwnd, (HMENU) ID_DISASMSIZE, g_hInst, 
                (LPVOID) NULL);
 
			WINDOWPOS wp;
			HDLAYOUT hdl;
 
			hdl.prc = &rc;
			hdl.pwpos = &wp;
			SendMessage(dps->hwndHeader, HDM_LAYOUT, 0, (LPARAM) &hdl);
			SetWindowPos(dps->hwndHeader, wp.hwndInsertAfter, wp.x, wp.y, 
				wp.cx, wp.cy, wp.flags);
 
		    HDITEM hdi; 
 
			TCHAR pszAddr[] = "Addr";
 
		    hdi.mask = HDI_TEXT | HDI_FORMAT | HDI_WIDTH;
		    hdi.pszText = pszAddr;
		    hdi.cxy = dps->cxAddr;
		    hdi.cchTextMax = sizeof(hdi.pszText)/sizeof(hdi.pszText[0]); 
		    hdi.fmt = HDF_LEFT | HDF_STRING;
 
		    dps->iAddr = SendMessage(dps->hwndHeader, HDM_INSERTITEM, 
		        (WPARAM) 0, (LPARAM) &hdi);
 
			TCHAR pszData[] = "Data";
		    hdi.mask = HDI_TEXT | HDI_FORMAT | HDI_WIDTH;
		    hdi.pszText = pszData;
		    hdi.cxy = dps->cxData;
		    hdi.cchTextMax = sizeof(hdi.pszText)/sizeof(hdi.pszText[0]); 
		    hdi.fmt = HDF_LEFT | HDF_STRING;	
 
			dps->iData = SendMessage(dps->hwndHeader, HDM_INSERTITEM, 
		        (WPARAM) dps->iAddr + 1, (LPARAM) &hdi);
 
 
		    TCHAR pszDisasm[] = "Disassembly";
		    hdi.mask = HDI_TEXT | HDI_FORMAT | HDI_WIDTH;
		    hdi.pszText = pszDisasm;
		    hdi.cxy = dps->cxDisasm;
		    hdi.cchTextMax = sizeof(hdi.pszText)/sizeof(hdi.pszText[0]); 
		    hdi.fmt = HDF_LEFT | HDF_STRING;	
 
			dps->iDisasm = SendMessage(dps->hwndHeader, HDM_INSERTITEM, 
		        (WPARAM) dps->iData + 1, (LPARAM) &hdi);
 
			bFirstDraw = TRUE;
			return 0;
		}
		case WM_SIZE:
		{
			RECT rc;
			GetClientRect(hwnd, &rc);
			dps->cxDisasm	= rc.right - dps->cxAddr - dps->cxData;
 
			HDITEM hdi;
			hdi.mask = HDI_WIDTH;
			hdi.cxy = dps->cxDisasm;
 
			SendMessage(dps->hwndHeader, HDM_SETITEM, dps->iDisasm, (LPARAM) &hdi);
 
			WINDOWPOS wp;
			HDLAYOUT hdl;
 
			hdl.prc = &rc;
			hdl.pwpos = &wp;
			SendMessage(dps->hwndHeader, HDM_LAYOUT, 0, (LPARAM) &hdl);
			SetWindowPos(dps->hwndHeader, wp.hwndInsertAfter, wp.x, wp.y, 
				wp.cx, wp.cy, wp.flags);
 
 
 
			if (rc.bottom < 20) rc.bottom = 20;
			if (dps->cyRow == 0) return 0;
			dps->nRows = (rc.bottom - 20)/dps->cyRow;
 
			SendMessage(hwnd, WM_COMMAND, DB_DISASM, dps->nPane);
			// Assign page length to include length sum of all commands on screen
			Z80_info_t 	*zfirst 	= &zinf[0],
						*zlast 	= &zinf[dps->nRows-1];
 
			dps->nPage = zlast->addr + zlast->size - zfirst->addr;
			return 0;
		}
		case WM_NOTIFY:
			switch (((NMHDR*) lParam)->code) {
				case HDN_BEGINTRACK:
				case HDN_ITEMCHANGING:
				case HDN_ENDTRACK:
				{
					int iItem = ((NMHEADER*) lParam)->iItem;
					HDITEM *lphdi = ((NMHEADER*) lParam)->pitem;
					static BOOL in_changing = FALSE;
 
					if (in_changing) return FALSE;
 
					in_changing = TRUE;
 
					if (iItem == 0) {
						dps->cxAddr = lphdi->cxy;
					} else if (iItem == 1) {
						dps->cxData = lphdi->cxy;
					}
 
					RECT rc;
					GetClientRect(hwnd, &rc);
					dps->cxDisasm = rc.right - dps->cxData - dps->cxAddr;
 
					HDITEM hdi;
					hdi.mask = HDI_WIDTH;
					hdi.cxy = dps->cxDisasm;
 
					SendMessage(dps->hwndHeader, HDM_SETITEM, dps->iDisasm, (LPARAM) &hdi);
					SendMessage(GetParent(hwnd), WM_USER, DB_UPDATE, 0);
					in_changing = FALSE;
				}
				default:
					return FALSE;
			}
			return FALSE;
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc, hdcDest;
			unsigned int i;
			RECT tr, rc;
			GetClientRect(hwnd, &tr);
			CopyRect(&rc, &tr);
			OffsetRect(&tr, 0, 20);
			tr.bottom = tr.top + dps->cyRow;
 
			if (bFirstDraw && dps->nRows/2) {
				bFirstDraw = FALSE;
				int iQ2 = dps->nRows/2;
 
				while (iQ2--) SendMessage(hwnd, WM_VSCROLL, SB_LINEUP, TRUE);
 
			}
 
 
			hdcDest = BeginPaint(hwnd, &ps);
 
			hdc = CreateCompatibleDC(hdcDest);
			HBITMAP hbm = CreateCompatibleBitmap(hdcDest, rc.right, rc.bottom);
			SelectObject(hdc, hbm);
			SetBkMode(hdc, TRANSPARENT);			
			SelectObject(hdc, GetStockObject(DC_BRUSH));
			SelectObject(hdc, GetStockObject(WHITE_PEN));
 
			// Mark selection index as not on screen
			dps->iSel = dps->iPC = -1;
			char szAddr[64], szData[16], szDisasm[64];
			TRIVERTEX vert[2];
			GRADIENT_RECT gRect;
			gRect.UpperLeft  = 0;
			gRect.LowerRight = 1;
			vert[0].x = rc.right - tm.tmAveCharWidth;
			vert[0].y = 20;
			vert[1].x = rc.right;
			vert[1].y = rc.bottom;
 
			vert[0].Red    = 0xff00;
			vert[0].Green  = 0xff00;
			vert[0].Blue   = 0xff00;
 
			int color = GetSysColor(COLOR_BTNSHADOW);
			vert[1].Red    = GetRValue(color) << 8;
			vert[1].Green  = GetGValue(color) << 8;
			vert[1].Blue   = GetBValue(color) << 8;
			GradientFill(hdc,vert,2,&gRect,1,GRADIENT_FILL_RECT_H);
 
			tr.right = rc.right - tm.tmAveCharWidth;
			for (i = 0; i < dps->nRows; i++, OffsetRect(&tr, 0, dps->cyRow)) {
				BOOL do_gradient = FALSE;
 
				vert[0].x      = tr.left;
				vert[0].y      = tr.top;
				vert[0].Red    = 0xff00;
				vert[0].Green  = 0xff00;
				vert[0].Blue   = 0xff00;
				vert[1].x      = tr.right;
				vert[1].y      = tr.bottom;
				vert[1].Red    = 0xff00;
				vert[1].Green  = 0xff00;
				vert[1].Blue   = 0xff00;
 
				// Print address
				sprintf(szAddr, "%0.4X  ", zinf[i].addr);
 
				int j;
				for (j = 0; j < 4; j++) {
					if (j < zinf[i].size) sprintf(szData + (j*2), "%0.2x  ", 
						mem_read(calcs[gslot].cpu.mem_c, zinf[i].addr+j));
					else sprintf(szData + (j*2), "    ");
				}
 
				sprint_command(szDisasm, &zinf[i]);
 
				if (calcs[gslot].cpu.pc == zinf[i].addr && zinf[i].index != DA_LABEL) {
					dps->iPC = i;
					if (calcs[gslot].cpu.halt) {
						vert [1] .Red    = 0xff00;
						vert [1] .Green  = 0x8000;
						vert [1] .Blue   = 0x2000;
					} else {					
						vert [1] .Red    = 0xa000;
						vert [1] .Green  = 0xa000;
						vert [1] .Blue   = 0xff00;
					}
					SetBkMode(hdc, TRANSPARENT);
					do_gradient = TRUE;
				}
				if (calcs[gslot].breakpoints[zinf[i].addr]) {
					vert [0] .Red    = 0xff00;
					vert [0] .Green  = 0xa000;
					vert [0] .Blue   = 0xa000;
					SetBkMode(hdc, TRANSPARENT);
					do_gradient = TRUE;
				}
 
				if (do_gradient) {
					GradientFill(hdc,vert,2,&gRect,1,GRADIENT_FILL_RECT_H);
 
 
					vert[0] = vert[1];
					vert[0].x = rc.right - tm.tmAveCharWidth;
					vert[0].y = tr.top;
					int color = GetSysColor(COLOR_BTNSHADOW);
					vert[1].Red    = GetRValue(color) << 8;
					vert[1].Green  = GetGValue(color) << 8;
					vert[1].Blue   = GetBValue(color) << 8;
 
					vert[1].x = rc.right;
					GradientFill(hdc,vert,2,&gRect,1,GRADIENT_FILL_RECT_H);
				} else {
					tr.right = rc.right - tm.tmAveCharWidth;
					FillRect(hdc, &tr, GetStockObject(WHITE_BRUSH));
				}
 
				tr.left = 3;
				tr.right = dps->cxAddr;
				if (dps->cxAddr > 8) {
					SelectObject(hdc, dps->hfontAddr);
					DrawText(hdc, szAddr, -1, &tr, DT_LEFT | DT_SINGLELINE | DT_VCENTER );
				}
 
				tr.left = dps->cxAddr;
				tr.right += dps->cxData;
				if (dps->cxData > 8) {
					SelectObject(hdc, dps->hfontData);
					DrawText(hdc, szData, -1, &tr, DT_LEFT | DT_SINGLELINE | DT_VCENTER );
				}
 
				tr.left = dps->cxAddr + dps->cxData;
				tr.right = rc.right;
				SelectObject(hdc, dps->hfontDisasm);
 
				DrawText(hdc, szDisasm, -1, &tr, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
				tr.left = 0;
 
				if (dps->nSel >= zinf[i].addr && dps->nSel < zinf[i].addr + zinf[i].size) {
					dps->iSel = i;
					DrawFocusRect(hdc, &tr);
				}
			}
			tr.left = 0; tr.bottom = rc.bottom; tr.right = rc.right- tm.tmAveCharWidth;
			FillRect(hdc, &tr, GetStockObject(WHITE_BRUSH));
 
			GetClientRect(hwnd, &rc);
			BitBlt(hdcDest, 0, 20, rc.right, rc.bottom, hdc, 0, 20, SRCCOPY);
 
			EndPaint(hwnd, &ps);
 
			DeleteDC(hdc);
			DeleteObject(hbm);
			return 0;
		}
		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				case DB_DISASM:
				{
					unsigned int addr = lParam;
					disassemble(&calcs[gslot].mem_c, addr, dps->nRows, zinf);
					break;
				}
				case DB_RUN:
					SendMessage(GetParent(hwnd), WM_DESTROY, 0, 0);
					break;
				case DB_STEP:
				{
					int past_last;
					int before_first;
 
					CPU_step((&calcs[gslot].cpu));
				db_step_finish:
					//if (zinf[dps->nRows-1].size) {
						past_last = calcs[gslot].cpu.pc - zinf[dps->nRows-1].addr + zinf[dps->nRows-1].size;
					//}
					before_first = zinf[0].addr - calcs[gslot].cpu.pc;
					InvalidateSel(hwnd, dps->iPC);
					InvalidateSel(hwnd, dps->iSel);
					dps->nSel = (&calcs[gslot].cpu)->pc;
					if (past_last >= 0 || before_first > 0) {
						SendMessage(hwnd, WM_VSCROLL, MAKEWPARAM(SB_THUMBTRACK, calcs[gslot].cpu.pc), 0);
						int iQ1 = dps->nRows/4;
						if (iQ1 == 0) return 0;
						while (iQ1--) SendMessage(hwnd, WM_VSCROLL, SB_LINEUP, 0);
						UpdateWindow(hwnd);
					} else if (past_last > 0) {
						SendMessage(hwnd, WM_VSCROLL, SB_PAGEDOWN, 0);
					} else if (before_first > 0) {
						SendMessage(hwnd, WM_VSCROLL, SB_PAGEUP, 0);
					} else {
						UpdateWindow(hwnd);
					}
					InvalidateSel(hwnd, dps->iPC);
					SendMessage(GetParent(hwnd), WM_USER, DB_UPDATE, 0);
					break;
				}
				case DB_STEPOVER: {
					int usable_commands[] = { DA_BJUMP, DA_BJUMP_N, DA_BCALL_N, DA_BCALL, 
											  DA_BLI, DA_CALL_X, DA_CALL_CC_X, DA_HALT,DA_RST_X};
					unsigned int i;
					double time = calcs[gslot].cpu.timer_c->elapsed;
					if (calcs[gslot].cpu.halt && calcs[gslot].cpu.iff1) {
						while ( (calcs[gslot].cpu.halt || calcs[gslot].cpu.pc != zinf[dps->iSel].addr)   ) {
							CPU_step((&calcs[gslot].cpu));
						}
					} else if (calcs[gslot].cpu.halt && !calcs[gslot].cpu.iff1) {
						calcs[gslot].cpu.halt = FALSE;
					} else {
						for (	i = 0; 
								i < NumElm(usable_commands) 
									&& zinf[dps->iSel].index != usable_commands[i]; 
								i++);
						if (i < NumElm(usable_commands) ) {
							while ( ((calcs[gslot].cpu.timer_c->elapsed-time)<15.0f) &&
								    (calcs[gslot].cpu.pc != zinf[dps->iSel + 1].addr) ) {
								CPU_step((&calcs[gslot].cpu));
							}
						} else {
							CPU_step((&calcs[gslot].cpu));
						}
					}
					goto db_step_finish;
				}
				case DB_GOTO:
				{
					break;
				}
				case DB_BREAKPOINT:
				{
					calcs[gslot].breakpoints[dps->nSel] = !calcs[gslot].breakpoints[dps->nSel];
					InvalidateSel(hwnd, dps->iSel);
					break;
				}	
			}
			return 0;
		case WM_LBUTTONDOWN:
		{
			int y = GET_Y_LPARAM(lParam) - 20;
			RECT r;
			GetClientRect(hwnd, &r);
			InvalidateSel(hwnd, dps->iSel);
			r.top = y -  (y % dps->cyRow); r.bottom = r.top + dps->cyRow;
			dps->nSel = zinf[y/dps->cyRow].addr;
			SendMessage(hwnd, WM_PAINT, 0, 0);
			InvalidateSel(hwnd, dps->iSel);
			UpdateWindow(hwnd);
			return 0;
		}
 
		case WM_KEYDOWN:
		{
			int Q1 = dps->nRows/4,
				Q2 = dps->nRows/2,
				Q3 = dps->nRows - dps->nRows/4 - 1;
 
			BOOL bCenter = FALSE;
			int nSel_old = dps->nSel;
 
			switch (wParam) {
				case VK_DOWN:
					if (zinf[dps->iSel].addr + zinf[dps->iSel].size != 0x10000) {
						dps->nSel += zinf[dps->iSel].size;
						dps->iSel++;
					}
					bCenter = TRUE;
					break;
				case VK_UP:
					if (dps->nSel != 0) {
						if (zinf[dps->iSel-1].size) dps->nSel = zinf[dps->iSel-1].addr;
						else dps->nSel = zinf[dps->iSel-2].addr;
						dps->iSel--;
					}
					bCenter = TRUE;
					break;
				case VK_NEXT:
					SendMessage(hwnd, WM_VSCROLL, SB_PAGEDOWN, 0);
					break;
				case VK_PRIOR:
					SendMessage(hwnd, WM_VSCROLL, SB_PAGEUP, 0);
					break;
				case 'G': {
					int result;
					result = DialogBox(g_hInst, MAKEINTRESOURCE(IDD_DLGGOTO), hwnd, (DLGPROC)GotoDialogProc);
					if (result == IDOK) SendMessage(hwnd, WM_VSCROLL, MAKEWPARAM(SB_THUMBTRACK, goto_addr), 0);
					dps->nSel = goto_addr;
					SetFocus(hwnd);
					return 0;
				}
			}
 
			if (bCenter && (dps->nSel < dps->nPane || dps->nSel > dps->nPane + dps->nPage)) {
				dps->nSel = nSel_old;
				SendMessage(hwnd, WM_VSCROLL, MAKEWPARAM(SB_THUMBTRACK, dps->nSel), 0);
				while (Q1--) SendMessage(hwnd, WM_VSCROLL, MAKEWPARAM(SB_LINEUP, 0), 0);
				UpdateWindow(hwnd);
				return 0;
			}
 
			// it's on the screen
			if (dps->iSel < Q1) SendMessage(hwnd, WM_VSCROLL, SB_LINEUP, 0);
			else if (dps->iSel > Q3) SendMessage(hwnd, WM_VSCROLL, SB_LINEDOWN, 0);
 
			InvalidateRect(hwnd, NULL, FALSE);
			UpdateWindow(hwnd);
			return 0;
		}
 
		case WM_MOUSEWHEEL:
		{
			int zDelta = GET_WHEEL_DELTA_WPARAM(wParam);
			WPARAM sbtype;
			if (zDelta > 0) sbtype = SB_LINEUP;
			else sbtype = SB_LINEDOWN;
			wParam = sbtype;
			/* Implicity call scroll */
		}
		case WM_VSCROLL:
		{
			static int last_pagedown = 32;
 
			switch (LOWORD(wParam)) {
				case SB_TOP:			//Home key
					dps->nPane = 0;
					break;
				case SB_BOTTOM:
					dps->nPane = 0x10000 - (4*dps->nRows);
					break;
				case SB_LINEUP:
				{
					#define LINEUP_DEPTH	12
 
					if (dps->nPane == 0) return 0;
 
					Z80_info_t zup[LINEUP_DEPTH];
					int nPane_old = dps->nPane;
					// Disasm 6 commands such that the 6th is equal to the first
					// visible command
 
					do {
						disassemble(calcs[gslot].cpu.mem_c, --dps->nPane, LINEUP_DEPTH, zup);
					} while (zup[LINEUP_DEPTH-2].addr > zinf[0].addr && dps->nPane);
 
					unsigned int i;
					for (i = 0; i < LINEUP_DEPTH && zup[i].addr != zinf[0].addr; i++);
					if (dps->nPane == 0) {
						if (i == 0) return 0;
						dps->nPane = zup[i - 1].addr;
					} else {
						if (i == LINEUP_DEPTH || i == 0) {
							dps->nPane = nPane_old - 1;
						} else {
							dps->nPane = zup[i - 1].addr;
						}
					}
					break;
				}
				case SB_LINEDOWN:
					if (zinf[0].addr + dps->nPage == 0x10000) return 0;
 
					if (zinf[0].size) {
						dps->nPane += zinf[0].size;
					} else {
						// label
						dps->nPane += zinf[1].size;
					}
					break;
				case SB_THUMBTRACK:
					dps->nPane = HIWORD(wParam);
					break;
				case SB_PAGEDOWN:
					last_pagedown = zinf[dps->nRows - 2].addr - dps->nPane;
					dps->nPane += last_pagedown;
					break;
				case SB_PAGEUP:
					dps->nPane -= last_pagedown;
					break;
			}
 
			SendMessage(hwnd, WM_COMMAND, DB_DISASM, dps->nPane);
			Z80_info_t 	*zfirst 	= &zinf[0],
						*zlast 	= &zinf[dps->nRows-1];
 
			dps->nPage = zlast->addr + zlast->size - zfirst->addr;
			InvalidateRect(hwnd, NULL, TRUE);
			return dps->nPane;
		}
		case WM_USER:
			switch (wParam) {
				case DB_UPDATE:
					InvalidateRect(hwnd, NULL, FALSE);
					UpdateWindow(hwnd);
					break;
			}
			return 0;
	}
	return DefWindowProc(hwnd, Message, wParam, lParam);
}
