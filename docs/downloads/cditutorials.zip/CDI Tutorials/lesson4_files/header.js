document.write('<div align="center">'); 
document.write('<img src="http://tifreakware.net/images/banners/tifw5.gif"  border="0">'); 
document.write('<br>');
document.write('<table border="0" align="center" valign="center" cellpadding="0" cellspacing="0" bgcolor="#000000">')
document.write('<tr>');

document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/start2g.gif" border="0" width="13" height="29" alt=""></TD>');
document.write('<TD height="29" bgcolor="#007000" align="center" background="http://tifreakware.net/images/navbar/middleg.gif" class="topbutton"><a href="http://tifreakware.net" class="topbutton">Home</a></td>');
document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/end2g.gif" border="0" width="13" height="29" alt=""></TD>');

document.write('<td width="4" height="29">&nbsp;</TD>');

document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/start2g.gif" border="0" width="13" height="29" alt=""></TD>');
document.write('<TD height="29" bgcolor="#007000" align="center" background="http://tifreakware.net/images/navbar/middleg.gif" class="topbutton"><a href="http://tifreakware.net/archives" class="topbutton">Archives</a></td>');
document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/end2g.gif" border="0" width="13" height="29" alt=""></TD>');

document.write('<td width="4" height="29">&nbsp;</TD>');

document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/start2g.gif" border="0" width="13" height="29" alt=""></TD>');
document.write('<TD height="29" bgcolor="#007000" align="center" background="http://tifreakware.net/images/navbar/middleg.gif" class="topbutton"><a href="http://s4.invisionfree.com/TIFreakware/index.php" class="topbutton">Forum</a></td>');
document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/end2g.gif" border="0" width="13" height="29" alt=""></TD>');

document.write('<td width="4" height="29">&nbsp;</TD>');

document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/start2g.gif" border="0" width="13" height="29" alt=""></TD>');
document.write('<TD height="29" bgcolor="#007000" align="center" background="http://tifreakware.net/images/navbar/middleg.gif" class="topbutton"><a href="http://tifreakware.net/tutorials/" class="topbutton">Tutorials</a></td>');
document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/end2g.gif" border="0" width="13" height="29" alt=""></TD>');

document.write('<td width="4" height="29">&nbsp;</TD>');

document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/start2g.gif" border="0" width="13" height="29" alt=""></TD>');
document.write('<TD height="29" bgcolor="#007000" align="center" background="http://tifreakware.net/images/navbar/middleg.gif" class="topbutton"><a href="http://tifreakware.net/admin/link.php?catag=index" class="topbutton">Links</a></td>');
document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/end2g.gif" border="0" width="13" height="29" alt=""></TD>');

document.write('<td width="4" height="29">&nbsp;</TD>');

document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/start2g.gif" border="0" width="13" height="29" alt=""></TD>');
document.write('<TD height="29" bgcolor="#007000" align="center" background="http://tifreakware.net/images/navbar/middleg.gif" class="topbutton"><a href="http://tifreakware.net/irc/" class="topbutton">IRC</a></td>');
document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/end2g.gif" border="0" width="13" height="29" alt=""></TD>');

document.write('<td width="4" height="29">&nbsp;</TD>');

document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/start2g.gif" border="0" width="13" height="29" alt=""></TD>');
document.write('<TD height="29" bgcolor="#007000" align="center" background="http://tifreakware.net/images/navbar/middleg.gif" class="topbutton"><a href="http://tifreakware.net/contest/" class="topbutton">Contest</a></td>');
document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/end2g.gif" border="0" width="13" height="29" alt=""></TD>');

document.write('<td width="4" height="29">&nbsp;</TD>');

document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/start2g.gif" border="0" width="13" height="29" alt=""></TD>');
document.write('<TD height="29" bgcolor="#007000" align="center" background="http://tifreakware.net/images/navbar/middleg.gif" class="topbutton"><a href="http://tifreakware.net/projects.htm" class="topbutton">Projects</a></td>');
document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/end2g.gif" border="0" width="13" height="29" alt=""></TD>');

document.write('<td width="4" height="29">&nbsp;</TD>');

document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/start2g.gif" border="0" width="13" height="29" alt=""></TD>');
document.write('<TD height="29" bgcolor="#007000" align="center" background="http://tifreakware.net/images/navbar/middleg.gif" class="topbutton"><a href="http://tifreakware.net/admin" class="topbutton">Control Panel</a></td>');
document.write('<TD height="29" width="13"><img src="http://tifreakware.net/images/navbar/end2g.gif" border="0" width="13" height="29" alt=""></TD>');

document.write('<td width="4" height="29">&nbsp;</TD>');

document.write('</tr></table>');