Readme for the Standard Form TI-Calc Guide
----------------------------------

* Guide.html is the guide that teaches you how to build the software.

* SCREEN01.JPG-SCREEN05.JPG are the pictures of the complete software.

* STRDFORM.8xp is the complete program for the TI-83+, if you have one.

* Of course, there is also this guide. Good luck with your coding.