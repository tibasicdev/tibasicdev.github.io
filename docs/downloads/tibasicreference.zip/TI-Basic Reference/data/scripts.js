<!--
function cellspOn(cellId) {
currBull="mb"+cellId;
currBull=document.getElementById(currBull);
currBull.style.background="white";
currItem="mi"+cellId;
currItem=document.getElementById(currItem);
currItem.style.background="#ff9933 url('images/menuitem_bg.bmp') repeat-y";
}
function cellspOff(cellId) {
currBull="mb"+cellId;
currBull=document.getElementById(currBull);
currBull.style.background="orange";
currItem="mi"+cellId;
currItem=document.getElementById(currItem);
currItem.style.background="white";
}
function buttOn(cellId) {
currCell=document.getElementById(cellId);
currCell.style.background="#ff9933 url('images/button_bg.bmp') repeat-x";
}
function buttOff(cellId) {
currCell=document.getElementById(cellId);
currCell.style.background="white";
}
function klik(loc) {
self.location=loc;
}
function sublinkOn(linkId,kleur) {
currLink=document.getElementById(linkId);
currLink.style.textDecoration="underline";
currLink.style.color=kleur;
}
function sublinkOff(linkId,kleur) {
currLink=document.getElementById(linkId);
currLink.style.textDecoration="none";
currLink.style.color=kleur;
}

function favoriet() {
  if (document.all) {
    window.external.AddFavorite("http://www.tibasic.tk","TI-basic.tk - leer programmeren op de ti-83/ti-83 plus/ti-84: TI-basic");
  }
}

function volscherm() {
self.moveTo(0,0);
self.resizeTo(screen.width,screen.height);
}

function inputOn(inputID) {
but=document.getElementById(inputID);
but.style.borderColor="orange";
}
function inputOff(inputID) {
but=document.getElementById(inputID);
but.style.borderColor="black";
}

function startpagina() {
setHomePage('http://www.tibasic.tk');
}

//-->