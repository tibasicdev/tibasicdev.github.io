document.write("<table align=\"center\" width=\"100\%\" border=\"1\" bordercolor=\"\#00008B\" rules=\"none\" cellspacing=\"0\" cellpadding=\"3\">");

document.write("<tr align=\"center\" valian=\"center\">");

document.write("<td><font size=\"4\"><a href=\"/home.html\">HOME<\/a><\/font><\/td>");

document.write("<td><font size=\"2\">");

document.write("<a href=\"/about.html\">About<\/a> | <a href=\"/archives/index.html\">Archives<\/a> | <a href=\"/awards.html\">Awards<\/a> | <a href=\"/features.html\">Features<\/a> | <a href=\"/games.html\">Games<\/a> | <a href=\"/hosting/index.html\">Hosting<\/a> | <a href=\"/index/index.html\">Index<\/a> | <a href=\"/interact.html\">Interact<\/a><br \/>");

document.write("<a href=\"/cgi-bin/links/index.pl\">Links<\/a> | <a href=\"/members/index.html\">Members<\/a> | <a href=\"/myprograms.html\">Programs<\/a> | <a href=\"/search.html\">Site Search<\/a> | <a href=\"/tutorials/index.html\">Tutorials<\/a> | <a href=\"/updates-news.html\">Updates & News<\/a>");

document.write("<\/font><\/td>");

document.write("<td><font size=\"3\"><a href=\"/contactme.html\" style=\"cursor:help\">HELP<\/a><\/font><\/td>");

document.write("<\/tr><\/table>");