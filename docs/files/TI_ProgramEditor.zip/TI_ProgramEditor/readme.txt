
 TI-Program Editor
 extracted by nitacku

 nitacku@gmail.com
	 
-----------------------------------------------------
 Installation:

 Extract the .zip file to a location of your choice.
 Run "font_install.bat" and Enjoy!

 Credit for the original font goes to TheStorm.

----------------------------------------------------
 Trouble Shooting: 

 - Unknown tag value in program image: 187 176

   This error will occurr if you try to open files
   containing lowercase letters. An easy way to
   get around this error is to open your file in
   TI-Graph link (available from TI's website)
   and copy and paste the file from graph link
   into TI-Program editor.

 - Crashes and errors

   You probably don't have Microsoft .Net Framework
   installed. You can download it for free from
   Microsoft's web site. Just do a google search
   on ".net framework".