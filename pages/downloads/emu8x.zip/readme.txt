Emu8x v1.0

Michael Vincent - me@michaelv.org
Produced for Detached Solutions - www.detachedsolutions.com


MANUAL
======
For the Emu8x manual which is essential for proper operation, visit http://www.detachedsolutions.com/emu8x


IMPORTANT NOTE
==============

The Emu8x flash application, once installed on your calculator, may NOT be transferred to any other calculators. ROM images of calculators are copyrighted by TI and may only be used by the owner of the calculator from which they were dumped. Because these ROM images are embedded in Emu8x, the application cannot be transferred.

Michael Vincent is not liable in any way for any acts or damages resulting from your use of Emu8x. This software comes with absolutely no warranty of any kind.

