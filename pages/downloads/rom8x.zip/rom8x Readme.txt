Best viewed in Notepad with Word Wrap

Program:  rom8x v0.2
Category:  DOS Utilities
Purpose:  83P/84P ROM Packer
Author:  Andree Chea
E-mail:  andree@ss.ticalc.org

/*****************************************************************************************/

Table of Contents
=================
1) Introduction
2) Getting the Dumps
3) Errors on the Dumps
4) Packing the Dumps
5) Errors in Packing
6) Upgrading
7) Emulators
8) License
9) Bugs
10) Version History
11) Future Version
12) Credits
13) Contact

Introduction
====================
rom8x is a console program that will aid one in creating a 'bare minimum' ROM or a complete ROM file.  The complete ROM is supported by the "majority" of the 83+/84+ emulators available, while the 'bare minimum' ROM is specific to TilEm (to date).  It does not require any specific linking software, as everything on the calculator-end is saved into an ordinary AppVar which is sendable via all computer<->calculator linking software, so as long as you can send and receive programs, you are all set.  It currently supports the 83+/83+SE/84+/84+SE calculators.  For a list of recommended emulators (to date) and ROM compatibility, read the 'Emulators' section.

Note:  I will refer to the 83+/83+SE/84+/84+SE as 83PBE/83PSE/84PBE/84PSE, respectively.

Getting the Dumps
====================
*** FOR USERS OF VERSION 0.1:  PLEASE READ THE 'Upgrading' SECTION ALSO ***

For the 83PBE/83PSE, you need only 1 dump, but on the 84PBE/84PSE, you need two.  Here are the steps and programs that you need to send to your calculator.  It is STRONGLY recommended that you clear your RAM prior to running these programs, or have at least 17KB of RAM free.

Note:  Asm( is located in the Catalog, accessible by pressing [2nd]+[0]

83PBE
	- Send G83PBE1.8xp to your calculator.
	- Run it by using Asm(
		- Your homescreen should have the following line:
			Asm(prgmG83PBE1
	- AppVar D83PBE1 should be created:  send this to the rom8x.exe directory on your computer via your linking software.

83PSE
	- Send G83PSE1.8xp to your calculator.
	- Run it by using Asm(
		- Your homescreen should have the following line:
			Asm(prgmG83PSE1
	- AppVar D83PSE1 should be created:  send this to the rom8x.exe directory on your computer via your linking software.

84PBE
	- Send G84PBE1.8xp and G84PBE2.8xp to your calculator.
	- Run G84PBE1 by using Asm(
		- Your homescreen should have the following line:
			Asm(prgmG84PBE1
	- AppVar D84PBE1 should be created:  send this to the rom8x.exe directory on your computer via your linking software and then delete it from your calculator.
	- Now, delete D84PBE1 to free up RAM
	- Repeat for G84PBE2, again, sending D84PBE2 to the rom8x.exe directory.

84PSE
	- Send G84PSE1.8xp and G84PSE2.8xp to your calculator.
	- Run G84PSE1 by using Asm(
		- Your homescreen should have the following line:
			Asm(prgmG84PSE1
	- AppVar D84PSE1 should be created:  send this to the rom8x.exe directory on your computer via your linking software and then delete it from your calculator.
	- Now, delete D84PSE1 to free up RAM
	- Repeat for G84PSE2, again, sending D84PSE2 to the rom8x.exe directory.

The manual that comes with your calculator will explain how to clear your RAM or delete programs.

Errors on the Dumps
====================
You may encounter an error or two when using the programs on the calculator:

"You do not have 16KBs of RAM free."
	You do not have enough free RAM.  Try deleting/archiving some programs, or clear your RAM.

"AppVar D?????? already exists."
	The AppVar is already on your calculator.  Delete/backup the D?????? AppVar and try again.

Packing the Dumps
====================
Now that you have the respective dumps from your calculator, you need to pack them into a ROM.  First download an OS upgrade file from TI's website that matches your calculator (i.e. 83P OS for an 83P calc, 84P OS for an 84P calc).  To date, the most direct link is http://education.ti.com/us/product/apps/latest.html (account required).  Otherwise, start searching from their home page, http://education.ti.com.  Download to the same directory as rom8x.exe.

Now open a command prompt and navigate to the rom8x.exe directory.  Its arguments are as follows:

rom8x calcType [-1 fileName [-2 fileName]] [-u fileName]
where:
      calcType:  calculator model (83PBE|83PSE|84PBE|84PSE)
   -1 fileName:  file name of first dump
   -2 fileName:  file name of second dump
   -u fileName:  OS upgrade file option

Typically, you will only need to concern yourself with calcType and -u.  For calcType, type in 83PBE for a black 83P, 83PSE for an 83P Silver Edition, etc.  Then after the -u switch, type in the name of the OS.

As a hypothetical example, if you have this setup:

	TI-84 Plus Silver Edition
	Windows NT (2000, XP, etc.)
	C:\Documents and Settings\<user>\Desktop\rom8x\rom8x.exe
	C:\Documents and Settings\<user>\Desktop\rom8x\D84PBE1.8xv
	C:\Documents and Settings\<user>\Desktop\rom8x\D84PBE1.8xv
	C:\Documents and Settings\<user>\Desktop\rom8x\TI84Plus_OS230.8xu
	
Then Start > Run > cmd.exe

	cd \
	cd Documents and Settings
	cd <user>
	cd Desktop
	cd rom8x
	rom8x 84PSE -u TI84Plus_OS230.8xu

If all goes well, a message should pop up saying that "8?P?E_v???.rom was successfully created."

Errors in Packing
====================
"? is not a supported model."
	You typed in a bad value for the first argument.  Remember that it can only be 83PBE, 83PSE, 84PBE, or 84PSE.

"invalid switch / not enough parameters / unknown option."
	You specified incorrect parameter(s).  Try again.

"invalid dump file."
	The file you provided was not a dump file.  Either move them there or re-dump the files from your calculator.
	
"invalid OS file."
	The OS file you specified did not have a valid header.  Make sure you are specifying an 83P OS for an 83P calculator and an 84P OS for an 84P calculator.
	
"unable to write ? to ROM file."
	The file could not be read/written for some reason, such as another program has the file locked.  Close any conflicting programs and try again.

There are probably a few more, but they are self-explanatory.

Upgrading
====================
If you have used v0.1, you may have noticed that the file names have changed.  Although you theoretically could just rename the file, it is 'better' to use these switches.  In general, when upgrading from v0.1 and you are too lazy to re-dump, you use a -2 if it was dump #1 and you would use a -1 if it was dump #2.  So:

	rom8x 83PBE -1 d83be2.8xp -u TI83Plus_OS118.8xu
	rom8x 83PSE -1 d83se2.8xp -u TI83Plus_OS118.8xu
	rom8x 84PBE -1 d84be2.8xp -2 d84be1.8xp -u TI84Plus_OS230.8xu
	rom8x 84PSE -1 d84se2.8xp -2 d84se1.8xp -u TI84Plus_OS230.8xu

The -1 and -2 options allow you to specify your own file names for the dumps 'if you have done this before' ;)

Version 0.1 was limited in that it only generated a ROM file without an OS, and to use the ROM file, one would have to load an OS to it via TilEm.  If you want this functionality (under normal circumstances, you don't, as no emulator other than TilEm currently supports it), simply omit the -u option.

Emulators
====================
Here is a list of emulators for Windows (to date) that 'could' accept the ROMs generated by this program:

VTI 2.5 Beta 5 - http://www.ticalc.org/archives/files/fileinfo/84/8442.html
Author: Rusty Wagner
	This emulator is the most well known and used emulator for TI calculators ever since it was released.  It supports most of the Z80/68K calculators (82/83/83PBE/85/86/89/92/92II/92P) and has a decent debugger, as well as numerous of other features.  It also has its share of bugs, such as not being able to load Apps and some (minor?) flawed emulation.  However, this emulator only emulates an 83PBE OS v1.12.  Unless you have OS v1.12, this emulator won't be that useful to you.

VTI 3.0 Alpha - http://www.ticalc.org/archives/files/fileinfo/261/26120.html
Author: Rusty Wagner
	This emulator supports a selected number of Z80 calculators (73/83PBE/83PSE, sorry, not 84P), and also supports OS versions greater than v1.12.  However, it lacks most of v2.5b5's features, and only permits you to send Apps.

TilEm - http://www.ticalc.org/archives/files/fileinfo/372/37211.html
Authors: Solignac Julien and Benjamin Moody
	Although initially a Linux-only emulator (TI Linux EMulator), it was ported it to Windows, and supports 'all Z80 TI calculators except the TI-81, and all known ROM/OS versions' (yes, that includes the 84P).  Therefore, if you have an 84P, this is the only emulator that you can use.  It has its share of features, and is still under development.

PindurTI - http://www.hszk.bme.hu/~pg429/pindurti/
Author: Patai Gergely
	To date, this emulator supports the 82, 83, and 83P calculators.  The main goal of this emulator is to provide the most accurate emulation in terms of hardware.  The 'flawed emulation' that is present in VTI is not (or should not be) present in PindurTI, and most of time, emulation is significantly improved.  It also has its share of features, and is still under development.

License
====================
Copyright (C) 2005 Andree Chea <andree@ss.ticalc.org>
Portions copyright (C) 2003 Benjamin Moody <benjamin@ecg.mit.edu>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

ROM images are copyrighted by TI and should not be distributed.  The
author of this program is not responsible for any issues that arise
with your (mis)use of this program.

Bugs
====================
-?

Even if there aren't any bugs here, that doesn't mean there aren't any, since I haven't fully tested this program.  So if you find one, please don't hesitate to tell me so I can fix it!

Version History
====================
20050802	Version 0.1
-First Public Release

20051209	Version 0.2
-Bug fix in G8?P?E programs
-Completely recoded from scratch in C (v0.1 was in C++)
-New, more flexible argument input method
-Allows OS upgrade file integration into the ROM
-Source! (released under the terms of the GNU GPL license)

Future Versions
====================
-More accurate ROM generation
-Optimizations

Credits
====================
Benjamin Moody (a.k.a. FloppusMaximus) for TilEm, OS Tools, and his invaluable support. :)
Tim Singer and Romain Li�vin (and those who helped them) for making the TI-XX Link Protocol Guide.
Various testers for testing this package.

Contact
====================
Any questions, comments, problems, criticisms? PLEASE send them all to:
andree@ss.ticalc.org

(2*b)||!(2*b); that = theQuestion;
Thank you for downloading!