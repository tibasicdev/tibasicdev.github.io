IF YOU CANT READ PRESS THE "[]"BUTTION

            BBB          BBB           U  U
           (B B          B B           U  U
           |BB   ATTEL   BB  OTZ       U  U NLESHED )
  ----{o}---B B          B B           U  U         |
  |_____    BBB          BBB           UUUU         |____{o}----|
        )                                                       |_____)

   BATTEL BOTZ UNLESHED
                  demo     VERSION


known errors

auto louse/ win in tornamen mode

***********************************************
             TOREMENT
***********************************************

   *CREATE AND NAME YOUR BOT.


   *AND FIGHT COMPEITOS

   *LOOK OUT FOR STELTH MISSELS

   * WIN

   *REPEAT
*************************
	FREE	PLAY
*************************


USE A ALREY MADE BOT

TO FIGHT A PRATICE BOT

***********************
WHATS IN V1?
***********************
all errors fixed

BACKROUNDS, AUTO AND CUSTOM



ENDING TORNAMENT


****************************************
CONTACT INFO
*************************************
E-MAIL THE 4ce @
Mgk0330@comcast.net

  OR DOWNLOAD MORE GAMES FROM US @
http://www.ticalc.org/archives/files/authors/94/9438.html
