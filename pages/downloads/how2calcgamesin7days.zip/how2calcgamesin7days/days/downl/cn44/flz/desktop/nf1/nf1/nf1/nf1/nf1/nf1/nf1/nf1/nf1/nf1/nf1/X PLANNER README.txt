    THANK YOU FOR DOWNLOADING THE 

      4        CCCCCC       EEEEEE
     4 4      C             E
    4  4      C             E                       
    444444   C             EEEEEE
       4      C             E                
       4       CCCCCC       EEEEEEE



XPLANNER   V 1.4

   PUTS YOUR CALC POWER TO WORK WITH 
TEXT STRINGING SAVE TECNOLOGEY.

**************************************
 		DEFULT  PASSWORD

**************************************
THE DEFULT PASSWORD IS STUDENT1 BUT YOU CAN
CHANGE IT AND THE NAMES OF YOUR SUBJECTS.
TO DO THIS EDIT PRGM "XPLANNER"  AND GO DOWN TO WERE IT
SAYS  ("STUDENT1"->STRNG01) AND CHANGE STUDENT1 TO WHAT EVER YOU WNT YOUR 
PASSWORD TO BE.

******************************************
USING THE XPLANER
******************************************
THE PLANNER CAN BE RUN ON MIRAGE OS OR FROM THE PGRM MENU

AFTER TYPING IN YOUR PASSWORD 
A MENU WILL APPEAR PICK A SUBJECT, PRESS ENTER ON IT IT WILL 
BRING UP ANOTHER MENU FOR NEW NOTES, OR VEIW NOTES
***************************************************
LOSS OF DATA
***************************************************
IF YOUR RAM IS CLEARED YOU WILL LOUSE ALL SAVED DATA
IN V 1.4 ONLY
****************************************************
WHAT IS GOING TO BE IN VERION 2
****************************************************
YOU WILL BEABELE TO SAVE MUTABAL NOTES PER SUBJECT AND
A NEW BUILT IN GAMES FEATCURE, AND TIMER.

*******************************************************
WHEN DOSE V 2 COME OUT
********************************************************
WHEN I LEARN TO MAKE LISTS   (JUNE 06)
