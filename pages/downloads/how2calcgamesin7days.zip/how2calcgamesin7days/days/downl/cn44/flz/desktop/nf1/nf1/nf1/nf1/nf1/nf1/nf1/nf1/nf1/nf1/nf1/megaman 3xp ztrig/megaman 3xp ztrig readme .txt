IF YOU CANT READ THIS CLICH THE []
FULL SCREEN BUTTION
	                                                                                                                                                                                                                                                                    MM MM    EEEEEEE    GGGGGG      AAA       MM MM      AAA      NNN    N                                        
               M  M  M   E          G          A   A     M  M  M    A   A     N  N   N
               M     M   EEEEEE     G   GGG   AAAAAAA    M     M   AAAAAAA    N   N  N
               M     M   E          G     G  A       A   M     M  A      A    N    N N
 ______________M_____M___EEEEEE_____GGGGGGG_A_________A__M_____M A________A___M_____N___________

 if you cant read it still it says MEGAMAN

                  3 TIMES XTRA POWER     (BASIC VERSON)
  
                                    ztrig

*************************************************************************************************

			STORY       LINE
*************************************************************************************************

AFTER WILLYS DEATH EVERY ONE THOUGHT LIFE WOULD BE EZAYER, BUT THEY FOUND OUT WILLY WASENT GONE AFTER ALL, SHURE HE WAS DEAD, BUT HE CLONED HIMSELF, HIS CLONE KIDNAPPED LAN, MALU AND CHAD, YOU GET TO TRAIN THEIR NAVIS TO GET REDY FOR THE FIGHT OF THIR LIVES.

*************************************************************************************************
CONTENTS:
*************************************************************************************************

******************************************************************************************************
saving  and recalling files
********************************************************************************************************
to save a file in the menu with your name on it go down to save
***
to recall a file when you first start the game go to saved and it will put
you right back were you were when you saves.

**********************************************************************
     saving    faQ
********************************************************************/
Q   when i start a new file dose it erase my saved one?

A: not unless you save it


Q: i frogot my password!


A:   quit the game then press the zero key and 
the sto-> key and the alpha key then number 1 key,
the screen should look like this:

0->Y

then press enter

and go back to the game



Q:   whats the cheepest way to make a milk shake?

by a milk carton at school freze it solad then defrost for 1 hour
********************************************************************





MIRAGE OS COMPADABEL :
(I DON'T RECREMEND IT MAY NOT WORK CORETLY)

2 TOWNS
(ACDC AND POWER PLANT

2 BOSS LELELS
(IN CONSTUTION)
(VS BASS, AND VS. WILLY CLONE)

3 NAVIS (MEGAMAN, PROTOMAN, RUSH)
 
STORE


MONEY  
BETA SYMBOL(0) = CASH 


WIN COUNT
TELLS YOUR TOTAL WIN NUMBER AND 
INDAVAL WINS COUNT FOR EACH NAVI


GAMEPLAY:
name your charitor

jack in 

go to area

fight 4 ur life

train to unlimited levels

face bass and use your skills to train with him.

and finally face willy's clone
********************************************************************************
CONTACT INFO
*********************************************************************
E-MAIL THE CO-CREATOR @
Mgk0330@comcast.net

  OR DOWNLOAD MORE GAMES FROM US @
http://www.ticalc.org/archives/files/authors/94/9438.html




