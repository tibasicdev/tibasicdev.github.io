
siepins is a program for when your so board you dont want to even play any games.



program source: ti-83 plus

gide book


progrmer:
4ce