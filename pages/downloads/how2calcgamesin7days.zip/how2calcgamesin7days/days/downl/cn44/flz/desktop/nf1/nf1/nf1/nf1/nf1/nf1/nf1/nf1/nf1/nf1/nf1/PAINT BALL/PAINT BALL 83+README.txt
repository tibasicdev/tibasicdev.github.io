

	HAVE YOU EVER BEEN PAINTBALLING IN SCHOOL?
IF NOT YOUVE NEVER TRIED:



  PAINT  BALL 83+  -----------(SPLAT)  BY 4CE LABS


MABEY THATS WHY YOU ARE READING THIS


*****************************************
    HOW   2      PLAY
******************************************

ONCE THE GAME IS STARTED YOU USE THE ARROW KEYS
TO MOVE YOUR TARGET LOCKER THEN PRESS THE (XT0N)
TO FIRE!


*******************************************
THATS IT PRETY EZEY TO UNDERSTAND BUT 
NOT AS EZEY TO DO!
********************************************

****************************************
CONTACT INFO
*************************************
E-MAIL THE 4ce @
MgkO33O@comcast.net

  OR DOWNLOAD MORE GAMES FROM US @
http://www.ticalc.org/archives/files/authors/94/9438.html