


		LAF LAND 2


ITS A JOKE PROGRAM YOU DONT NEED A READ ME!

***********************
CONTACT INFO
*********************
E-MAIL THE 4CE @
Mgk0330@comcast.net

  OR DOWNLOAD MORE GAMES FROM US @
http://www.ticalc.org/archives/files/authors/94/9438.html