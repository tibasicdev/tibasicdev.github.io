    custom 

  oooooooooooooooooooooooo
  F             F         F
  F              F        F
  **************************
  RRRRRRRRRRRRRRRRRRRRRRRRR R
  OOOOOOOOOOOOOOOOOOOOOOOOOOOO
  AAAAAAAAAAAAAAAAAAAAAAAAAAAA
  DDDD       DDDDDDD      DDDDD
      !!!!!!         !!!!    !!
     !!    !!       !!  !!
    !!      !!     !!    !!
    !!      !!     !!    !!
     !!    !!       !!  !!
       !!!!           !!

  
just like offroad but with custom trucks
BY 4CE

ALL TRUCKS MUST BE IN RAM


to desine your own truck make a new progam and name it "TRUCK1" 

MAKE IT A DISPLAY: EXAMPEL

YOU GET 6 LINES

(KEEP THE LAST TWO DISP'S IN THIS EXAMPEL IN YOUR PROGRAM TO KEEP FORM GETTING ERRORS)
{TO GET (DISP ) PRESS PRGM THE RIGHT  ARROW AND THE NUMBER 3}

(PRESS 2ND AND PLUS TO GET {"S})

PROGRAM:TRUCK1

:DISP " --------"
:DISP "[     /--]"
:DISP "[^^^^^^^^>"
:DISP "(*********>
:DISP " 0     0
:DISP "----------------"

THEN CREATE ANOTHER NEW PROGRAM BY QUITING OUT OF THE OLD ONE.

PROGRAM:TRUCK2

:DISP " --------"
:DISP "[     /--]"
:DISP "[^^^^^^^^>"
:DISP "(*********>
:DISP " 0     0
:DISP "--------------+-"


TRUCK2 SHOUL LOOK THE SAME BUT MOVE THE "+" OVER TWO SPOTS

PROGRAM:TRUCK3

:DISP " --------"
:DISP "[     /--]"
:DISP "[^^^^^^^^>"
:DISP "(*********>
:DISP " 0     0
:DISP "------------+---"

NEW PROGAM


PROGRAM:TRUCK4
:DISP " --------"
:DISP "[     /--]"
:DISP "[^^^^^^^^>"
:DISP "(*********>
:DISP " 0     0
:DISP "----------+-----"




PROGRAM:TRUCK5
:DISP " --------"
:DISP "[     /--]"
:DISP "[^^^^^^^^>"
:DISP "(*********>
:DISP " 0     0
:DISP "--------+-------"

TRUCK 6 IS DIFRENT ADD A LINE FOR WHEN THE TRUCK JUMPS

PROGRAM:TRUCK6
:DISP " --------"
:DISP "[     /--]"
:DISP "[^^^^^^^^>"
:DISP "(*********>
:DISP " 0     0
:DISP ""
:DISP "---+------------"

LAST ONE GOOD WORK



PROGRAM:TRUCK7
:DISP " --------"
:DISP "[     /--]"
:DISP "[^^^^^^^^>"
:DISP "(*********>
:DISP " 0     0
:DISP "+---------------"

NOW TRY OUT "CTMOFFRD"

