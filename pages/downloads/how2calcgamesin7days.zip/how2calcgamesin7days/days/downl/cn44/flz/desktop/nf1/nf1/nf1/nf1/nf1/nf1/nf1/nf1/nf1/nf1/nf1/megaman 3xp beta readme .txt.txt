IF YOU CANT READ THIS CLICH THE []
FULL SCREEN BUTTION
	                                                                                                         MM   MM   EEEEEE      GGGGGGG     A       MM   MM      A       NN     N                           M M M M   E          G           A A      M M M M     A A      N N    N
               M  M  M   E          G          A   A     M  M  M    A   A     N  N   N
               M     M   EEEEEE     G   GGG   AAAAAAA    M     M   AAAAAAA    N   N  N
               M     M   E          G     G  A       A   M     M  A      A    N    N N
 ______________M_____M___EEEEEE_____GGGGGGG_A_________A__M_____M A________A___M_____N___________



                  3 TIMES XTRA POWER     (BASIC VERSON)
  
                                      beta

*************************************************************************************************

			STORY       LINE
*************************************************************************************************

AFTER WILLYS DEATH EVERY ONE THOUGHT LIFE WOULD BE EZAYER, BUT THEY FOUND OUT WILLY WASENT GONE AFTER ALL, SHURE HE WAS DEAD, BUT HE CLONED HIMSELF, HIS CLONE KIDNAPPED LAN, MALU AND CHAD, YOU GET TO TRAIN THEIR NAVIS TO GET REDY FOR THE FIGHT OF THIR LIVES.

*************************************************************************************************
CONTENTS:
*************************************************************************************************

MIRAGE OS COMPADABEL :
(I DON'T RECREMEND IT MAY NOT WORK CORETLY)

2 TOWNS
(ACDC AND POWER PLANT

2 BOSS LELELS
(VS BASS, AND VS. WILLY CLONE)

3 NAVIS (MEGAMAN, PROTOMAN, RUSH)
 
STORE


MONEY  
BETA SYMBOL(0) = CASH 


WIN COUNT
TELLS YOUR TOTAL WIN NUMBER AND 
INDAVAL WINS COUNT FOR EACH NAVI


GAMEPLAY:
name your charitor

jack in 

go to area

fight 4 ur life

train to unlimited levels

face bass and use your skills to train with him.

and finally face willy's clone

******************************************
90%  done

-cant fight willy clone

-fight bass whith only megaman and protoman




