
   holo ultimit war {demo}


   by 4ce
     {david matthews}

**************************************
controls
**************************************

enter =move enemy
 
first frame when enemy jumps

press enter and he will quickly move higer up you must hit the up arrow right as his chest is infront of your gun. it is hard but dont press enter and up at the same time
**************************************
demo levels
**************************************
the only levels that work in  demo are artic (work great destroy 20 enemys)
and ufo(buggy)

**************************************
important
**************************************
send group "holodemo" not just game so  when your ram is cleared you can just  ungroup insted of re downloading.
**************************************
ungroping
**************************************
to ungroup
press 2nd then press"+" this opens the memory menu, then press the up arrow  and the number 8 shoud be highlighted
then press enter, next press the right
arrow and ungroup shoud be highlited
scroll down to "holodemo" and press enter if an error comes up go to overwrite unless it says error archived then unarchive all pics and try agian.


